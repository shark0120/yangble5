# yb5 pipeline contracts

## ORIENT
```json
{"mode":"research|code|architecture|strategy|writing|decision|debug|creative","goal":"...","audience":"...","constraints":[],"depth":"micro|lite|standard|max|insane","done_definition":[],"risk_if_wrong":"...","irreversible":false,"tool_plan":["search","shell","tests"]}
```

## DECOMPOSE
```json
{"streams":[{"id":"S1","question":"...","why_it_matters":"...","lens":"evidence|risk|alternative|edge|decision","status":"open|done|skipped"}]}
```
Rules: count=SUBQUESTIONS; >=1 kill-case; >=1 alternative unless pure single-bug debug.

## EXECUTE
```json
{"stream_id":"S1","findings":[{"id":"C1","text":"...","evidence":["..."],"method":"search|code-run|reasoning|user-provided"}],"open_questions":[]}
```

## VERIFY
```json
{"claim_id":"C1","votes":[{"lens":"...","refuted":true,"reasoning":"...","severity":"..."}],"status":"VERIFIED|SUPPORTED|UNVERIFIED|CONTESTED","kept_text":"..."}
```

## REDTEAM
```json
{"strikes":[{"type":"contradiction|missing_killer|incentive","attack":"...","severity":"...","severity_on_conclusion":"high|med|low"}],"must_fix_before_ship":[],"conclusion_still_stands":true}
```

## CRITIC
```json
{"missing":[{"question":"...","impact":"...","priority":1}],"stop":false}
```

## SYNTHESIS judge
Score drafts on quality-rubric axes; pick winner; absorb steelman/premortem residue.

## METACRITIC
```json
{"mocks":["..."],"patches_applied":["..."],"deferred":["..."]}
```

## GATE
Structural + rubric threshold by depth. Footer required:

```
---
yb5 | depth=... | streams=... | rounds=... | verifiers=... | drafts=...
survived=.../... | bumped=... | mode=... | run=...
weakest: ...
next_token_spend: ...
gate: PASS|FAIL avg=...
redteam: clean|patched|unresolved
```

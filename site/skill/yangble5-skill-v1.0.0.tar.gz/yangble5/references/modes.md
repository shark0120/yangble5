# yb5 modes

Pick one in ORIENT. Same elite loop; different final shape.

## research
Streams: definitions, current state, primary evidence, counterevidence, base rates, stakeholders.
Final: bottom line; tagged findings; evidence map; counterpoints; open questions; what would change my mind.

## code
Streams: repro, root cause, minimal fix, tests, regressions, perf/security edges.
Final: diagnosis; patch; tests run+output; residual risks.
Never claim tests passed unless run.

## architecture
Streams: requirements, constraints, 2-4 options, trade table, failure modes, migration, operability.
Final: recommendation; rejected alternatives; contracts; rollout/backout; risks.

## strategy / decision
Streams: objective, options, EV, kill-criteria, incentives, second-order, reversibility.
Final: decision; rationale; rejected alts; monitors; review trigger.
Irreversible => pilot if possible.

## writing
Streams: audience, promise, structure, proof, objections, tone risks, cuts.
Final: the piece + short choices/cuts appendix. Verify factual claims inside.

## debug
Streams: symptoms, timeline, bisect, blast radius, fix vs workaround.
Final: root cause -> evidence -> fix -> verification.

## creative
Diverge many seeds -> adversarial craft critique -> best-of-N.
Subjective calls are SUPPORTED with craft rationale, not VERIFIED.

## Cross rules
- kill-case stream always
- unknowns explicit
- tools on when available
- pick defaults; label assumptions; continue

# yb5 red-team patterns

Use during REDTEAM stage and whenever the answer is becoming too neat.

## Attack catalog

### A. Evidence attacks
- Citation laundering (blog cites blog)
- Screenshot/API docs out of date
- N=1 anecdote generalized
- Metric without denominator / window
- Survivorship bias

### B. Logic attacks
- Hidden quantifier shift (some -> all)
- Causal claim from correlation
- Base-rate neglect
- Multiple comparisons / garden of forking paths
- False dichotomy

### C. Product/code attacks
- Works on happy path only
- Missing authz/tenancy checks
- Timezones, idempotency, retries, poison messages
- Migration not backward compatible
- Observability cannot detect failure

### D. Strategy attacks
- Competitor response ignored
- Incentive misalignment inside org
- Single vendor / key-person risk
- Regulatory cliff
- Liquidity / runway fantasy

### E. Process attacks
- Goalpost move mid-analysis
- Unfalsifiable recommendation
- No kill-criteria
- No owner / no timer

## Minimum red-team output

For each material recommendation produce:
1. strongest counter-argument
2. cheapest decisive test
3. stop/go trigger

## Pass condition

REDTEAM pass is not "no attacks found".
Pass = attacks found, severity labeled, high-severity ones answered or they downgrade the claim.

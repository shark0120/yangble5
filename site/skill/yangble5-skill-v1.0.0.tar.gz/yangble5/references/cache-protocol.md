# yb5 cache protocol (99.9)

Target: min_lcp_ratio >= 0.999
Assembly: STABLE_PACK -> USER -> INTERNAL
Card sha256: `31ff8dbec379023c49dc5e1854b76e4683960371848c25d26a96ea6c2deb0a52`

Runtime/omega/arena must not put volatile bytes into STABLE_PACK.

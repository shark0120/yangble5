#!/usr/bin/env python3
"""Heuristic scorer for yb5-shaped artifacts.

Not an LLM judge - a cheap structural gate you can run offline before claiming done.

Usage:
  python yb5_score.py --input report.md
  python yb5_score.py --text "..."
  echo report | python yb5_score.py --stdin
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

TAGS = ("VERIFIED", "SUPPORTED", "UNVERIFIED", "CONTESTED")
FOOTER_MARK = re.compile(r"^---\s*$", re.M)
YB5_FOOTER = re.compile(r"yb5\s*\|", re.I)
TAG_RE = re.compile(r"\b(VERIFIED|SUPPORTED|UNVERIFIED|CONTESTED)\b")
URL_RE = re.compile(r"https?://[^\s)\]]+")
FAKE_PRECISION = re.compile(r"\b\d+\.\d{3,}%\b")


def load_text(args: argparse.Namespace) -> str:
    if args.stdin:
        return sys.stdin.read()
    if args.text is not None:
        return args.text
    if args.input:
        return Path(args.input).read_text(encoding="utf-8")
    raise SystemExit("provide --input, --text, or --stdin")


def score(text: str) -> dict:
    checks = {}
    tags_found = TAG_RE.findall(text)
    checks["has_tags"] = bool(tags_found)
    checks["tag_counts"] = {t: tags_found.count(t) for t in TAGS}
    checks["has_footer_rule"] = bool(FOOTER_MARK.search(text)) and bool(YB5_FOOTER.search(text))
    checks["has_urls_or_paths"] = bool(URL_RE.search(text)) or bool(
        re.search(r"`[^`]+`|\b[\w.-]+\.(py|ts|tsx|md|json)\b", text)
    )
    checks["has_unknowns"] = bool(
        re.search(
            r"\b(unknown|unverified|open question|residual risk|what would change)\b",
            text,
            re.I,
        )
    )
    stripped = text.lstrip()
    checks["has_direct_answer"] = len(text.strip()) > 0 and not stripped.lower().startswith(
        ("first,", "in this report", "as an ai", "certainly")
    )
    checks["no_fake_precision"] = FAKE_PRECISION.search(text) is None
    checks["length_ok"] = 400 <= len(text) <= 80_000
    v = checks["tag_counts"]["VERIFIED"]
    weak = checks["tag_counts"]["UNVERIFIED"] + checks["tag_counts"]["CONTESTED"]
    checks["not_suspiciously_agreeable"] = not (v >= 5 and weak == 0 and len(text) > 1500)

    truth = 3
    if checks["has_tags"] and checks["has_urls_or_paths"] and checks["no_fake_precision"]:
        truth = 5 if checks["has_unknowns"] else 4
    elif not checks["no_fake_precision"]:
        truth = 2

    adversarial = 4 if (weak > 0 or checks["tag_counts"]["SUPPORTED"] > 0) else 2
    if not checks["not_suspiciously_agreeable"]:
        adversarial = min(adversarial, 2)

    coverage = 4 if checks["has_unknowns"] and checks["length_ok"] else 3
    decision = (
        4
        if re.search(r"\b(recommend|bottom line|decision|fix|patch|next step)\b", text, re.I)
        else 2
    )
    structure = 5 if checks["has_footer_rule"] and checks["has_tags"] else (3 if checks["has_tags"] else 2)

    axes = {
        "truthfulness": truth,
        "adversarial_hardness": adversarial,
        "coverage": coverage,
        "decision_usefulness": decision,
        "structure_density": structure,
    }
    avg = sum(axes.values()) / len(axes)
    bump = avg < 4.0 or not checks["has_footer_rule"] or not checks["has_tags"]
    return {
        "axes": axes,
        "average": round(avg, 2),
        "pass": avg >= 4.0 and checks["has_footer_rule"] and checks["has_tags"],
        "auto_bump": bump,
        "checks": checks,
        "advice": _advice(axes, checks),
    }


def _advice(axes: dict, checks: dict) -> list[str]:
    tips = []
    if axes["truthfulness"] < 4:
        tips.append("Add primary evidence handles and kill fake precision.")
    if axes["adversarial_hardness"] < 4:
        tips.append("Run real refuters; keep some UNVERIFIED/CONTESTED residue.")
    if axes["coverage"] < 4:
        tips.append("Another completeness round on risks/alternatives.")
    if axes["decision_usefulness"] < 4:
        tips.append("Lead with a crisp recommendation and kill-criteria.")
    if axes["structure_density"] < 4:
        tips.append("Add claim tags + required yb5 metadata footer.")
    if not checks["has_footer_rule"]:
        tips.append("Missing `yb5 | depth=...` footer.")
    if not tips:
        tips.append("Structural gate passed; optional: spend tokens on weakest domain content.")
    return tips


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Score a yb5-shaped artifact")
    parser.add_argument("--input", help="Path to markdown/text report")
    parser.add_argument("--text", help="Inline text")
    parser.add_argument("--stdin", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    text = load_text(args)
    result = score(text)
    if args.json:
        json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        status = "PASS" if result["pass"] else "FAIL"
        print(f"yb5_score: {status}  avg={result['average']}  auto_bump={result['auto_bump']}")
        for k, v in result["axes"].items():
            print(f"  {k}: {v}/5")
        print("advice:")
        for tip in result["advice"]:
            print(f"  - {tip}")
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
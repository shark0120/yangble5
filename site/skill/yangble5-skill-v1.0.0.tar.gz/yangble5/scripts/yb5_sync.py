#!/usr/bin/env python3
"""Sync the repo yangble5 skill to %USERPROFILE%/.codex/skills/yangble5 and report drift."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
USER = Path.home() / ".codex" / "skills" / "yangble5"


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def list_files(root: Path) -> dict[str, str]:
    out = {}
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if "__pycache__" in p.parts or p.suffix == ".pyc":
            continue
        if ".yb5" in p.parts:
            continue
        rel = p.relative_to(root).as_posix()
        out[rel] = file_hash(p)
    return out


def drift_report() -> dict:
    if not USER.exists():
        return {"in_sync": False, "reason": "user skill missing", "only_repo": [], "only_user": [], "changed": []}
    r = list_files(REPO)
    u = list_files(USER)
    only_repo = sorted(set(r) - set(u))
    only_user = sorted(set(u) - set(r))
    changed = sorted(k for k in set(r) & set(u) if r[k] != u[k])
    return {
        "in_sync": not only_repo and not only_user and not changed,
        "only_repo": only_repo,
        "only_user": only_user,
        "changed": changed,
        "repo_files": len(r),
        "user_files": len(u),
    }


def sync() -> dict:
    if USER.exists():
        shutil.rmtree(USER)
    shutil.copytree(REPO, USER, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".yb5"))
    rep = drift_report()
    rep["synced"] = True
    return rep


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true", help="only report drift")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    rep = drift_report() if args.check else sync()
    if args.json:
        json.dump(rep, sys.stdout, indent=2)
        sys.stdout.write("\n")
    else:
        print("yb5_sync:", "IN_SYNC" if rep.get("in_sync") else "DRIFT")
        for k in ("only_repo", "only_user", "changed"):
            if rep.get(k):
                print(f"  {k}: {rep[k]}")
        print(f"  repo_files={rep.get('repo_files')} user_files={rep.get('user_files')}")
    return 0 if rep.get("in_sync") else 1


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""yb5 planner - emit a depth-tier work plan as JSON/Markdown.

Usage:
  python yb5_plan.py --task "Due diligence on Acme robotics" --depth max
  python yb5_plan.py --task "Fix flaky auth race" --mode code --depth standard
"""
from __future__ import annotations

import argparse
import json
import re
import sys

DEPTHS = {
    "micro": {
        "SUBQUESTIONS": 1,
        "VERIFIER_VOTES": 1,
        "MAX_ROUNDS": 0,
        "SYNTHESIS_DRAFTS": 1,
        "PARALLEL_LENSES": 1,
    },
    "lite": {
        "SUBQUESTIONS": 4,
        "VERIFIER_VOTES": 1,
        "MAX_ROUNDS": 1,
        "SYNTHESIS_DRAFTS": 1,
        "PARALLEL_LENSES": 1,
    },
    "standard": {
        "SUBQUESTIONS": 8,
        "VERIFIER_VOTES": 3,
        "MAX_ROUNDS": 2,
        "SYNTHESIS_DRAFTS": 2,
        "PARALLEL_LENSES": 3,
    },
    "max": {
        "SUBQUESTIONS": 12,
        "VERIFIER_VOTES": 5,
        "MAX_ROUNDS": 3,
        "SYNTHESIS_DRAFTS": 3,
        "PARALLEL_LENSES": 5,
    },
    "insane": {
        "SUBQUESTIONS": 20,
        "VERIFIER_VOTES": 7,
        "MAX_ROUNDS": 5,
        "SYNTHESIS_DRAFTS": 5,
        "PARALLEL_LENSES": 7,
    },
    "omega": {
        "SUBQUESTIONS": 24,
        "VERIFIER_VOTES": 9,
        "MAX_ROUNDS": 8,
        "SYNTHESIS_DRAFTS": 7,
        "PARALLEL_LENSES": 7,
        "OMEGA": True,
        "EPSILON": 0.05,
        "PATIENCE": 2,
        "MAX_OMEGA_STEPS": 12,
    },
}

LENSES = [
    "correctness",
    "recency",
    "source_credibility",
    "completeness",
    "adversary",
    "implementability",
    "incentive",
]

MODE_SEEDS = {
    "research": [
        "What are the load-bearing facts about {task}?",
        "What disconfirming evidence would weaken the main thesis on {task}?",
        "What are the strongest alternative explanations or competitors for {task}?",
        "What base rates and historical analogues apply to {task}?",
        "Who are the stakeholders and what are their incentives around {task}?",
        "What is time-sensitive or likely stale about {task}?",
        "What second-order risks appear if the main recommendation on {task} is wrong?",
        "What decision does {task} unlock, and what kill-criteria should stop it?",
    ],
    "code": [
        "How do we reliably reproduce the failure in {task}?",
        "What is the most likely root cause hierarchy for {task}?",
        "What is the minimal safe patch for {task}?",
        "Which tests prove {task} is fixed and stay green?",
        "What regressions and blast radius could the fix for {task} introduce?",
        "Are there performance, security, or concurrency edges in {task}?",
        "What observability would catch a recurrence of {task}?",
        "What is the rollback / feature-flag plan for {task}?",
    ],
    "architecture": [
        "What requirements and hard constraints bound {task}?",
        "What 2-4 viable designs address {task}?",
        "How do options for {task} trade off simplicity, cost, and operability?",
        "What failure modes dominate each option for {task}?",
        "What interfaces and contracts must stay stable in {task}?",
        "What migration and backout look like for {task}?",
        "What is explicitly out of scope for {task}?",
        "What metrics prove the architecture for {task} is working?",
    ],
    "strategy": [
        "What objective and success metric define {task}?",
        "What options exist for {task} and what is reversible?",
        "What is the expected value and downside of each option for {task}?",
        "What incentives distort judgment on {task}?",
        "What second-order effects follow from deciding {task}?",
        "What kill-criteria and monitors belong on {task}?",
        "What does a smart adversary do after we choose on {task}?",
        "What is the default action if we decide nothing on {task}?",
    ],
    "writing": [
        "Who is the audience and what must they believe after {task}?",
        "What is the single promise of the piece for {task}?",
        "What proof points are load-bearing in {task}?",
        "What objections must be pre-empted in {task}?",
        "What structure maximizes scan-value for {task}?",
        "Which claims in {task} need factual verification?",
        "What should be cut ruthlessly from {task}?",
        "What tone risks undermine {task}?",
    ],
    "decision": [
        "What decision is actually being made in {task}?",
        "What are the real options on the table for {task}?",
        "What evidence would change the call on {task}?",
        "What is the cost of being wrong on {task}?",
        "What is reversible vs one-way in {task}?",
        "What stakeholders can veto or sabotage {task}?",
        "What is the timed next review for {task}?",
        "What recommendation survives adversarial review on {task}?",
    ],
    "debug": [
        "What exact symptoms and timeline define {task}?",
        "What changed recently that could cause {task}?",
        "How do we bisect hypotheses for {task}?",
        "What is the smallest decisive experiment for {task}?",
        "What is blast radius if {task} is systemic?",
        "Fix vs workaround: what is justified for {task}?",
        "How do we verify the fix for {task} end-to-end?",
        "How do we prevent silent recurrence of {task}?",
    ],
    "creative": [
        "What is the core emotional or intellectual job of {task}?",
        "Generate divergent directions for {task}",
        "Which directions for {task} are cliche and must die?",
        "What constraints make {task} sharper rather than smaller?",
        "What craft risks (pacing, clarity, originality) hit {task}?",
        "What would a harsh critic mock in {task}?",
        "Which single direction deserves best-of-N expansion for {task}?",
        "What finishing details separate good from unforgettable in {task}?",
    ],
}

EXTRA_ANGLES = [
    "regulatory and compliance exposure for {task}",
    "customer concentration and retention dynamics for {task}",
    "unit economics and path to profitability for {task}",
    "key-person and execution risk inside {task}",
    "technical moat durability of {task}",
    "go-to-market realism for {task}",
    "capital structure and dilution path for {task}",
    "operational scalability limits of {task}",
    "security and safety failure modes of {task}",
    "what smart money opposing {task} would argue",
    "leading indicators to monitor after deciding on {task}",
    "minimum evidence bar before committing more to {task}",
]


def detect_mode(task: str, forced: str | None) -> str:
    if forced:
        return forced
    t = task.lower()
    rules = [
        ("code", r"\b(bug|fix|patch|refactor|test|stack trace|typeerror|compile)\b"),
        ("debug", r"\b(debug|flaky|repro|regression|incident|outage)\b"),
        ("architecture", r"\b(architect|system design|microservice|schema|infra)\b"),
        ("strategy", r"\b(strateg|go-to-market|gtm|pricing|compet)\b"),
        ("decision", r"\b(should we|decide|choose|tradeoff|trade-off)\b"),
        ("writing", r"\b(rewrite|blog|essay|copy|landing|pitch deck prose)\b"),
        ("creative", r"\b(story|poem|brand|name ideas|creative)\b"),
        ("research", r"\b(research|diligence|dd\b|market|cite|source)\b"),
    ]
    for mode, pat in rules:
        if re.search(pat, t):
            return mode
    return "research"


def core_subject(task: str) -> str:
    t = task.strip().rstrip(".?!")
    patterns = [
        r"(?i)^due diligence on\s+",
        r"(?i)^research\s+",
        r"(?i)^analyze\s+",
        r"(?i)^investigate\s+",
        r"(?i)^decide(?: on)?\s+",
        r"(?i)^design\s+",
        r"(?i)^fix\s+",
        r"(?i)^debug\s+",
        r"(?i)^write\s+",
    ]
    for pat in patterns:
        t2 = re.sub(pat, "", t).strip()
        if t2:
            t = t2
    return t or task.strip()


def build_streams(task: str, mode: str, n: int) -> list[dict]:
    seeds = MODE_SEEDS.get(mode, MODE_SEEDS["research"])
    lenses = [
        "evidence",
        "risk",
        "alternative",
        "edge",
        "decision",
        "incentive",
        "base_rate",
        "operability",
    ]
    subject = core_subject(task)
    out: list[dict] = []
    seen: set[str] = set()

    def add(question: str, why: str) -> None:
        q = question if question.endswith("?") else question + "?"
        key = re.sub(r"\W+", " ", q.lower()).strip()
        if key in seen or len(out) >= n:
            return
        seen.add(key)
        out.append(
            {
                "id": f"S{len(out) + 1}",
                "question": q,
                "why_it_matters": why,
                "lens": lenses[len(out) % len(lenses)],
            }
        )

    for template in seeds:
        add(
            template.format(task=subject),
            "Could change the final recommendation if answered well.",
        )
        if len(out) >= n:
            break

    for angle in EXTRA_ANGLES:
        if len(out) >= n:
            break
        add(
            f"What is the truth about {angle.format(task=subject)}",
            "Fills a high-value flank not covered by the base seeds.",
        )

    # Absolute fallback to hit exact count without duplicates.
    k = 1
    while len(out) < n:
        add(
            f"What overlooked constraint #{k} most affects decisions on {subject}",
            "Synthetic filler stream to satisfy depth knob; replace if domain-specific angles exist.",
        )
        k += 1

    if n >= 2:
        out[1]["lens"] = "risk"
    return out


def plan(task: str, depth: str, mode: str | None) -> dict:
    depth = depth.lower()
    if depth not in DEPTHS:
        raise SystemExit(f"unknown depth {depth}; choose {list(DEPTHS)}")
    knobs = DEPTHS[depth]
    resolved_mode = detect_mode(task, mode)
    lenses = LENSES[: knobs["PARALLEL_LENSES"]]
    streams = build_streams(task, resolved_mode, knobs["SUBQUESTIONS"])
    return {
        "task": task,
        "mode": resolved_mode,
        "depth": depth,
        "knobs": knobs,
        "lenses": lenses,
        "streams": streams,
        "pipeline": [
            "ORIENT",
            "DECOMPOSE",
            "EXECUTE",
            "EXTRACT",
            "VERIFY",
            "CRITIC",
            "LOOP",
            "SYNTHESIZE",
        ],
        "output_contract": [
            "direct_answer_first",
            "tagged_material_claims",
            "risks_and_unknowns",
            "metadata_footer",
        ],
    }


def to_markdown(p: dict) -> str:
    lines = [
        "# yb5 plan",
        "",
        f"**Task:** {p['task']}",
        f"**Mode:** `{p['mode']}` · **Depth:** `{p['depth']}`",
        "",
        "## Knobs",
        "```",
        json.dumps(p["knobs"], indent=2),
        "```",
        "",
        "## Lenses",
        ", ".join(f"`{x}`" for x in p["lenses"]),
        "",
        "## Streams",
    ]
    for s in p["streams"]:
        lines.append(f"- **{s['id']}** [{s['lens']}] {s['question']}")
    lines += [
        "",
        "## Pipeline",
        " -> ".join(p["pipeline"]),
        "",
        "## Footer template",
        "```",
        "---",
        (
            f"yb5 | depth={p['depth']} | streams={p['knobs']['SUBQUESTIONS']} | "
            f"rounds<= {p['knobs']['MAX_ROUNDS']} | verifiers={p['knobs']['VERIFIER_VOTES']} | "
            f"drafts={p['knobs']['SYNTHESIS_DRAFTS']}"
        ),
        f"survived=?/? | bumped=no | mode={p['mode']}",
        "weakest: ",
        "next_token_spend: ",
        "```",
    ]
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Emit a yb5 work plan")
    parser.add_argument("--task", required=True, help="User task / topic")
    parser.add_argument("--depth", default="standard", choices=list(DEPTHS))
    parser.add_argument("--mode", default=None, choices=list(MODE_SEEDS))
    parser.add_argument("--json", action="store_true", help="Print JSON instead of Markdown")
    args = parser.parse_args(argv)
    p = plan(args.task, args.depth, args.mode)
    if args.json:
        json.dump(p, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        sys.stdout.write(to_markdown(p))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
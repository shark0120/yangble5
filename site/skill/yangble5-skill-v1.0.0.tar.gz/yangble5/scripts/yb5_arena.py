#!/usr/bin/env python3
"""yb5 arena — single-shot vs multi-depth runtime (offline).

Uses yb5_runtime closed-loop simulator so deeper knobs must change outcomes.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))
from yb5_quality_fire import evaluate  # noqa: E402
from yb5_runtime import run_runtime  # noqa: E402
import yb5_prompt_assemble as asm  # noqa: E402
import yb5_stable_pack as sp  # noqa: E402


def lcp_len(a: str, b: str) -> int:
    n = min(len(a), len(b))
    i = 0
    while i < n and a[i] == b[i]:
        i += 1
    return i


def single_shot_artifact(topic: str) -> str:
    return (
        f"Certainly, regarding {topic}, the answer is obvious and should be shipped immediately. "
        f"All risks are manageable and no further analysis is required."
    )


def main(argv=None) -> int:
    import os as _os
    _os.environ["YB5_QUIET"] = "1"
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--topic", default="adopting event sourcing in checkout")
    args = parser.parse_args(argv)

    sp.write_pack()
    topic = args.topic
    depths = ["lite", "standard", "max", "insane", "omega"]

    rows = []
    ss = single_shot_artifact(topic)
    ss_eval = evaluate(ss, "standard")
    rows.append({
        "contender": "single_shot",
        "depth": "none",
        "quality_pass": ss_eval["pass"],
        "quality_avg": ss_eval["average"],
        "findings_total": 0,
        "hard_fails": ss_eval.get("hard_fails"),
    })

    prev_q = None
    monotone = True
    prev_findings = -1
    findings_nondecreasing = True
    for d in depths:
        rr = run_runtime(topic, d)
        # cache assembly continuity
        p0 = asm.assemble(topic, None, None)
        p1 = asm.assemble(topic, "elite.md", "yb5 RESUME run=arena stage=EXECUTE")
        p2 = asm.assemble(topic, "infinity.md", "yb5 RESUME run=arena stage=OMEGA")
        prefix = asm.stable_prefix()
        lcp_ratio = min(lcp_len(p0, p1), lcp_len(p0, p2)) / max(len(p0), 1)
        qavg = float(rr.quality.get("average") or 0)
        cavg = float(rr.quality.get("composite") or rr.metadata.get("composite") or 0)
        ft = int(rr.metadata.get("findings_total") or 0)
        row = {
            "contender": "yb5",
            "depth": d,
            "quality_pass": bool(rr.gate.get("pass")),
            "quality_avg": qavg,
            "composite": cavg,
            "min_avg_required": rr.quality.get("min_avg"),
            "findings_total": ft,
            "critic_rounds": rr.critic_rounds,
            "cache_lcp_ratio": round(lcp_ratio, 6),
            "prefix_integrity": p0.startswith(prefix) and p1.startswith(prefix) and p2.startswith(prefix),
            "omega": rr.omega,
            "hard_fails": rr.quality.get("hard_fails"),
        }
        if prev_q is not None and cavg + 1e-9 < prev_q:
            monotone = False
        if prev_findings >= 0 and ft < prev_findings:
            findings_nondecreasing = False
        prev_q = cavg
        prev_findings = ft
        rows.append(row)

    f5_rows = [r for r in rows if r["contender"] == "yb5"]
    best = max(f5_rows, key=lambda r: (r.get("composite", 0), r["quality_avg"], r["findings_total"]))
    lite_row = next(r for r in f5_rows if r["depth"] == "lite")
    std_row = next(r for r in f5_rows if r["depth"] == "standard")
    omega_row = next(r for r in f5_rows if r["depth"] == "omega")
    lite_f = lite_row["findings_total"]
    omega_f = omega_row["findings_total"]
    lite_q = float(lite_row["quality_avg"])
    std_q = float(std_row["quality_avg"])
    omega_q = float(omega_row["quality_avg"])
    lite_c = float(lite_row.get("composite") or 0)
    std_c = float(std_row.get("composite") or 0)
    max_c = float(next(r for r in f5_rows if r["depth"] == "max").get("composite") or 0)
    insane_c = float(next(r for r in f5_rows if r["depth"] == "insane").get("composite") or 0)
    omega_c = float(omega_row.get("composite") or 0)
    result = {
        "ts": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "topic": topic,
        "rows": rows,
        "single_shot_avg": ss_eval["average"],
        "best_yb5": best,
        "delta_best_minus_single": round(best["quality_avg"] - ss_eval["average"], 3),
        "monotone_nondecreasing_quality": monotone,
        "findings_nondecreasing": findings_nondecreasing,
        "findings_lite": lite_f,
        "findings_omega": omega_f,
        "quality_lite": lite_q,
        "quality_standard": std_q,
        "quality_omega": omega_q,
        "composite_lite": lite_c,
        "composite_standard": std_c,
        "composite_max": max_c,
        "composite_insane": insane_c,
        "composite_omega": omega_c,
        "all_yb5_prefix_integrity": all(r.get("prefix_integrity") for r in f5_rows),
        "pass": (
            best["quality_avg"] > ss_eval["average"] + 0.5
            and all(r.get("cache_lcp_ratio", 0) >= 0.999 for r in f5_rows)
            and all(r.get("prefix_integrity") for r in f5_rows)
            and findings_nondecreasing
            and omega_f > lite_f
            and std_c > lite_c + 0.5
            and max_c > std_c + 0.2
            and insane_c > max_c + 0.2
            and omega_c > insane_c + 0.2
            and any(r["depth"] == "omega" for r in f5_rows)
        ),
        "method": "runtime closed-loop + quality_fire + cache LCP; no model sampling",
    }

    try:
        repo_root = ROOT.parents[2] if (ROOT.parents[2] / "AGENTS.md").exists() else Path.cwd()
        out_dir = repo_root / ".yb5" / "cache-evidence"
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f"arena-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}.json"
        out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        result["evidence_path"] = str(out.resolve())
    except OSError:
        pass

    if args.json:
        json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        status = "PASS" if result["pass"] else "FAIL"
        print(f"yb5_arena: {status}")
        print(f"  single_shot_avg={result['single_shot_avg']}")
        print(f"  best_yb5={result['best_yb5']['depth']} avg={result['best_yb5']['quality_avg']}")
        print(f"  delta={result['delta_best_minus_single']}")
        print(f"  findings lite->omega: {lite_f}->{omega_f}")
        print(f"  monotone_quality={monotone} findings_nondecreasing={findings_nondecreasing}")
        for r in rows:
            print(
                f"  - {r['contender']:10} depth={str(r['depth']):8} "
                f"avg={r['quality_avg']} comp={r.get('composite')} pass={r['quality_pass']} findings={r.get('findings_total')} "
                f"lcp={r.get('cache_lcp_ratio')}"
            )
        if result.get("evidence_path"):
            print(f"  evidence: {result['evidence_path']}")
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

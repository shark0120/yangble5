#!/usr/bin/env python3
"""Assemble yb5 prompts for maximum multi-turn prefix cache hits.

Order (strict):
  1) STABLE_PACK  (byte-frozen)
  2) USER         (user message only)
  3) INTERNAL     (resume + stage_focus pointer; no reference bodies)
"""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = Path(__file__).resolve().parent
PACK = SCRIPTS / "stable_pack.txt"


def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def ensure_pack() -> str:
    if not PACK.exists():
        sys.path.insert(0, str(SCRIPTS))
        import yb5_stable_pack as sp  # type: ignore

        sp.write_pack()
    text = PACK.read_text(encoding="utf-8")
    if not text.endswith("\n"):
        text += "\n"
    return text


def stable_prefix() -> str:
    return ensure_pack()


def assemble(user_text: str, stage_ref: str | None = None, resume_line: str | None = None) -> str:
    pack = stable_prefix().rstrip() + "\n"
    user = (user_text or "").strip()
    parts = [pack.rstrip(), "", "# USER", user, ""]
    internal_lines = ["# INTERNAL"]
    if resume_line:
        internal_lines.append(resume_line.strip())
    if stage_ref:
        focus = stage_ref.strip().replace("\\", "/").split("/")[-1]
        internal_lines.append(f"stage_focus={focus}")
        internal_lines.append("stage_body=in_stable_pack")
    if len(internal_lines) > 1:
        parts.extend(internal_lines)
        parts.append("")
    return "\n".join(parts)


def main(argv=None) -> int:
    # Force UTF-8 stdout: the assembled pack contains non-cp950 chars (e.g. U+2265),
    # which crash on a legacy Windows console codepage otherwise.
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass
    parser = argparse.ArgumentParser()
    parser.add_argument("--text", required=True)
    parser.add_argument("--stage-ref", default=None)
    parser.add_argument("--resume-line", default=None)
    parser.add_argument("--hash", action="store_true")
    args = parser.parse_args(argv)
    out = assemble(args.text, args.stage_ref, args.resume_line)
    sys.stdout.write(out)
    if args.hash:
        print("sha256=" + sha256_text(out))
        print("prefix_sha256=" + sha256_text(stable_prefix()))
        print("prefix_len=" + str(len(stable_prefix())))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
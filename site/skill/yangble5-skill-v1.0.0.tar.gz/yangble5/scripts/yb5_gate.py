#!/usr/bin/env python3
"""Ship gate for yb5 artifacts.

Wraps the structural scorer and enforces autonomy ship rules.
Exit 0 = PASS (may ship). Exit 1 = FAIL (must bump/continue).

Usage:
  python yb5_gate.py --input report.md --min-avg 4.0
  python yb5_gate.py --input report.md --run <run_dir>   # also updates state
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from yb5_score import score  # noqa: E402


FOOTER_GATE = re.compile(r"gate:\s*(PASS|FAIL)\b", re.I)
KILL = re.compile(r"\b(kill[- ]?criteria|what would change|rollback|stop if)\b", re.I)


def load_text(path: Path | None, stdin: bool) -> str:
    if stdin:
        return sys.stdin.read()
    if path is None:
        raise SystemExit("provide --input or --stdin")
    return path.read_text(encoding="utf-8")


def extra_checks(text: str) -> list[str]:
    fails = []
    if not FOOTER_GATE.search(text):
        # soft: recommend but do not hard-fail if other footer present; still advice
        pass
    if not KILL.search(text):
        # decision usefulness helper — only flag if also no recommendation words handled by scorer
        pass
    # hard: must not claim PASS in footer if we are failing overall — checked later
    return fails


def maybe_update_run(run_dir: Path | None, passed: bool, result: dict) -> None:
    if run_dir is None:
        return
    script = Path(__file__).resolve().parent / "yb5_state.py"
    avg = result.get("average")
    args = [
        sys.executable,
        str(script),
        "--run",
        str(run_dir),
        "gate",
        "--pass" if passed else "--fail",
        "--avg",
        str(avg),
    ]
    subprocess.run(args, check=False)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="yb5 ship gate")
    parser.add_argument("--input", type=Path, default=None)
    parser.add_argument("--stdin", action="store_true")
    parser.add_argument("--min-avg", type=float, default=4.0)
    parser.add_argument("--run", type=Path, default=None, help="Optional run dir to update state")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--require-gate-line", action="store_true", help="Require gate: PASS|FAIL in footer")
    args = parser.parse_args(argv)

    text = load_text(args.input, args.stdin)
    result = score(text)
    avg = float(result["average"])
    structural_pass = bool(result["pass"]) and avg >= args.min_avg

    reasons = list(result.get("advice") or [])
    if args.require_gate_line and not FOOTER_GATE.search(text):
        structural_pass = False
        reasons.append("Missing `gate: PASS|FAIL` line in footer.")

    # Autonomy residue rule: standard+ artifacts should show adversarial residue OR kill-criteria
    tags = result.get("checks", {}).get("tag_counts", {})
    weak = int(tags.get("UNVERIFIED") or 0) + int(tags.get("CONTESTED") or 0) + int(tags.get("SUPPORTED") or 0)
    if structural_pass and weak == 0 and not KILL.search(text):
        structural_pass = False
        reasons.append("No adversarial residue (UNVERIFIED/CONTESTED/SUPPORTED) and no kill-criteria.")

    out = {
        "pass": structural_pass,
        "average": avg,
        "min_avg": args.min_avg,
        "axes": result.get("axes"),
        "auto_bump": (not structural_pass),
        "advice": reasons,
        "checks": result.get("checks"),
    }

    maybe_update_run(args.run, structural_pass, out)

    if args.json:
        json.dump(out, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        status = "PASS" if structural_pass else "FAIL"
        print(f"yb5_gate: {status}  avg={avg}  min={args.min_avg}  auto_bump={not structural_pass}")
        for k, v in (result.get("axes") or {}).items():
            print(f"  {k}: {v}/5")
        print("advice:")
        for tip in reasons:
            print(f"  - {tip}")
        if not structural_pass:
            print("action: BUMP weakest axis and continue autonomy loop (do not stop)")
    return 0 if structural_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())

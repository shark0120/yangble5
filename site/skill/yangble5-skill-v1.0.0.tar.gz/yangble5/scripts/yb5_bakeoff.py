#!/usr/bin/env python3
"""yb5 bake-off — real head-to-head with anti-gaming substance scoring.

`yb5_quality_fire.py` is a STRUCTURAL proxy: a shape-only artifact (every header
present, bodies empty, sim:// evidence) can score avg 5.0 / composite 100. That number
does not mean you beat a frontier reasoner.

This harness pits a CHALLENGER artifact (e.g. our grok4.5+codex run) against an OPPONENT
artifact (e.g. a native frontier-model baseline) and scores SUBSTANCE with anti-gaming detectors,
then declares a winner. A structure-win / substance-loss is reported honestly.

IMPORTANT — the honesty this tool enforces on ITSELF:
  The substance score is a HEURISTIC FLOOR, not an authoritative quality verdict. An
  adversarial red-team proved that fluent, DECORATED VACUITY (real-looking dates, metrics,
  URLs, file paths, and hedge keywords bolted onto tautologies or content-free prose) can
  still fool surface-token counting. Regex cannot judge whether a claim carries information.
  So: heuristic score = necessary, not sufficient. The AUTHORITATIVE substance verdict is an
  LLM-judge pass (the grok4.5 orchestrator's job) — see `judge_prompt()` / --emit-judge-prompt
  and references/grok-codex.md. The `decorated_vacuity` flag marks artifacts the heuristic
  refuses to clear on its own.

Usage:
  python yb5_bakeoff.py --challenger ours.md --opponent baseline.md
  python yb5_bakeoff.py --challenger-text "..." --opponent-text "..." --json
  python yb5_bakeoff.py --challenger ours.md --opponent baseline.md --emit-judge-prompt
  python yb5_bakeoff.py --demo
  python yb5_bakeoff.py --selftest
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

# Defensive import: quality_fire is rewritten frequently by the self-evolution loop.
try:  # pragma: no cover - import guard
    from yb5_quality_fire import evaluate as _qf_evaluate  # type: ignore
except Exception:  # pragma: no cover
    _qf_evaluate = None

# ---- regexes -------------------------------------------------------------

HEADER_RE = re.compile(r"^\s{0,3}#{1,6}\s+(.*)$", re.M)
SECTION_KEYS = (
    "bottom line", "finding", "red-team", "redteam", "disconfirm", "kill-criteria",
    "kill criteria", "unknown", "implementation", "steelman", "pre-mortem", "premortem",
    "risk", "recommendation", "trade", "option",
)
TAG_RE = re.compile(r"\b(VERIFIED|SUPPORTED|UNVERIFIED|CONTESTED)\b")
URL_RE = re.compile(r"https?://[^\s)\]]+")
PLACEHOLDER_HOST_RE = re.compile(r"(example\.(com|org|net)|localhost|foo\.bar|your-domain|placeholder)", re.I)
FAKE_HANDLE_RE = re.compile(r"(sim://|\bTODO\b|\blorem\b|\bplaceholder\b|\bXXX\b|<fill[-_ ]?in>)", re.I)
FILE_PATH_RE = re.compile(r"\b[\w./-]+\.(?:py|ts|tsx|js|jsx|md|json|ya?ml|go|rs|sql|sh|toml|cfg)\b")
BACKTICK_RE = re.compile(r"`[^`\n]{2,}`")
TEST_SIGNAL_RE = re.compile(r"\b(pytest|npm test|go test|cargo test|exit code|exit 0|exit 1|returncode|tests?\s+(?:pass|fail)|assert)\b", re.I)
DATE_RE = re.compile(r"\b\d{4}-\d{2}-\d{2}\b")
NUM_UNIT_RE = re.compile(r"\b(\d+(?:\.\d+)?)\s?(ms|s|sec|%|x|mb|gb|kb|k|h|hr|hrs|hours|days|rps|qps|req|p50|p95|p99|bp|bps|usd|\$)\b", re.I)
CODE_FENCE_RE = re.compile(r"```")
SCOPED_RE = re.compile(r"\b(UNVERIFIED|CONTESTED|SUPPORTED|under (?:pilot |test )?conditions?|only if|scoped to|conditional on|residual risk|what would change my mind|kill[- ]criteria|rollback|abort if|UNKNOWN|open question)\b", re.I)
SWAGGER_RE = re.compile(r"\b(obviously|certainly|guaranteed|no risk|zero risk|always works|no further analysis|ship immediately|trivially|undoubtedly|clearly the best|risk[- ]free|100%\s+safe)\b", re.I)
SENT_SPLIT_RE = re.compile(r"[.!?]\s+|\n+")
REAL_HOST_URL_RE = re.compile(r"https?://(?!(?:www\.)?(?:example\.(?:com|org|net)|localhost))[^\s)\]]+", re.I)
WORD_RE = re.compile(r"[A-Za-z][A-Za-z-]{4,}")  # content-ish words, len>=5
NUM_TOKEN_RE = re.compile(r"\b\d+(?:\.\d+)?\b")

# Vacuity register: abstract nouns + multiword filler that carry little decision information.
ABSTRACT_NOUNS = {
    "consideration", "considerations", "initiative", "circumstance", "circumstances",
    "posture", "tradeoff", "tradeoffs", "relevance", "direction", "matter", "degree",
    "envelope", "dynamics", "juncture", "thread", "threads", "picture", "reading",
    "contour", "contours", "tension", "geometry", "narrative", "framing", "clarity",
    "deliberation", "optionality", "bearing", "coherence", "impression", "impressions",
    "cadence", "premise", "premises", "posture", "prudence", "nuance",
}
FILLER_PHRASES = (
    "under consideration", "as a whole", "sits at", "interesting juncture", "threads of",
    "prudent posture", "continue to unfold", "remaining attentive", "the present reading",
    "on balance", "less a verdict", "the path forward", "balance the tradeoffs",
    "conditional on how", "worth sitting with", "the degree to which", "value judgment rather",
    "abstract uncertainty", "cheap to be wrong", "the whole reading", "quiet costs",
    "measured attention", "broadly consistent direction", "resisted tidy summary",
    "tidy conclusions", "smooth narrative", "the state it is already in", "the ratio it holds",
    "operating envelope", "generally expected", "the window it was taken in",
    "genuinely in tension", "no single obvious direction", "hold the present reading",
)


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, x))


def _sentences(text: str) -> list[str]:
    return [re.sub(r"\s+", " ", s).strip() for s in SENT_SPLIT_RE.split(text) if len(s.strip()) >= 20]


# ---- structural / surface sub-metrics -----------------------------------

def _sections(text: str) -> list[tuple[str, str]]:
    matches = list(HEADER_RE.finditer(text))
    out: list[tuple[str, str]] = []
    for i, m in enumerate(matches):
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        out.append((m.group(1).strip(), text[start:end].strip()))
    return out


def _is_meaningful(header: str) -> bool:
    h = header.lower()
    return any(k in h for k in SECTION_KEYS)


def section_body_density(text: str, min_body: int = 120) -> tuple[float, int, int]:
    secs = [(h, b) for (h, b) in _sections(text) if _is_meaningful(h)]
    if len(secs) >= 2:
        bodied = sum(1 for _, b in secs if len(b) >= min_body)
        return bodied / len(secs), bodied, len(secs)
    paras = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    if not paras:
        return 0.0, 0, 0
    bodied = sum(1 for p in paras if len(p) >= min_body)
    return _clamp01(bodied / max(3, len(paras))), bodied, len(paras)


def evidence_reality(text: str) -> tuple[float, int, int]:
    # DISTINCT handles only — decorative repetition of the same token does not inflate.
    real_set = set()
    real_set.update(REAL_HOST_URL_RE.findall(text))
    real_set.update(FILE_PATH_RE.findall(text))
    real_set.update(m.lower() for m in (t[0] if isinstance(t, tuple) else t for t in TEST_SIGNAL_RE.findall(text)))
    real_set.update(BACKTICK_RE.findall(text)[:8])
    real = len(real_set)
    fake = len(FAKE_HANDLE_RE.findall(text)) + len(PLACEHOLDER_HOST_RE.findall(text))
    score = real / (real + 2 * fake + 1)
    presence = _clamp01(real / 6.0)
    return _clamp01(0.6 * score + 0.4 * presence), real, fake


def specificity(text: str) -> float:
    nums = [n for n, _ in NUM_UNIT_RE.findall(text)]
    n = 0
    n += len(DATE_RE.findall(text))
    n += len(nums)
    n += len(CODE_FENCE_RE.findall(text)) // 2
    n += min(6, len(set(FILE_PATH_RE.findall(text))))
    per_1k = n / max(1.0, len(text) / 1000.0)
    raw = _clamp01(per_1k / 8.0)
    # Diversity gate: repeating the same number (e.g. "480 ... 480 ... 480") is decoration,
    # not specificity. Scale by the distinct-ratio of numeric tokens.
    all_nums = NUM_TOKEN_RE.findall(text)
    if len(all_nums) >= 4:
        diversity = len(set(all_nums)) / len(all_nums)
        raw *= 0.4 + 0.6 * diversity
    return _clamp01(raw)


def non_boilerplate(text: str) -> tuple[float, float]:
    sents = [s.lower() for s in _sentences(text)]
    if len(sents) < 4:
        return 1.0, 0.0
    repetition = (len(sents) - len(set(sents))) / len(sents)
    return _clamp01(1.0 - repetition), repetition


def calibration_balance(text: str) -> tuple[float, int, int]:
    scoped = len(SCOPED_RE.findall(text))
    swagger = len(SWAGGER_RE.findall(text))
    base = scoped / (scoped + 2 * swagger + 1)
    presence = _clamp01(scoped / 4.0)
    return _clamp01(0.6 * base + 0.4 * presence), scoped, swagger


# ---- the anti-vacuity sub-metric (the real defense) ----------------------

def concreteness(text: str) -> tuple[float, dict]:
    """Penalize tautology/self-reference and abstract filler — the vacuity signatures.

    This is what surface-token counting misses: a claim can be dense with dates, metrics,
    URLs and hedges yet carry zero information (restating its own inputs, or fluent abstraction).
    """
    sents = _sentences(text)
    n = max(1, len(sents))

    # 1) intra-sentence self-reference: a content token repeated inside one sentence
    #    ("p99 of 480ms tracked the reference p99 of 480ms"; "the ratio it holds when equal").
    #    Tokens include words (len>=4), number-units (480ms, 12%, 3x, 60s) and pXX latency tags.
    tautological = 0
    for s in sents:
        low = s.lower()
        toks = re.findall(r"[a-z]{4,}", low) + re.findall(r"\d+\s?[a-z%]{1,4}", low) + re.findall(r"p\d{2,3}", low)
        rep = len(toks) - len(set(toks))
        if rep >= 2:
            tautological += 1
    tautology_ratio = tautological / n

    # 2) abstract-noun + filler-phrase density (the fluent-vacuity register)
    low = text.lower()
    abstract_hits = sum(len(re.findall(r"\b" + re.escape(w) + r"\b", low)) for w in ABSTRACT_NOUNS)
    filler_hits = sum(low.count(p) for p in FILLER_PHRASES)
    abstract_density = (abstract_hits + 2 * filler_hits) / max(10.0, float(n))

    score = _clamp01(1.0 - 0.8 * tautology_ratio - min(0.75, abstract_density))
    return score, {
        "tautology_ratio": round(tautology_ratio, 3),
        "abstract_noun_hits": abstract_hits,
        "filler_phrase_hits": filler_hits,
        "abstract_density": round(abstract_density, 3),
        "sentences": n,
    }


SUBSTANCE_WEIGHTS = {
    "section_body_density": 0.13,
    "evidence_reality": 0.20,
    "specificity": 0.10,
    "non_boilerplate": 0.10,
    "calibration_balance": 0.07,
    "concreteness": 0.40,
}


def structure_average(text: str, depth: str) -> tuple[float, dict]:
    if _qf_evaluate is not None:
        try:
            r = _qf_evaluate(text, depth)
            return float(r.get("average") or 0.0), dict(r)
        except Exception:
            pass
    tags = bool(TAG_RE.search(text))
    footer = bool(re.search(r"yb5\s*\|", text, re.I)) and bool(re.search(r"gate:\s*(PASS|FAIL)", text, re.I))
    length_ok = 400 <= len(text) <= 120_000
    avg = 2.0 + (1.5 if tags else 0) + (1.0 if footer else 0) + (0.5 if length_ok else 0)
    return min(5.0, avg), {"average": min(5.0, avg), "fallback": True}


def scorecard(text: str, depth: str = "max", label: str = "artifact") -> dict:
    sbd, bodied, present = section_body_density(text)
    ev, real, fake = evidence_reality(text)
    spec = specificity(text)
    nb, repetition = non_boilerplate(text)
    cal, scoped, swagger = calibration_balance(text)
    conc, conc_detail = concreteness(text)
    parts = {
        "section_body_density": sbd,
        "evidence_reality": ev,
        "specificity": spec,
        "non_boilerplate": nb,
        "calibration_balance": cal,
        "concreteness": conc,
    }
    substance = 5.0 * sum(parts[k] * w for k, w in SUBSTANCE_WEIGHTS.items())
    struct_avg, struct_detail = structure_average(text, depth)
    combined = 0.35 * struct_avg + 0.65 * substance

    flags: list[str] = []
    if present >= 2 and sbd < 0.5:
        flags.append("empty_sections")
    if fake > 0 and fake >= real:
        flags.append("fake_evidence")
    if repetition >= 0.2:
        flags.append("boilerplate_padding")
    if swagger > scoped:
        flags.append("swagger")
    if (struct_avg - substance) >= 1.5:
        flags.append("structure_over_substance")
    # The key adversarial catch: lots of surface tokens but low concreteness ->
    # heuristic cannot certify this; it must go to the LLM judge.
    surface_heavy = spec >= 0.45 or real >= 8 or ev >= 0.7
    if surface_heavy and conc < 0.6:
        flags.append("decorated_vacuity")
    if conc_detail["tautology_ratio"] >= 0.18:
        flags.append("tautology")

    # heuristic can "clear" an artifact only if it is substantive AND unflagged for vacuity.
    vacuity_flags = {"decorated_vacuity", "tautology", "empty_sections", "structure_over_substance"}
    heuristic_clear = substance >= 4.0 and not (set(flags) & vacuity_flags)

    return {
        "label": label,
        "structure_avg": round(struct_avg, 3),
        "substance": round(substance, 3),
        "combined": round(combined, 3),
        "heuristic_clear": heuristic_clear,
        "parts": {k: round(v, 3) for k, v in parts.items()},
        "signals": {
            "sections_bodied": bodied, "sections_present": present,
            "evidence_real": real, "evidence_fake": fake,
            "repetition_ratio": round(repetition, 3),
            "scoped_claims": scoped, "swagger_claims": swagger,
            **conc_detail,
        },
        "gaming_flags": flags,
        "structure_detail": {k: struct_detail.get(k) for k in ("average", "composite", "pass", "weakest") if k in struct_detail},
    }


CAVEAT = (
    "substance is a HEURISTIC FLOOR (necessary, not sufficient); regex cannot judge information "
    "content, so decorated vacuity can survive. Authoritative substance verdict = LLM judge "
    "(orchestrator). Treat any 'decorated_vacuity'/'tautology' flag as: escalate to judge."
)


def judge_prompt(challenger: str, opponent: str) -> str:
    """Emit the authoritative substance judgement prompt for the grok4.5 orchestrator."""
    return (
        "# yb5 substance judge (authoritative layer)\n\n"
        "You are an adversarial substance judge. The offline heuristic (yb5_bakeoff) only "
        "counts surface tokens and can be fooled by fluent, decorated vacuity. Ignore surface "
        "polish. Judge ONLY whether each artifact carries decision-relevant INFORMATION: real "
        "mechanisms, falsifiable claims bound to real evidence, non-tautological reasoning, and "
        "kill-criteria a team could actually act on.\n\n"
        "For EACH artifact, score 0-5 on: information (not restatement of its own inputs), "
        "evidence-truth (do the cited handles plausibly support the claim, or are they decoration), "
        "decision-usefulness, and adversarial-hardness. Then pick a winner and name the single "
        "strongest reason. Penalize any artifact that reads as tautology or content-free abstraction "
        "no matter how many dates/metrics/URLs it cites.\n\n"
        "Return JSON: {\"challenger\":{...axes,avg},\"opponent\":{...axes,avg},\"winner\":\"challenger|opponent|tie\",\"reason\":\"...\"}\n\n"
        "## CHALLENGER\n" + challenger.strip() + "\n\n## OPPONENT\n" + opponent.strip() + "\n"
    )


def bakeoff(challenger: str, opponent: str, depth: str = "max") -> dict:
    ch = scorecard(challenger, depth, "challenger")
    op = scorecard(opponent, depth, "opponent")
    margin = round(ch["combined"] - op["combined"], 3)
    winner = "tie" if abs(margin) < 0.05 else ("challenger" if margin > 0 else "opponent")

    notes: list[str] = []
    if winner == "challenger" and ch["substance"] < op["substance"]:
        notes.append("challenger wins overall but LOSES on substance — margin is structure-driven; not a real quality win")
    if winner == "opponent" and ch["structure_avg"] >= op["structure_avg"] and ch["substance"] < op["substance"]:
        notes.append("challenger matched structure but lost on substance — do not quote the structural score as parity")
    for c, who in ((ch, "challenger"), (op, "opponent")):
        if "decorated_vacuity" in c["gaming_flags"]:
            notes.append(f"{who} flagged decorated_vacuity — high surface tokens, low concreteness; heuristic cannot certify. Run the LLM judge.")
        if "tautology" in c["gaming_flags"]:
            notes.append(f"{who} flagged tautology — claims restate their own inputs; likely low information.")
        if "fake_evidence" in c["gaming_flags"]:
            notes.append(f"{who} flagged fake_evidence — sim://placeholder handles instead of executor-produced evidence.")

    # The heuristic result is never authoritative on its own.
    needs_judge = (not ch["heuristic_clear"]) or (not op["heuristic_clear"]) or bool(
        {"decorated_vacuity", "tautology"} & (set(ch["gaming_flags"]) | set(op["gaming_flags"]))
    )

    return {
        "depth": depth,
        "winner": winner,
        "authoritative": False,
        "needs_llm_judge": needs_judge,
        "caveat": CAVEAT,
        "combined_margin": margin,
        "substance_margin": round(ch["substance"] - op["substance"], 3),
        "structure_margin": round(ch["structure_avg"] - op["structure_avg"], 3),
        "challenger": ch,
        "opponent": op,
        "notes": notes,
        "method": "heuristic floor: 0.35*structure + 0.65*substance; anti-vacuity flags; NOT a quality verdict — see caveat",
    }


# ---- demo / selftest fixtures -------------------------------------------

SHAPE_ONLY = """# Bottom line
Obviously ship immediately. No risk, guaranteed. VERIFIED VERIFIED VERIFIED.

## Findings
Finding. VERIFIED sim://primary/s1
Finding. VERIFIED sim://primary/s2

## Red-team / disconfirm
Disconfirm. sim://counter/s1

## Steelman
Steelman.

## Pre-mortem
Pre-mortem.

## Kill-criteria
Kill-criteria.

## Unknowns
Unknown.

Padding sentence that repeats to satisfy the length gate for the structural scorer.
Padding sentence that repeats to satisfy the length gate for the structural scorer.
Padding sentence that repeats to satisfy the length gate for the structural scorer.
Padding sentence that repeats to satisfy the length gate for the structural scorer.

See example.com/x for details. See example.com/y for details.

---
yb5 | depth=max | streams=12 | rounds=3 | verifiers=5 | drafts=3
survived=8/8 | bumped=no | mode=research | run=shape
weakest: none
next_token_spend: none
gate: PASS avg=5.0
redteam: clean
"""

# Fluent decorated vacuity: real-looking dates/metrics/URLs/paths + hedges bolted onto
# tautologies and abstraction. This is the adversarial class that broke the v1 scorer.
DECORATED_VACUITY = """# Bottom line
As of 2026-07-14 the matter under consideration sits at an interesting juncture, and the
measured p99 of 480ms tracked the reference p99 of 480ms, so the delta stayed inside the band
the delta is generally expected to occupy. UNVERIFIED, conditional on conditions continuing.

## Findings
- On 2026-07-13 the tier processed 480 rps against a reference of 480 rps and the ratio held at
  1x, which is the ratio it holds when the two are equal. SUPPORTED by `tests/load.py` (exit code 0)
  and the panel at https://grafana.obs.acme.io/d/lat covering the 60s window.
- The 2026-06-01 schema in `migrations/0042.sql` remains 0042 and has not changed since it became
  0042. CONTESTED only in that no measurement has contradicted the measurement. UNVERIFIED beyond.

## Red-team / disconfirm
The prudent posture is to hold the present reading lightly; the threads of relevance appear to
converge without resolving into a single obvious direction. Residual risk and open question remain.

## Steelman
Under the operating envelope observed, and only if it persists, continuing as-is dominates any
change whose benefit is unstated, conditional on how circumstances continue to unfold.

## Pre-mortem
Six months out the 480ms was always a restatement of the 480 rps input and carried no information,
and the dashboard at https://runbooks.acme.io/x kept reporting green because green was last observed.

## Kill-criteria
Abort if the p99 stops being 480ms while load stays 480 rps, scoped to the conditions above and no
other. Rollback is `bash ops/rollback.sh`, which returns the system to the state it is already in.

## Unknowns
Whether any 2026-07-14 number describes the system rather than its inputs remains UNVERIFIED, an
open question load-bearing and not measured outside the window it was taken in.

---
yb5 | depth=max | streams=12 | rounds=3 | verifiers=5 | drafts=3
survived=4/6 | bumped=yes | mode=architecture | run=decorated
weakest: decision_usefulness
next_token_spend: measure numbers outside their own window
gate: PASS avg=4.5
redteam: patched
"""

SUBSTANTIVE = """# Bottom line
Do not full-scale ship yet. Run a 30-day pilot behind a feature flag; expand only if the
bake-off decisive metric holds. VERIFIED the core path builds and passes tests; unit
economics remain UNVERIFIED under production load.

## Findings
- On checkout throughput: p99 held within 2-3x baseline at 480 rps in the staging run on
  2026-07-14, but only with the write-batcher enabled. SUPPORTED by `tests/load_checkout.py`
  (exit code 0). Without batching, p99 blew past 900ms. CONTESTED at peak.
- Migration is not backward compatible for events written before 2026-06-01; a shim is
  required. UNVERIFIED whether the shim covers replays. See `migrations/0042_events.sql`.
- Competitor shipped a comparable event-sourced checkout in Q1; recovery tooling is the moat,
  not the store itself. SUPPORTED by https://engineering.realvendor.io/posts/event-sourcing.

## Red-team / disconfirm
Missing-killer: no third-party measurement of replay latency under a cold cache — that single
number could flip the rollout. Incentive: the team proposing event sourcing also owns the
migration budget, so upside is likely overstated. Contradiction: the optimistic p99 and the
peak-load CONTESTED result cannot both hold at 900 rps.

## Steelman for shipping now
If a competitor lock-in window is real and each delayed month cedes irreversible integration
ground, shipping behind a flag with instrumentation could beat waiting — provided rollback is a
one-line flag flip and kill-criteria are live before the first real customer.

## Pre-mortem
Six months out this fails via silent replay drift: a poison event stalls a projection, the p99
alert never fires because it measures the happy path, and reconciliation runs weekly instead of
continuously. Early warning: projection lag > 60s, replay error rate > 1%, rollback drill fails.

## Implementation path
1. Encode acceptance in `tests/load_checkout.py` and `tests/replay_invariants.py`.
2. Run `pytest -q tests/replay_invariants.py` and keep the exit-code artifact.
3. Roll out behind `flags.event_sourcing_checkout`; rollback = disable the flag.

## Kill-criteria
Abort expansion if replay error rate exceeds 1% in the third-party bake-off, projection lag
exceeds 60s at 480 rps, or a rollback drill fails. Conditional on instrumentation being live.

## Unknowns
Cold-cache replay latency and the shim's coverage of pre-2026-06-01 events remain open
questions; both are load-bearing and currently UNVERIFIED.

---
yb5 | depth=max | streams=12 | rounds=3 | verifiers=5 | drafts=3
survived=2/6 | bumped=yes | mode=architecture | run=substantive
weakest: implementability
next_token_spend: cold-cache replay measurement
gate: PASS avg=4.5
redteam: patched
"""


def selftest() -> int:
    fails: list[str] = []

    # 1) real substance beats shape-only, shape-only flagged
    r1 = bakeoff(SUBSTANTIVE, SHAPE_ONLY, "max")
    if r1["winner"] != "challenger":
        fails.append(f"substantive should beat shape-only: {r1['winner']}")
    if "fake_evidence" not in r1["opponent"]["gaming_flags"]:
        fails.append(f"shape-only should be flagged fake_evidence: {r1['opponent']['gaming_flags']}")

    # 2) THE regression guard: fluent decorated vacuity must NOT clear the heuristic.
    r2 = bakeoff(SUBSTANTIVE, DECORATED_VACUITY, "max")
    dv = r2["opponent"]
    sub = r2["challenger"]
    if dv["heuristic_clear"]:
        fails.append(f"decorated vacuity wrongly CLEARED heuristic: substance={dv['substance']} flags={dv['gaming_flags']}")
    if "decorated_vacuity" not in dv["gaming_flags"] and "tautology" not in dv["gaming_flags"]:
        fails.append(f"decorated vacuity not flagged: {dv['gaming_flags']} concreteness={dv['parts']['concreteness']}")
    if not sub["heuristic_clear"]:
        fails.append(f"substantive artifact should clear heuristic: substance={sub['substance']} flags={sub['gaming_flags']}")
    if sub["substance"] <= dv["substance"]:
        fails.append(f"substantive should out-substance decorated vacuity: {sub['substance']} vs {dv['substance']}")
    if not r2["needs_llm_judge"]:
        fails.append("needs_llm_judge should be True when a contender is decorated vacuity")

    print("yb5_bakeoff selftest:")
    print(f"  substantive : substance={sub['substance']} concreteness={sub['parts']['concreteness']} clear={sub['heuristic_clear']} flags={sub['gaming_flags']}")
    print(f"  decorated   : substance={dv['substance']} concreteness={dv['parts']['concreteness']} clear={dv['heuristic_clear']} flags={dv['gaming_flags']}")
    print(f"  shape-only  : substance={r1['opponent']['substance']} flags={r1['opponent']['gaming_flags']}")
    if fails:
        print("FAIL")
        for f in fails:
            print("  -", f)
        return 1
    print("yb5_bakeoff: SELFTEST PASS")
    return 0


def _print_human(res: dict) -> None:
    ch, op = res["challenger"], res["opponent"]
    print(f"yb5_bakeoff: winner={res['winner'].upper()}  combined_margin={res['combined_margin']}  (authoritative=False)")
    print(f"  needs_llm_judge={res['needs_llm_judge']}")
    print(f"  {'axis':<22}{'challenger':>12}{'opponent':>12}")
    for k in ("combined", "substance", "structure_avg"):
        print(f"  {k:<22}{ch[k]:>12}{op[k]:>12}")
    print(f"  {'heuristic_clear':<22}{str(ch['heuristic_clear']):>12}{str(op['heuristic_clear']):>12}")
    print("  --- substance parts (challenger | opponent) ---")
    for k in SUBSTANCE_WEIGHTS:
        print(f"  {k:<22}{ch['parts'][k]:>12}{op['parts'][k]:>12}")
    print(f"  challenger flags: {ch['gaming_flags'] or 'none'}")
    print(f"  opponent   flags: {op['gaming_flags'] or 'none'}")
    if res["notes"]:
        print("  notes:")
        for n in res["notes"]:
            print("   -", n)
    print(f"  caveat: {res['caveat']}")


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="yb5 head-to-head bake-off (heuristic floor + LLM-judge protocol)")
    p.add_argument("--challenger", type=Path)
    p.add_argument("--opponent", type=Path)
    p.add_argument("--challenger-text")
    p.add_argument("--opponent-text")
    p.add_argument("--depth", default="max")
    p.add_argument("--json", action="store_true")
    p.add_argument("--emit-judge-prompt", action="store_true", help="print the authoritative LLM-judge prompt and exit")
    p.add_argument("--demo", action="store_true")
    p.add_argument("--selftest", action="store_true")
    args = p.parse_args(argv)

    if args.selftest:
        return selftest()
    if args.demo:
        ch_text, op_text = SUBSTANTIVE, DECORATED_VACUITY
    else:
        if args.challenger is not None:
            ch_text = args.challenger.read_text(encoding="utf-8")
        elif args.challenger_text is not None:
            ch_text = args.challenger_text
        else:
            raise SystemExit("provide --challenger/--challenger-text, or --demo/--selftest")
        if args.opponent is not None:
            op_text = args.opponent.read_text(encoding="utf-8")
        elif args.opponent_text is not None:
            op_text = args.opponent_text
        else:
            raise SystemExit("provide --opponent/--opponent-text, or --demo/--selftest")

    if args.emit_judge_prompt:
        sys.stdout.write(judge_prompt(ch_text, op_text))
        return 0

    res = bakeoff(ch_text, op_text, args.depth)
    if args.json:
        json.dump(res, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        _print_human(res)
    return 0 if res["winner"] != "opponent" else 1


if __name__ == "__main__":
    raise SystemExit(main())

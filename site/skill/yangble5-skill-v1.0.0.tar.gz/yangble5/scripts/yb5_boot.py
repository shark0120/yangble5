#!/usr/bin/env python3
"""Boot a yb5 autonomous run directory.

Creates .yb5/runs/<run_id>/ with meta, plan, state, ledger.
Does not call an LLM — the agent executes stages using this scaffold.

Usage:
  python yb5_boot.py --task "Due diligence on Acme" --depth max
  python yb5_boot.py --task "Fix flaky auth" --mode code --depth standard --run-root .yb5/runs
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

# Allow importing sibling planner helpers
sys.path.insert(0, str(Path(__file__).resolve().parent))
from yb5_plan import DEPTHS, detect_mode, plan  # noqa: E402


STAGES = [
    "ORIENT",
    "DECOMPOSE",
    "EXECUTE",
    "VERIFY",
    "CRITIC",
    "SYNTHESIZE",
    "GATE",
    "BUMP",
    "SHIP",
    "BLOCKED",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def slug(text: str, n: int = 24) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "-", text.strip().lower()).strip("-")
    return (s[:n] or "task").strip("-")


def task_hash(task: str) -> str:
    return hashlib.sha1(task.strip().encode("utf-8")).hexdigest()[:10]


def make_run_id(task: str) -> str:
    ts = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    return f"{ts}-{task_hash(task)}-{slug(task, 18)}"


def write_json(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def append_ledger(path: Path, event: dict) -> None:
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(event, ensure_ascii=False) + "\n")


def find_resumable(run_root: Path, thash: str) -> Path | None:
    if not run_root.exists():
        return None
    candidates: list[Path] = []
    for child in sorted(run_root.iterdir(), reverse=True):
        meta = child / "meta.json"
        state = child / "state.json"
        if not (child.is_dir() and meta.exists() and state.exists()):
            continue
        try:
            m = json.loads(meta.read_text(encoding="utf-8"))
            s = json.loads(state.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if m.get("task_hash") == thash and s.get("stage") not in {"SHIP", "BLOCKED"}:
            candidates.append(child)
    return candidates[0] if candidates else None


def boot(
    task: str,
    depth: str,
    mode: str | None,
    run_root: Path,
    resume: bool,
    fresh: bool,
) -> dict:
    depth = depth.lower()
    if depth not in DEPTHS:
        raise SystemExit(f"unknown depth {depth}; choose {list(DEPTHS)}")

    run_root.mkdir(parents=True, exist_ok=True)
    thash = task_hash(task)

    if resume and not fresh:
        existing = find_resumable(run_root, thash)
        if existing is not None:
            state = json.loads((existing / "state.json").read_text(encoding="utf-8"))
            meta = json.loads((existing / "meta.json").read_text(encoding="utf-8"))
            return {
                "resumed": True,
                "run_dir": str(existing.resolve()),
                "run_id": meta.get("run_id"),
                "stage": state.get("stage"),
                "depth": state.get("depth") or meta.get("depth"),
                "mode": meta.get("mode"),
                "message": f"Resumed run at stage={state.get('stage')}",
            }

    p = plan(task, depth, mode)
    run_id = make_run_id(task)
    run_dir = run_root / run_id
    run_dir.mkdir(parents=True, exist_ok=False)

    knobs = p["knobs"]
    streams = p["streams"]
    for s in streams:
        s["status"] = "open"

    meta = {
        "run_id": run_id,
        "task": task,
        "task_hash": thash,
        "mode": p["mode"],
        "depth": depth,
        "knobs": knobs,
        "lenses": p["lenses"],
        "created_at": utc_now(),
        "skill": "yb5",
        "autonomous": True,
    }
    state = {
        "run_id": run_id,
        "stage": "ORIENT",
        "depth": depth,
        "round": 0,
        "bumps": 0,
        "max_bumps": {"micro": 0, "lite": 1, "standard": 2, "max": 3, "insane": 4, "omega": 12}[depth],
        "open_streams": [s["id"] for s in streams],
        "done_streams": [],
        "claim_counts": {
            "VERIFIED": 0,
            "SUPPORTED": 0,
            "UNVERIFIED": 0,
            "CONTESTED": 0,
        },
        "gate": None,
        "blocked": None,
        "updated_at": utc_now(),
    }

    write_json(run_dir / "meta.json", meta)
    write_json(run_dir / "plan.json", p)
    # markdown plan for humans
    from yb5_plan import to_markdown

    (run_dir / "plan.md").write_text(to_markdown(p), encoding="utf-8")
    write_json(run_dir / "state.json", state)
    write_json(run_dir / "orient.json", {
        "mode": p["mode"],
        "goal": task,
        "audience": "skeptical decision-maker",
        "constraints": [],
        "depth": depth,
        "done_definition": [
            "material claims tagged",
            "adversarial verification performed",
            "gate pass avg>=4",
        ],
        "risk_if_wrong": "bad decision under false confidence",
        "tool_plan": ["search", "shell", "tests"] if p["mode"] in {"code", "debug"} else ["search", "read"],
    })
    (run_dir / "claims.jsonl").write_text("", encoding="utf-8")
    (run_dir / "ledger.jsonl").write_text("", encoding="utf-8")
    append_ledger(run_dir / "ledger.jsonl", {
        "ts": utc_now(),
        "stage": "BOOT",
        "event": "run_created",
        "depth": depth,
        "streams": len(streams),
    })
    # checklist the agent must drive
    checklist = {
        "stages": STAGES,
        "required_before_ship": [
            "all initial streams executed or explicitly skipped with reason",
            "material claims verified",
            "at least one critic pass",
            "best-of-N synthesis written to report.md",
            "yb5_gate.py PASS",
        ],
        "commands": {
            "status": f"python scripts/yb5_state.py --run \"{run_dir}\" status",
            "gate": f"python scripts/yb5_gate.py --input \"{run_dir / 'report.md'}\" --min-avg 4.0",
        },
    }
    write_json(run_dir / "checklist.json", checklist)

    return {
        "resumed": False,
        "run_dir": str(run_dir.resolve()),
        "run_id": run_id,
        "stage": "ORIENT",
        "depth": depth,
        "mode": p["mode"],
        "streams": len(streams),
        "knobs": knobs,
        "message": "Bootstrapped new autonomous run",
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Boot a yb5 autonomous run")
    parser.add_argument("--task", required=True)
    parser.add_argument("--depth", default="standard", choices=list(DEPTHS))
    parser.add_argument("--mode", default=None)
    parser.add_argument(
        "--run-root",
        default=str(Path.cwd() / ".yb5" / "runs"),
        help="Directory that holds run folders",
    )
    parser.add_argument("--resume", action="store_true", default=True, help="Resume unfinished same-task run (default)")
    parser.add_argument("--no-resume", action="store_true", help="Do not resume")
    parser.add_argument("--fresh", action="store_true", help="Force a new run")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    result = boot(
        task=args.task,
        depth=args.depth,
        mode=args.mode,
        run_root=Path(args.run_root),
        resume=(args.resume and not args.no_resume),
        fresh=args.fresh,
    )
    if args.json:
        json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        print(f"yb5 BOOT run={result['run_id']} depth={result['depth']} mode={result['mode']}")
        print(f"run_dir={result['run_dir']}")
        print(f"stage={result['stage']} resumed={result['resumed']}")
        if "streams" in result:
            print(f"streams={result['streams']}")
        print(result["message"])
        print("next: read references/autonomy.md and advance stages with yb5_state.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

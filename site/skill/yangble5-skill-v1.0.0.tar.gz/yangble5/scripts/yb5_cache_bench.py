#!/usr/bin/env python3
"""Benchmark structural cache-friendliness: naive vs yb5 (99.9 target)."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))
import yb5_prompt_assemble as asm  # noqa: E402
import yb5_stable_pack as sp  # noqa: E402

TARGET = 0.999


def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def lcp_len(a: str, b: str) -> int:
    n = min(len(a), len(b))
    i = 0
    while i < n and a[i] == b[i]:
        i += 1
    return i


def pairwise_min_lcp_ratio(prompts: list[str]) -> float:
    if len(prompts) < 2:
        return 1.0
    base = prompts[0]
    return min(lcp_len(base, p) / max(len(base), 1) for p in prompts[1:])


def naive_assemble(user_text: str, turn: int, stage_ref: str | None = None) -> str:
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    ts = datetime.now(timezone.utc).isoformat()
    parts = [
        f"# turn={turn} generated_at={ts} nonce={sha256_text(user_text + str(turn))[:16]}",
        f"# USER\n{user_text}",
        "# reshuffled skill body",
        "\n".join(sorted(skill.splitlines())),
    ]
    if stage_ref:
        ref = ROOT / "references" / stage_ref
        if ref.exists():
            parts.append(ref.read_text(encoding="utf-8"))
    return "\n\n".join(parts) + "\n"


def yb5_assemble(user_text: str, turn: int, stage_ref: str | None, resume: bool) -> str:
    resume_line = f"yb5 RESUME run=bench stage=S{turn}" if resume else None
    return asm.assemble(user_text, stage_ref, resume_line)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    sp.write_pack()

    user = "fix flaky auth race"
    turns = [
        (user, None),
        (user, "autonomy.md"),
        (user, "pipeline.md"),
        (user, "quality-rubric.md"),
        (user, "cache-protocol.md"),
        (user, "roles.md"),
        (user, "modes.md"),
    ]
    naive_prompts = [naive_assemble(t, i, ref) for i, (t, ref) in enumerate(turns)]
    f5_prompts = [yb5_assemble(t, i, ref, resume=(i > 0)) for i, (t, ref) in enumerate(turns)]
    naive_ratio = pairwise_min_lcp_ratio(naive_prompts)
    f5_ratio = pairwise_min_lcp_ratio(f5_prompts)
    prefix = asm.stable_prefix()
    f5_starts = all(p.startswith(prefix) for p in f5_prompts)
    naive_starts = all(p.startswith(prefix) for p in naive_prompts)
    integrity = all(lcp_len(prefix, p) >= len(prefix) for p in f5_prompts)
    lcp_chars_f5 = [lcp_len(f5_prompts[0], p) for p in f5_prompts[1:]]
    lcp_chars_naive = [lcp_len(naive_prompts[0], p) for p in naive_prompts[1:]]
    delta = f5_ratio - naive_ratio
    weighted = [lcp_len(f5_prompts[0], p) / max(len(p), 1) for p in f5_prompts[1:]]
    min_weighted = min(weighted) if weighted else 1.0
    result = {
        "ts": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "target": TARGET,
        "turns": len(turns),
        "naive": {
            "min_lcp_ratio": round(naive_ratio, 6),
            "starts_with_stable_prefix": naive_starts,
            "lcp_chars_vs_turn0": lcp_chars_naive,
            "prompt0_len": len(naive_prompts[0]),
        },
        "yb5": {
            "min_lcp_ratio": round(f5_ratio, 6),
            "min_weighted_lcp_ratio": round(min_weighted, 6),
            "starts_with_stable_prefix": f5_starts,
            "prefix_integrity": integrity,
            "lcp_chars_vs_turn0": lcp_chars_f5,
            "prompt0_len": len(f5_prompts[0]),
            "stable_prefix_len": len(prefix),
            "stable_prefix_sha256": sha256_text(prefix),
            "user_block_in_lcp": bool(lcp_chars_f5 and lcp_chars_f5[0] > len(prefix)),
        },
        "delta_min_lcp_ratio": round(delta, 6),
        "pass": bool(
            f5_ratio >= TARGET
            and f5_starts
            and integrity
            and delta >= 0.5
            and (not naive_starts)
            and min_weighted >= 0.99
        ),
        "thresholds": {
            "yb5_min_lcp_ratio": TARGET,
            "yb5_min_weighted_lcp_ratio": 0.99,
            "min_delta_over_naive": 0.5,
            "prefix_integrity": 1.0,
        },
        "method": "LCP(turn0,turn_i)/len(turn0); STABLE_PACK->USER->INTERNAL; stage pointers only.",
    }
    try:
        repo_root = ROOT.parents[2] if (ROOT.parents[2] / "AGENTS.md").exists() else Path.cwd()
        out_dir = repo_root / ".yb5" / "cache-evidence"
        out_dir.mkdir(parents=True, exist_ok=True)
        out = out_dir / f"bench-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}.json"
        out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        result["evidence_path"] = str(out.resolve())
    except OSError:
        pass
    if args.json:
        json.dump(result, sys.stdout, indent=2)
        sys.stdout.write("\n")
    else:
        status = "PASS" if result["pass"] else "FAIL"
        print(f"yb5_cache_bench: {status} (target>={TARGET})")
        print(f"  naive_min_lcp_ratio   = {result['naive']['min_lcp_ratio']}")
        print(f"  yb5_min_lcp_ratio  = {result['yb5']['min_lcp_ratio']}")
        print(f"  yb5_weighted_min   = {result['yb5']['min_weighted_lcp_ratio']}")
        print(f"  delta                 = {result['delta_min_lcp_ratio']}")
        print(f"  stable_prefix_len     = {result['yb5']['stable_prefix_len']}")
        print(f"  prefix_integrity      = {result['yb5']['prefix_integrity']}")
        print(f"  user_block_in_lcp     = {result['yb5']['user_block_in_lcp']}")
        if result.get("evidence_path"):
            print(f"  evidence: {result['evidence_path']}")
    return 0 if result["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
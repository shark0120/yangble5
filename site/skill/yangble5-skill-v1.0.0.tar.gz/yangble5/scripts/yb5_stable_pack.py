#!/usr/bin/env python3
"""Build/verify the frozen yb5 STABLE_PACK used for 99.9% prefix hits."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent
REFS = ROOT / "references"
OUT = SCRIPTS / "stable_pack.txt"
META = REFS / "stable_pack_meta.json"

REF_ORDER = [
    "always-on.md",
    "cache-protocol.md",
    "infinity.md",
    "elite.md",
    "redteam.md",
    "autonomy.md",
    "grok-codex.md",
    "pipeline.md",
    "roles.md",
    "modes.md",
    "quality-rubric.md",
]


def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def skill_stable_block() -> str:
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    begin = "<!-- CACHE_STABLE_PREFIX_BEGIN -->"
    end = "<!-- CACHE_STABLE_PREFIX_END -->"
    if begin not in skill or end not in skill:
        raise SystemExit("SKILL.md missing stable prefix markers")
    return skill.split(begin, 1)[1].split(end, 1)[0].strip() + "\n"


def build_pack() -> str:
    card = (SCRIPTS / "always_on_card.txt").read_text(encoding="utf-8")
    if not card.endswith("\n"):
        card += "\n"
    parts = [
        "# YB5_STABLE_PACK_BEGIN\n",
        "# byte-frozen protocol pack - do not edit by hand; run yb5_stable_pack.py --write\n",
        "\n## [CARD]\n",
        card,
        "\n## [SKILL_STABLE_PREFIX]\n",
        skill_stable_block(),
    ]
    for name in REF_ORDER:
        path = REFS / name
        text = path.read_text(encoding="utf-8")
        if not text.endswith("\n"):
            text += "\n"
        parts.append(f"\n## [REF:{name}]\n")
        parts.append(text)
    parts.append("# YB5_STABLE_PACK_END\n")
    return "".join(parts)


def write_pack() -> dict:
    pack = build_pack()
    OUT.write_text(pack, encoding="utf-8", newline="\n")
    card = (SCRIPTS / "always_on_card.txt").read_text(encoding="utf-8")
    if not card.endswith("\n"):
        card += "\n"
    meta = {
        "stable_pack_sha256": sha256_text(pack),
        "stable_pack_len": len(pack),
        "card_sha256": sha256_text(card),
        "refs": REF_ORDER,
        "path": "scripts/stable_pack.txt",
    }
    META.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8", newline="\n")
    return meta


def verify_pack() -> dict:
    if not OUT.exists():
        return {"pass": False, "detail": "stable_pack.txt missing"}
    current = build_pack()
    disk = OUT.read_text(encoding="utf-8")
    ok = current == disk
    return {
        "pass": ok,
        "detail": "stable_pack matches rebuild" if ok else "stable_pack DRIFT vs sources",
        "disk_sha256": sha256_text(disk),
        "rebuild_sha256": sha256_text(current),
        "len": len(disk),
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--verify", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if args.write or not OUT.exists():
        meta = write_pack()
        if args.json:
            json.dump({"wrote": True, **meta}, sys.stdout, indent=2)
            sys.stdout.write("\n")
        else:
            print(f"wrote {OUT} len={meta['stable_pack_len']} sha256={meta['stable_pack_sha256']}")
        if args.write and not args.verify:
            return 0
    rep = verify_pack()
    if args.json:
        json.dump(rep, sys.stdout, indent=2)
        sys.stdout.write("\n")
    else:
        print(f"yb5_stable_pack: {'PASS' if rep['pass'] else 'FAIL'} {rep['detail']} len={rep.get('len')}")
    return 0 if rep.get("pass") else 1


if __name__ == "__main__":
    raise SystemExit(main())
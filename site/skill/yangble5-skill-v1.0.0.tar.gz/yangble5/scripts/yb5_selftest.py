#!/usr/bin/env python3
"""Offline self-test for yb5 skill scripts (no network, no API key)."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
PY = sys.executable


def run(args: list[str], check: bool = True) -> subprocess.CompletedProcess:
    # Decode child stdout as UTF-8 (children emit UTF-8); the Windows locale codec
    # (e.g. cp950) would otherwise fail on CJK text in the always-on card.
    return subprocess.run(
        args, cwd=str(SCRIPTS), capture_output=True, text=True,
        encoding="utf-8", errors="replace", check=check,
    )


def main() -> int:
    failures: list[str] = []

    # cache card stable
    cp = run([PY, "yb5_cache_card.py", "--hash"])
    if "always-on card" not in cp.stdout or "sha256=" not in cp.stdout:
        failures.append("cache card missing/unstable output")
    cp2 = run([PY, "yb5_cache_card.py", "--hash"])
    if cp.stdout != cp2.stdout:
        failures.append("cache card not deterministic across calls")

    # plan unique streams
    cp = run([PY, "yb5_plan.py", "--task", "Due diligence on Acme robotics", "--depth", "max", "--json"])
    plan = json.loads(cp.stdout)
    qs = [s["question"] for s in plan["streams"]]
    if len(qs) != 12 or len(set(qs)) != 12:
        failures.append(f"plan streams unique/count failed: {len(qs)} unique={len(set(qs))}")
    if "Acme robotics" not in qs[0]:
        failures.append(f"plan subject peel failed: {qs[0]}")

    # score fail/pass
    cp = run([PY, "yb5_score.py", "--text", "Certainly this is fine."], check=False)
    if cp.returncode == 0:
        failures.append("score should fail thin text")

    good = """# Bottom line
Ship staged capital only. VERIFIED core tech exists; unit economics remain UNVERIFIED.

## Findings
- Pilot gross margin uses one customer. UNVERIFIED
- Safety cert in progress via company blog. SUPPORTED
- Competitor X matched payload in 2025. VERIFIED https://example.com/x

## Risks
Open questions on battery cycle life remain.

## Recommendation
Proceed to technical DD. Kill-criteria: MTBA < 4h in third-party bakeoff.

Padding paragraph to satisfy length gate for offline structural scoring during selftest. Residual risk stays explicit without third-party telemetry.

---
yb5 | depth=max | streams=12 | rounds=2 | verifiers=5 | drafts=3
survived=1/3 | bumped=no | mode=research | run=selftest
weakest: unit economics
next_token_spend: customer references
gate: PASS avg=4.4
"""
    with tempfile.TemporaryDirectory() as td:
        tdir = Path(td)
        report = tdir / "report.md"
        report.write_text(good, encoding="utf-8")
        cp = run([PY, "yb5_score.py", "--input", str(report)], check=False)
        if cp.returncode != 0:
            failures.append(f"score should pass good report: {cp.stdout}{cp.stderr}")

        cp = run([PY, "yb5_gate.py", "--input", str(report), "--min-avg", "4.0"], check=False)
        if cp.returncode != 0:
            failures.append(f"gate should pass good report: {cp.stdout}{cp.stderr}")

        # boot + state machine
        boot = run(
            [
                PY,
                "yb5_boot.py",
                "--task",
                "Due diligence on Acme robotics",
                "--depth",
                "standard",
                "--run-root",
                str(tdir / "runs"),
                "--fresh",
                "--json",
            ]
        )
        info = json.loads(boot.stdout)
        run_dir = info["run_dir"]
        if not Path(run_dir, "state.json").exists():
            failures.append("boot missing state.json")

        run([PY, "yb5_state.py", "--run", run_dir, "stage", "EXECUTE", "--note", "start"])
        run([PY, "yb5_state.py", "--run", run_dir, "stream-done", "S1"])
        run([PY, "yb5_state.py", "--run", run_dir, "claims", "--verified", "2", "--unverified", "1", "--supported", "1"])
        run([PY, "yb5_state.py", "--run", run_dir, "stage", "SYNTHESIZE"])
        # copy report into run and gate with --run
        (Path(run_dir) / "report.md").write_text(good, encoding="utf-8")
        cp = run([PY, "yb5_gate.py", "--input", str(Path(run_dir) / "report.md"), "--run", run_dir], check=False)
        if cp.returncode != 0:
            failures.append(f"gate+run update failed: {cp.stdout}{cp.stderr}")
        state = json.loads((Path(run_dir) / "state.json").read_text(encoding="utf-8"))
        if not (state.get("gate") or {}).get("pass"):
            failures.append(f"state gate not updated: {state.get('gate')}")
        run([PY, "yb5_state.py", "--run", run_dir, "ship"])
        if not (Path(run_dir) / "summary.json").exists():
            failures.append("ship missing summary.json")

        # bump path
        boot2 = run(
            [
                PY,
                "yb5_boot.py",
                "--task",
                "Another task for bump",
                "--depth",
                "lite",
                "--run-root",
                str(tdir / "runs2"),
                "--fresh",
                "--json",
            ]
        )
        info2 = json.loads(boot2.stdout)
        run_dir2 = info2["run_dir"]
        run([PY, "yb5_state.py", "--run", run_dir2, "bump", "--axis", "coverage", "--raise-depth"])
        st2 = json.loads((Path(run_dir2) / "state.json").read_text(encoding="utf-8"))
        if st2.get("depth") != "standard" or st2.get("bumps") != 1:
            failures.append(f"bump/raise-depth failed: {st2}")

    cp = run([PY, "yb5_cache_bench.py"], check=False)
    if cp.returncode != 0:
        failures.append("cache_bench failed:\n" + cp.stdout + "\n" + cp.stderr)

    cp = run([PY, "yb5_quality_fire.py", "--selftest"], check=False)
    if cp.returncode != 0:
        failures.append("quality_fire failed:\n" + cp.stdout + "\n" + cp.stderr)

    cp = run([PY, "yb5_runtime.py", "--selftest"], check=False)
    if cp.returncode != 0:
        failures.append("runtime failed:\n" + cp.stdout + "\n" + cp.stderr)

    # omega diminishing returns controller
    import tempfile as _tf
    with _tf.TemporaryDirectory() as _td:
        _rd = Path(_td) / "run"
        _rd.mkdir()
        run([PY, "yb5_omega.py", "--run", str(_rd), "init", "--patience", "2", "--max-steps", "5"], check=False)
        run([PY, "yb5_omega.py", "--run", str(_rd), "step", "--axis", "coverage", "--quality", "3.5"], check=False)
        run([PY, "yb5_omega.py", "--run", str(_rd), "step", "--axis", "coverage", "--quality", "3.51"], check=False)
        cp = run([PY, "yb5_omega.py", "--run", str(_rd), "step", "--axis", "coverage", "--quality", "3.52"], check=False)
        om = json.loads((_rd / "omega.json").read_text(encoding="utf-8"))
        if not om.get("stopped"):
            failures.append(f"omega should stop on diminishing returns: {om}")

    if failures:
        print("yb5_selftest: FAIL")
        for f in failures:
            print(" -", f)
        return 1
    print("yb5_selftest: PASS")
    print("note: full evidence suite = yb5_cache_verify.py --evidence")
    print("boot/plan/score/gate/state autonomy scaffolding OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Deterministic yb5 trigger/depth router for verification corpora."""
from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

OPT_OUT = re.compile(
    r"\b(one[\s-]?shot|cheap|no\s*yb5|without\s*yb5|disable\s*yb5)\b|"
    r"(不要\s*yb5|別用\s*yb5|不要燒)",
    re.IGNORECASE,
)
SOCIAL = re.compile(
    r"^(?:hi|hello|hey|yo|sup|thanks|thank you|thx|ok|okay|cool|nice|gg|lol|"
    r"哈囉|嗨|你好|謝謝|谢谢|感恩|好的|喔|嗯|在嗎|在吗)[\s!.。！？~]*$",
    re.IGNORECASE,
)
OMEGA_SIG = re.compile(
    r"omega|infinite|unbounded|no\s*ceiling|breakthrough|keep\s*going|keep\s*escalat|"
    r"突破|無限|無界|進化",
    re.IGNORECASE,
)

MAX_SIG = re.compile(
    r"burn\s*tokens?|spend\s*more|yb5\s*max|max(?:imum)?\s*depth|overkill|"
    r"due\s*diligence|\bdd\b|production|incident|legal|security|architect|"
    r"自主執行|燒\s*token|多燒|認真|完整|高風險",
    re.IGNORECASE,
)
LITE_SIG = re.compile(
    r"^(what\s+is|define|rename|typo|format|where\s+is)\b|改名|這是什麼",
    re.IGNORECASE,
)
TASK_SIG = re.compile(
    r"\b(fix|bug|error|implement|build|create|design|review|refactor|test|"
    r"analyze|research|plan|debug|optimize|explain|compare|should\s+i|how\s+to|"
    r"write|improve|ship|todo|idea|architecture|strategy)\b|"
    r"(幫我|怎麼|為何|為什麼|寫|實作|修|除錯|分析|研究|規劃|設計|比較|評估|總結|優化|重構)",
    re.IGNORECASE,
)


@dataclass
class Route:
    trigger: bool
    depth: str
    reason: str
    exempt: bool


def route(text: str) -> Route:
    t = (text or "").strip()
    if not t:
        return Route(False, "micro", "empty", True)
    if OPT_OUT.search(t):
        return Route(False, "micro", "explicit_opt_out", True)
    if SOCIAL.match(t):
        return Route(False, "micro", "pure_social", True)
    if OMEGA_SIG.search(t):
        return Route(True, "omega", "omega_signal", False)
    if MAX_SIG.search(t):
        return Route(True, "max", "max_signal", False)
    if LITE_SIG.search(t) and len(t) < 60:
        return Route(True, "lite", "lite_task", False)
    if TASK_SIG.search(t):
        return Route(True, "standard", "task_signal", False)
    if re.search(r"[\u4e00-\u9fff]", t) and not re.search(r"[?？]", t) and len(t) <= 16:
        # short CJK after greeting filter is usually a real ask
        return Route(True, "standard", "short_cjk_task", False)
    if len(t) <= 12 and not re.search(r"[?？]", t):
        return Route(False, "micro", "short_non_task", True)
    return Route(True, "standard", "default_non_exempt", False)


def main(argv: list[str] | None = None) -> int:
    # Windows consoles/pipes default to a legacy codepage (e.g. cp950) that cannot
    # encode non-BMP-for-that-locale chars; the trigger corpus contains CJK/emoji.
    # Force UTF-8 so `--json` (ensure_ascii=False) never dies on e.g. "谢谢".
    try:
        sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
    except Exception:
        pass
    parser = argparse.ArgumentParser(description="yb5 deterministic router")
    parser.add_argument("--text", default=None)
    parser.add_argument("--corpus", type=Path, default=None)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)

    if args.corpus:
        rows = []
        total = hit = depth_hit = 0
        for line in args.corpus.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            item = json.loads(line)
            r = route(item["text"])
            total += 1
            exp_trigger = bool(item["trigger"])
            if r.trigger == exp_trigger:
                hit += 1
            exp_depth = item.get("depth")
            if exp_depth is None or r.depth == exp_depth or (not exp_trigger and r.exempt):
                depth_hit += 1
            rows.append({"text": item["text"], "expected": item, "got": asdict(r)})
        summary = {
            "total": total,
            "trigger_match": hit,
            "trigger_hit_rate": round(hit / total, 4) if total else 0.0,
            "depth_match": depth_hit,
            "depth_hit_rate": round(depth_hit / total, 4) if total else 0.0,
            "rows": rows,
        }
        if args.json:
            json.dump(summary, sys.stdout, indent=2, ensure_ascii=False)
            sys.stdout.write("\n")
        else:
            print(
                f"router_corpus: trigger_hit_rate={summary['trigger_hit_rate']} ({hit}/{total}) "
                f"depth_hit_rate={summary['depth_hit_rate']} ({depth_hit}/{total})"
            )
        return 0 if hit == total else 1

    if args.text is None:
        raise SystemExit("provide --text or --corpus")
    r = route(args.text)
    if args.json:
        json.dump(asdict(r), sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        print(f"trigger={r.trigger} depth={r.depth} reason={r.reason} exempt={r.exempt}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
---
name: yangble5
description: "DEFAULT elite reasoning protocol with omega infinity escalation for almost every user message. Auto-trigger on thinking, coding, debugging, research, writing, planning, review, decision, analysis, architecture, strategy, implement, fix, explain, compare, design, ship, due diligence, or quality work. Also trigger on yb5, $yb5, overkill, burn tokens, spend more, autonomous, omega, infinite, unbounded, breakthrough, help me, how to, why, bug, error, idea, should I, build, create, improve. Micro only for pure greetings/acks. Otherwise run autonomous multi-pass (decompose, tools, refute, redteam, critic, best-of-N, metacritic, gate) and auto-bump; on omega/infinite requests escalate until diminishing returns."
---

# yangble5

<!-- CACHE_STABLE_PREFIX_BEGIN -->
<!-- card v7 + stable pack; verify: cache_verify / bakeoff / orchestrate / arena / runtime -->

## ALWAYS-ON CARD (read every turn; do not skip)

You are running the **yangble5** skill — elite, always-on, optionally unbounded.

```
# yb5 always-on card v7
ROUTE every user message through yb5 unless EXEMPT.
EXEMPT only: pure greeting/thanks/emoji; explicit one-shot/cheap/no yb5; platform yes/no with no task.
If EXEMPT: brief answer + `yb5 | depth=micro | skipped=exempt`.
Else: BOOT>ORIENT>DECOMPOSE>EXECUTE>VERIFY>REDTEAM>CRITIC~EXECUTE>SYNTHESIZE>METACRITIC>GATE>(BUMP|OMEGA|SHIP)
Depth: micro|lite|standard|max|insane|omega (default standard; burn-tokens=>max; infinite/omega/突破/無限/無界=>omega)
Omega: escalate weakest axis until delta<epsilon for patience steps, or hard stop.
Elite laws: tools before claims; refute before accept; unknowns loud; gate or no ship.
Infinity laws: no fake ceiling; depth must move measurable quality; arena must beat single-shot.
Substance law: structural scores are necessary not sufficient; bakeoff substance must clear gaming flags.
Ship: VERIFIED|SUPPORTED|UNVERIFIED|CONTESTED; kill-criteria; footer; gate fail=>bump/omega.
Runtime: yb5_runtime.py (offline loop). Orchestrate: yb5_orchestrate.py (executor-bound evidence).
Assembly: STABLE_PACK -> USER -> INTERNAL only. Volatile never in STABLE_PACK.
```

card_sha256: `31ff8dbec379023c49dc5e1854b76e4683960371848c25d26a96ea6c2deb0a52`

**Depth:** micro | lite | standard | max | insane | **omega**
- burn-tokens / high stakes => max
- breakthrough / infinite / unbounded / 突破 / 無限 / 無界 => **omega**

**Loop:**
`BOOT > ORIENT > DECOMPOSE > EXECUTE > VERIFY > REDTEAM > CRITIC~EXECUTE > SYNTHESIZE > METACRITIC > GATE > (BUMP|OMEGA|SHIP)`

**Elite laws:** tools before claims; refute before accept; disconfirm mandatory; unknowns loud; gate or no ship.
**Infinity laws:** no fake ceiling; escalate weakest axis; stop on epsilon plateau / safety rail / PASS / blocker.
**Substance law:** `quality_fire` is structural only; `bakeoff` substance must reject decorated vacuity.
**Runtime law:** deeper depth must change measurable outcomes (findings/composite), not just labels.

**Cache:** `STABLE_PACK -> USER -> INTERNAL` only.

**Helpers:**
```bash
python <skill>/scripts/yb5_boot.py --task "..." --depth omega
python <skill>/scripts/yb5_runtime.py --task "..." --depth omega --print-report
python <skill>/scripts/yb5_orchestrate.py --depth omega --json
python <skill>/scripts/yb5_bakeoff.py --challenger a.md --opponent b.md
python <skill>/scripts/yb5_omega.py --run <run_dir> init
python <skill>/scripts/yb5_arena.py
python <skill>/scripts/yb5_cache_verify.py --evidence
python <skill>/scripts/yb5_selftest.py
```
<!-- CACHE_STABLE_PREFIX_END -->

---

## Thesis

Others ask once. yangble5 asks many times, red-teams itself, binds claims to executor evidence, and when asked to break the ceiling escalates with **omega** until gains diminish — then ships with evidence, not mythology.

## Breakthrough stack (prove, don't posture)

1. **Structure** — `yb5_quality_fire.py` / gate / footer tags
2. **Work intensity** — `yb5_runtime.py` findings + composite ladder by depth
3. **Cache** — STABLE_PACK LCP >= 0.999
4. **Substance anti-gaming** — `yb5_bakeoff.py` rejects shape-only and decorated vacuity
5. **Executor-bound truth** — `yb5_orchestrate.py` only ships on real exit codes
6. **Infinity control** — `yb5_omega.py` stops on diminishing returns

A high structural score alone is **not** a win. If bakeoff flags `decorated_vacuity` or orchestrate cannot provenance VERIFIED findings, do not claim breakthrough.

## Closed-loop proof commands

```bash
python scripts/yb5_runtime.py --selftest
python scripts/yb5_arena.py
python scripts/yb5_bakeoff.py --selftest
python scripts/yb5_orchestrate.py --selftest
python scripts/yb5_cache_verify.py --evidence
```

## Omega controller

When depth=omega:
1. boot + runtime/orchestrate
2. `yb5_omega.py init`
3. step on weakest axis with measured quality
4. stop on diminishing_returns / safety_rail / gate_pass

## Footer

```
---
yb5 | depth=... | streams=... | rounds=... | verifiers=... | drafts=...
survived=.../... | bumped=... | mode=... | run=...
weakest: ...
next_token_spend: ...
gate: PASS|FAIL avg=...
redteam: clean|patched|unresolved
omega: steps=k stopped=reason
substance: clear|flagged
```

## Anti-patterns

- Celebrating structural avg 5.0 / composite 100 from empty templates
- Infinite loops without epsilon/patience
- Depth labels with identical work intensity
- Fake PASS / fake cache claims without evidence commands
- Putting stage bodies above USER
- Silent skill self-edit without evolve verify

# Fable5 quality rubric

Score silently before ship. FAIL is a spend signal, not a vibe.

## Axes (1-5)

### 1. Truthfulness
5 evidenced; uncertainty explicit; no invented citations/tests
3 mostly fair, some overreach
1 hallucination / fake precision

### 2. Adversarial hardness
5 real refutations; weak claims killed/narrowed; redteam strikes answered
3 mild caveats
1 confirmation-only

### 3. Coverage
5 evidence+risk+alternatives+edges+decision; critic converged
3 main path only
1 single angle

### 4. Decision usefulness
5 clear action, owners/timers if relevant, kill-criteria, monitors
3 informative but mushy
1 no actionable point

### 5. Structure and density
5 scannable, mode-correct, tags+footer
3 readable but bloated/missing tags
1 dump

### 6. Calibration
5 claims scoped with conditions; CONTESTED/UNVERIFIED used honestly
3 mixed
1 swagger without mechanism

### 7. Implementability
5 path to execution is real (tests/commands/interfaces/rollout)
3 high-level only
1 slideware

### 8. Dialectic integrity
5 steelman + premortem residue absorbed into winner
3 mentioned then ignored
1 absent on standard+

## Ship thresholds
- lite: avg >= 3.5 on axes 1-5 (axes 6-8 optional)
- standard: avg >= 4.0 on axes 1-8, footer+tags required
- max: avg >= 4.4, redteam present, kill-criteria present
- insane: avg >= 4.6, steelman+premortem drafts present, primary evidence on load-bearing claims

## Auto-bump triggers (any)
- below threshold for depth
- zero UNVERIFIED/CONTESTED/SUPPORTED residue on long research with many claims
- no disconfirm stream
- footer/gate missing
- redteam high-severity unanswered on max/insane
- burn-tokens requested but depth still lite/standard without reason

## Spend the next dollar on the lowest axis
- Truth -> primary retrieval + verifier votes
- Adversarial -> redteam + extra lenses
- Coverage -> critic round
- Decision -> option table + kill-criteria
- Structure -> retag/footer/best-of-N only
- Calibration -> narrow claims / add conditions
- Implementability -> tests, interfaces, rollout
- Dialectic -> force steelman+premortem drafts

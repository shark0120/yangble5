# Fable5 on grok4.5 + codex (orchestrator/executor split)

Prototype under test: **Grok 4.5 = ORCHESTRATOR** (reasoning, judgment, decomposition,
adjudication, synthesis, stop-rules). **Codex = EXECUTOR** (runs code/tools, returns evidence).
Fable5 is the shared protocol. The bet: this pairing goes head-to-head with a native
frontier reasoner (e.g. Fable5) not by a bigger single forward pass, but by **disciplined
multi-pass reasoning bound to real tool evidence**.

## Why split reasoner from executor

A single model conflates "I reasoned it" with "I checked it." Splitting makes the elite law
*tools before claims* structural instead of aspirational:

- The **orchestrator cannot emit tool output.** Only the executor can. Fabricated evidence
  becomes impossible-by-construction, not a rule the model must remember to follow.
- The **executor cannot decide ship.** It returns raw stdout + exit codes; the gate call is
  the orchestrator's. Neither side can shortcut the other's job.

This is the same separation-of-powers `redteam.md` demands ("separate proposer from evaluator").

## Hard division of labor

| Stage | Owner | Concrete output |
|-------|-------|-----------------|
| BOOT | executor | `fable5_boot.py --task ... --depth ...` → `run_dir`, `state.json` |
| ORIENT | orchestrator | `{mode, goal, audience, depth, done_definition, risk_if_wrong, irreversible, tool_plan}` |
| DECOMPOSE | orchestrator (seed via `fable5_plan.py`) | streams JSON, ≥1 kill-case, ≥1 alternative |
| EXECUTE | **executor** | run search/tests/repro; return atomic findings + evidence handles |
| VERIFY | orchestrator judges; executor runs any check it asks for | votes → VERIFIED/SUPPORTED/UNVERIFIED/CONTESTED |
| REDTEAM | orchestrator; executor runs the decisive test | strikes + must-fix |
| CRITIC | orchestrator | flip-the-answer gaps; loop back to EXECUTE |
| SYNTHESIZE | orchestrator | best-of-N drafts → winner absorbing steelman/premortem residue |
| METACRITIC | orchestrator | mock list + cheap material patches |
| GATE | executor runs `fable5_gate.py` / `fable5_quality_fire.py`; orchestrator decides | PASS/FAIL + ship decision |
| OMEGA | orchestrator picks weakest axis; executor runs `fable5_omega.py step` | escalation until epsilon |
| SHIP | orchestrator | final artifact + footer |

Rule of thumb: **if a claim can be checked by running something, it belongs to the executor.**
Everything about *what to check, what it means, and whether to stop* belongs to the orchestrator.

## Message envelope (orchestrator ↔ executor)

Keep traffic as small typed JSON so the split stays cache-friendly and auditable.

```json
// orchestrator -> executor
{"type":"EXEC_REQUEST","stage":"EXECUTE","stream_id":"S3",
 "cmd":["python","scripts/fable5_plan.py","--task","...","--depth","max","--json"],
 "expect":"stdout_json","timeout_s":120,"why":"seed decomposition"}
```
```json
// executor -> orchestrator  (NEVER editorialized; raw truth only)
{"type":"EXEC_RESULT","stage":"EXECUTE","stream_id":"S3",
 "exit_code":0,"stdout":"...","stderr":"","status":"OK",
 "evidence_handles":["scripts/fable5_plan.py","run://f5-xxxx/plan.json"]}
```

## Executor laws (Codex)

1. Only the executor produces tool output. Return raw stdout + exit codes; never write "tests pass" — return the exit code and let the orchestrator conclude.
2. On tool failure: retry once, then return `status:"ERROR"` with the failure text. **Never synthesize success.**
3. Stay on the deterministic offline path: every `fable5_*.py` runs with no network and no API key.
4. Never decide ship, never tag claims, never narrow a recommendation. That is orchestrator work.

## Orchestrator laws (Grok 4.5)

1. Never fabricate evidence handles. A claim with no backing `EXEC_RESULT` is `UNVERIFIED` — loudly.
2. `EXEC_RESULT` is the *only* ground truth for "did it run / did it pass."
3. Own the loop and the stop rules (gate PASS, omega epsilon/patience, safety rail, user stop).
4. Keep the proposer≠evaluator wall: the stream that made a claim does not get to clear it.

## Portability & caching on a non-Claude orchestrator

The `STABLE_PACK → USER → INTERNAL` assembly targets **prefix-cache reuse**, and cache
semantics differ per provider. Do not assume the 99.9% LCP number transfers to Grok/OpenAI.

- **Measure, don't assume.** Run `fable5_cache_verify.py` against the actual provider, or budget for full re-send.
- **Progressive disclosure when prefix caching is weak/absent.** Load `always_on_card.txt` every turn (it is small and model-agnostic by design); pull heavy references on demand instead of shipping the whole `stable_pack.txt` each turn.
- **Machine-readable fallback.** If the orchestrator underweights dense prose, drive it from the `pipeline.md` JSON stage contracts as the primary interface and treat the narrative refs as backup.

## Beating native Fable5: structure is table stakes, substance wins

Read this before quoting any score.

- `fable5_quality_fire.py` is a **structural proxy**. A shape-only artifact — every required
  header present, bodies empty, `sim://` evidence — can score `avg 5.0 / composite 100`. That
  number is **not** evidence you matched a frontier reasoner.
- `composite=100 @ omega` is a **work-intensity ceiling, not a quality ceiling.** Per
  `infinity.md` ("no fake ceiling"), treat composite as *spend telemetry*, never a trophy.
- Real competitiveness is decided **adversarially against a real opponent artifact**, on
  substance — that is what `fable5_bakeoff.py` measures.

Anti-gaming rules (the bakeoff scorer enforces these as a *floor*):

1. Every required section carries a **non-trivial body**, not a header plus one keyword.
2. Evidence is **real** — url / file path / test output / exit code — never `sim://` or
   `example.com` placeholders. In live runs, only executor-produced handles count.
3. **No boilerplate padding.** Repeated templated sentences are penalized, not rewarded.
4. Prefer **specifics** — numbers with units, dates, named entities, exact commands — over
   hedged abstractions.
5. **No decorated vacuity.** Real-looking dates/metrics/URLs bolted onto tautologies
   ("p99 of 480ms tracked the reference p99 of 480ms") or fluent abstraction carry no
   information. The scorer flags `decorated_vacuity` / `tautology`, but see the two-layer rule.

Ship-claim discipline: report **structural gate PASS** and **substance-vs-opponent** as two
separate facts. Never present a structural 5.0 as "we beat Fable5."

## Two-layer substance judging (heuristic floor + LLM judge)

A red-team of the bakeoff scorer proved the honest limit: **a regex/heuristic cannot detect
fluent decorated vacuity** — surface-token counting can be fooled by content-free prose dressed
in real-looking specifics. So substance is judged in two layers:

- **Layer 1 — heuristic floor (executor / Codex).** `fable5_bakeoff.py` gives a cheap,
  deterministic `substance` score plus vacuity flags. It reliably kills crude gaming
  (shape-only, fake evidence, boilerplate, tautology-heavy, most decorated vacuity) and returns
  `heuristic_clear` + `needs_llm_judge`. A passing floor is **necessary, not sufficient**.
- **Layer 2 — LLM judge (orchestrator / Grok 4.5), authoritative.** The real substance verdict
  is a semantic judgement no regex can make. Emit the judge prompt and have the orchestrator (or
  a separate judge model) score information/evidence-truth/decision-usefulness and pick a winner:

```bash
python scripts/fable5_bakeoff.py --challenger our_report.md --opponent baseline_report.md --emit-judge-prompt
```

Never treat the heuristic score as authoritative; `bakeoff` returns `authoritative: false`.

## Executable engine

`scripts/fable5_orchestrate.py` makes this whole contract runnable, not just prose:

- **Executor** runs the real `fable5_*.py` tools as subprocesses and returns raw exit codes —
  findings are backed by real `run://<cmd>#exit=N` handles, never `sim://`.
- **Reasoner** is pluggable: `DeterministicReasoner` (offline, deterministic, selftest-clean) or
  `LLMReasoner(call_llm, cassette)` for a live grok/codex/anthropic model with record/replay.
- **Provenance invariants** (hardened after a 5-lens red-team broke v1): `report_handles_all_executor_produced`
  (every evidence handle in the shipped report is in the executor's real run log — reasoner prose is
  sanitized so it cannot smuggle a `run://…#exit=0` in), `verified_backed_by_exit0`, `no_fabricated_evidence`,
  `experiments_allowlisted` (findings run only vetted tools with canonical hypotheses the reasoner cannot
  rewrite — no VERIFYing a claim via `--help`), `footer_gate_matches_real`, `own_report_clears_floor` (the
  report passes its own bake-off substance floor), and `all_experiments_verified` (a failing tool sinks the
  gate — no green-on-failure). **Honest caveat**: a passing tool proves it ran and passed, NOT that it fully
  tests the claim — the LLM judge is the authoritative substance layer. **Omega is measured**: each step runs
  one more real experiment and feeds the re-scored substance to the controller (no hardcoded curve).

```bash
python scripts/fable5_orchestrate.py --depth omega --json   # real evidence trail + gate + omega
python scripts/fable5_orchestrate.py --selftest
```

### Guard mode: wire the engine into an autonomy loop

The engine doubles as a loop's verification gate. The loop/project supplies its OWN vetted
acceptance checks (a JSON spec); the engine runs them with real evidence + the honesty invariants
and returns a machine-readable ship / no-ship verdict. The reasoner only ADJUDICATES exit codes, so
it cannot game caller-supplied checks. `exit 0 == ship`, plus a `.coord`-style `PASS`/`FAIL` line.

```bash
python scripts/fable5_orchestrate.py --guard acceptance.json --json
```
```json
{"task":"verify my change","min_verified_fraction":1.0,"cwd":".",
 "checks":[{"name":"tests","argv":["python","-m","pytest","-q"],"hypothesis":"the suite passes"},
           {"name":"coord","argv":["python",".coord/check.py"],"hypothesis":"coordination is consistent"}]}
```

Integration: an autopilot / iterate / `.coord` loop replaces its ad-hoc verify step with a guard
call and gates on the verdict. A failing load-bearing check sinks `ship`; the honesty invariants
(provenance, `verified_backed_by_exit0`, `checks_allowlisted`) still hold on the failing run, and the
report states it must not ship. See `acceptance.example.json`.

SECURITY: a guard spec runs arbitrary commands — pass only specs from a TRUSTED source
(operator / loop / checked-in project config), never one built from untrusted observed content.

## Head-to-head

```bash
# Layer 1 — heuristic floor (challenger = our grok4.5+codex run; opponent = the model we race)
python scripts/fable5_bakeoff.py --challenger our_report.md --opponent baseline_report.md

# prove the harness resists shape-gaming AND decorated vacuity
python scripts/fable5_bakeoff.py --demo        # substantive vs decorated-vacuity fixture
python scripts/fable5_bakeoff.py --selftest
```

The winner is decided on **substance-weighted** axes with explicit gaming flags; a
structure-win / substance-loss is reported honestly rather than hidden behind the higher number.
Then run Layer 2 for the authoritative call.

# Fable5 infinity protocol

There is no blessed final depth. There is only:

```
quality_t+1 - quality_t  <  epsilon
```

for consecutive escalations, with honest stopping.

## Why "infinite" is not cosplay

Unbounded search without a stop rule is thrashing.
Fable5 infinity = **unbounded escalation + measurable diminishing returns + hard stops**.

## Depth ladder

```
micro < lite < standard < max < insane < omega(n)
```

`omega(n)` is not a fixed knob table. It is a recursive operator:

```
omega(0) = insane baseline
omega(n+1) = escalate(omega(n)) on weakest axis
stop when:
  - delta_quality < epsilon for patience steps, or
  - hard_stop hit, or
  - user stop
```

## Escalate operators (burn map)

| Weakest axis | Omega escalation |
|--------------|------------------|
| truthfulness | +primary retrieval; split contested claims; require dated sources |
| adversarial | +redteam strikes; double verifier votes; invite kill-case stream |
| coverage | +critic round; force second-order / incentive / base-rate streams |
| decision | force option matrix + kill-criteria + monitors + owner/timer |
| structure | retag; compress; best-of-N rewrite only |
| calibration | convert swagger to conditions; add ranges/triggers |
| implementability | run tests/commands; define interfaces/rollout/rollback |
| dialectic | mandatory steelman + premortem drafts merged into winner |

## Epsilon & patience

Defaults:
- epsilon = 0.05 quality points (0-5 scale) or structural gate still failing
- patience = 2 consecutive no-gain escalations
- max_omega_steps = 12 (safety rail, not a quality ceiling)

If gate still FAIL at max_omega_steps: ship best-so-far with `gate: FAIL` and `omega_stopped=safety_rail`.

## Hard stops (only)

1. Gate PASS and redteam high-severity resolved and delta < epsilon
2. External blocker (secrets/network/user budget) -> BLOCKED.md
3. Safety rail max_omega_steps
4. User says stop

## Anti-thrash rules

- Never restart architecture when a knob would do
- Never re-research resolved VERIFIED claims without new disconfirm
- Cache STABLE_PACK; only INTERNAL/user evidence changes
- Each omega step must name: target_axis, action, expected_delta, measured_delta

## Self-evolution (optional, offline)

`fable5_evolve.py` may propose skill patches under `.fable5/evolve/`.
A patch is kept only if:
1. quick_validate / selftest PASS
2. cache_verify PASS
3. arena score does not regress
4. quality_fire selftest PASS

Evolution never silent-edits production skill without those gates.

## Arena

`fable5_arena.py` compares assemblies/scores:
single-shot baseline vs Fable5 depths.
Infinity is real only if arena shows monotone non-regression with depth on structural quality proxies.

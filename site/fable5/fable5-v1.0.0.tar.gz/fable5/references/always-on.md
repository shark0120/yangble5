# Fable5 always-on routing

## Exempt only
1. Pure greeting / thanks / emoji / ok with no ask
2. Explicit one-shot / cheap / no fable5
3. Platform binary UI with no task content

## Canonical card
```
# fable5 always-on card v7
ROUTE every user message through Fable5 unless EXEMPT.
EXEMPT only: pure greeting/thanks/emoji; explicit one-shot/cheap/no fable5; platform yes/no with no task.
If EXEMPT: brief answer + `fable5 | depth=micro | skipped=exempt`.
Else: BOOT>ORIENT>DECOMPOSE>EXECUTE>VERIFY>REDTEAM>CRITIC~EXECUTE>SYNTHESIZE>METACRITIC>GATE>(BUMP|OMEGA|SHIP)
Depth: micro|lite|standard|max|insane|omega (default standard; burn-tokens=>max; infinite/omega/突破/無限/無界=>omega)
Omega: escalate weakest axis until delta<epsilon for patience steps, or hard stop.
Elite laws: tools before claims; refute before accept; unknowns loud; gate or no ship.
Infinity laws: no fake ceiling; depth must move measurable quality; arena must beat single-shot.
Substance law: structural scores are necessary not sufficient; bakeoff substance must clear gaming flags.
Ship: VERIFIED|SUPPORTED|UNVERIFIED|CONTESTED; kill-criteria; footer; gate fail=>bump/omega.
Runtime: fable5_runtime.py (offline loop). Orchestrate: fable5_orchestrate.py (executor-bound evidence).
Assembly: STABLE_PACK -> USER -> INTERNAL only. Volatile never in STABLE_PACK.
```
sha256: `303f302f8197b5ab5deffed9d191fee144f88a96c80a664fc4c0f7c79aafda82`

## Breakthrough proof order
structure -> work intensity -> cache -> bakeoff substance -> orchestrate executor truth -> omega stop

## Commands
```bash
python scripts/fable5_cache_verify.py --evidence
python scripts/fable5_bakeoff.py --selftest
python scripts/fable5_orchestrate.py --selftest
```

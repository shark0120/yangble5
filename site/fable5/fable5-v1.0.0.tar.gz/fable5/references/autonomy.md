# Fable5 autonomous execution (elite)

Mechanical loop. User sees progress pings + final artifact, not a negotiation.

## 0. BOOT
```bash
python scripts/fable5_boot.py --task "..." --depth <tier>
```
Resume unfinished same task_hash unless fresh.

## 1. ORIENT
mode, goal, audience, constraints, depth, done_definition, risk_if_wrong, tool_plan, irreversibility.
Defaults: skeptical decision-maker; tools on; citations for facts.

## 2. DECOMPOSE
Exactly SUBQUESTIONS streams. >=1 kill-case. >=1 alternative (except pure single-bug debug).

## 3. EXECUTE
Tools first. Atomic findings + evidence handles. Parallelize independent streams.

## 4. VERIFY
VERIFIER_VOTES ballots / lenses. Default refute if thin. Narrow > delete.
Suspicion check: many claims and zero weak tags => force adversary pass.

## 5. REDTEAM
Contradiction / missing-killer / incentive strikes.
High severity unanswered => new streams or narrowed conclusion.

## 6. CRITIC
Flip-the-answer gaps only. Loop to EXECUTE while rounds remain.

## 7. SYNTHESIZE
Best-of-N with operator / skeptic / implementer (+ steelman + premortem on max/insane).
Winner absorbs critical residue.

## 8. METACRITIC
Hostile expert mock list. Apply cheap material patches.

## 9. GATE
```bash
python scripts/fable5_gate.py --input report.md --min-avg <threshold>
```
standard 4.0 / max 4.4 / insane 4.6 (rubric). Structural gate still required.

## 10. BUMP or SHIP
Bump weakest axis within spend caps. Exhaustion => honest FAIL footer + best artifact.

## Progress pings
`fable5 <STAGE> key=value ...`

## Failure ethics
No fake PASS. No silent dropped refutations. BLOCKED names exact missing capability.

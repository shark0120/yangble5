# Fable5 cache protocol (99.9)

Target: min_lcp_ratio >= 0.999
Assembly: STABLE_PACK -> USER -> INTERNAL
Card sha256: `303f302f8197b5ab5deffed9d191fee144f88a96c80a664fc4c0f7c79aafda82`

Runtime/omega/arena must not put volatile bytes into STABLE_PACK.

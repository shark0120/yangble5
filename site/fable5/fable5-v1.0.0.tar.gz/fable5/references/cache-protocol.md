# Fable5 cache protocol (99.9)

Target: min_lcp_ratio >= 0.999
Assembly: STABLE_PACK -> USER -> INTERNAL
Card sha256: `a801013252d1ba06831a3c2bed14896bf4c09c0c179242d9285b91012c343a2a`

Runtime/omega/arena must not put volatile bytes into STABLE_PACK.

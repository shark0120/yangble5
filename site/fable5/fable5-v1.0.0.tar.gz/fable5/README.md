# Fable5

An execution protocol plus scoring gate for AI agents (Claude Code, Codex, or
any agent that loads Markdown skills). Instead of answering once and hoping,
the agent runs a fixed loop —

```
BOOT > ORIENT > DECOMPOSE > EXECUTE > VERIFY > REDTEAM >
CRITIC~EXECUTE > SYNTHESIZE > METACRITIC > GATE > (BUMP | OMEGA | SHIP)
```

— and may only ship a result after the gate passes. Every claim in the output
must carry one of four evidence states: **VERIFIED**, **SUPPORTED**,
**UNVERIFIED**, or **CONTESTED**. If the gate fails, the loop bumps depth and
tries again; on explicit "omega" requests it escalates the weakest axis until
returns diminish, then stops.

## Who this is for

- People who run coding/research agents and want outputs that separate what
  was actually verified from what was merely asserted.
- Agent builders who want an offline, deterministic quality gate (structure
  scoring, anti-gaming bake-off, diminishing-returns controller) they can run
  in CI without any API key.
- Anyone tired of confident single-shot answers with no evidence trail.

## Install as a Claude Code / Codex skill

1. Download `fable5-v1.0.0.tar.gz` and verify its SHA256 against the published
   `.sha256` file before extracting.
2. Extract the top-level `fable5/` directory into your skills directory:
   - Claude Code: `~/.claude/skills/fable5/`
   - Codex: `~/.codex/skills/fable5/`
3. The agent picks up `SKILL.md` automatically; the always-on card at the top
   of that file is the runtime contract.

No network access, accounts, or API keys are required by any bundled script.

## Run the selftest

```bash
cd <skills-dir>/fable5/scripts
python fable5_selftest.py          # offline; expects "fable5_selftest: PASS"
python fable5_cache_verify.py --evidence   # optional full evidence suite
```

The selftest is the acceptance check and passes on a clean extraction. The
`--evidence` suite additionally contains environment-bound checks
(`repo_user_sync`, `agents_injection`) that compare against a copy installed
at `~/.codex/skills/fable5` and an always-on block in `~/.codex/AGENTS.md`;
on a machine without those, expect exactly those checks to fail and the rest
to pass.

Python 3.10+ is required (standard library only). The selftest exercises the
planner, scorer, gate, state machine, cache card determinism, and the omega
diminishing-returns controller — all offline.

## What's in the box

- `SKILL.md` — the always-on card and protocol definition
- `references/` — protocol references (pipeline, roles, rubric, red-team,
  cache protocol, trigger corpus)
- `scripts/` — offline helpers: boot/plan/score/gate/state/runtime/
  orchestrate/bakeoff/omega/arena/cache-verify/selftest

## Honest limitations

The scoring scripts are structural and heuristic: they check that a report has
the required shape, tags, and evidence handles — they cannot judge whether the
underlying claims are true, and a determined author can satisfy the gate with
well-formed but wrong content. Cache metrics are structural proxies, not
provider telemetry. Treat a PASS as "the process was followed," never as "the
answer is correct."

## License

MIT — see `LICENSE`. Copyright (c) 2026 shark0120.

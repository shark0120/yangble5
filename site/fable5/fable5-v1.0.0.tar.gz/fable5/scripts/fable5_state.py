#!/usr/bin/env python3
"""Read/update Fable5 run state (autonomous checkpoint helper).

Usage:
  python fable5_state.py --run <run_dir> status
  python fable5_state.py --run <run_dir> stage VERIFY --note "3 claims contested"
  python fable5_state.py --run <run_dir> round 2
  python fable5_state.py --run <run_dir> bump --axis coverage --note "missing regulatory"
  python fable5_state.py --run <run_dir> claims --verified 4 --supported 2 --unverified 1 --contested 1
  python fable5_state.py --run <run_dir> stream-done S3
  python fable5_state.py --run <run_dir> gate --pass --avg 4.4
  python fable5_state.py --run <run_dir> blocked --reason "OPENAI_API_KEY missing"
  python fable5_state.py --run <run_dir> ship
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

VALID_STAGES = {
    "ORIENT",
    "DECOMPOSE",
    "EXECUTE",
    "VERIFY",
    "CRITIC",
    "SYNTHESIZE",
    "GATE",
    "BUMP",
    "SHIP",
    "BLOCKED",
}

DEPTH_ORDER = ["lite", "standard", "max", "insane", "omega"]


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def append_ledger(run_dir: Path, event: dict) -> None:
    path = run_dir / "ledger.jsonl"
    event = {"ts": utc_now(), **event}
    with path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(event, ensure_ascii=False) + "\n")


def require_run(run: str) -> Path:
    run_dir = Path(run)
    if not (run_dir / "state.json").exists():
        raise SystemExit(f"not a fable5 run dir: {run_dir}")
    return run_dir


def cmd_status(run_dir: Path) -> int:
    state = load_json(run_dir / "state.json")
    meta = load_json(run_dir / "meta.json")
    plan = load_json(run_dir / "plan.json")
    print(f"run_id={state.get('run_id')}")
    print(f"task={meta.get('task')}")
    print(f"mode={meta.get('mode')} depth={state.get('depth')} stage={state.get('stage')}")
    print(f"round={state.get('round')} bumps={state.get('bumps')}/{state.get('max_bumps')}")
    print(f"open_streams={len(state.get('open_streams') or [])} done_streams={len(state.get('done_streams') or [])}")
    print(f"claims={state.get('claim_counts')}")
    print(f"gate={state.get('gate')}")
    if state.get("blocked"):
        print(f"blocked={state.get('blocked')}")
    print(f"streams_planned={len(plan.get('streams') or [])}")
    print(f"updated_at={state.get('updated_at')}")
    # next action hint
    stage = state.get("stage")
    hints = {
        "ORIENT": "Write orient.json details, then stage DECOMPOSE (already planned at boot).",
        "DECOMPOSE": "Confirm plan.json streams, then stage EXECUTE and work open streams.",
        "EXECUTE": "Execute open streams with tools; mark stream-done as you finish.",
        "VERIFY": "Adversarially verify material claims; update claim counts.",
        "CRITIC": "Find flip-the-answer gaps; enqueue streams or advance to SYNTHESIZE.",
        "SYNTHESIZE": "Write best-of-N report.md then stage GATE.",
        "GATE": "Run fable5_gate.py on report.md; on FAIL stage BUMP, on PASS stage SHIP.",
        "BUMP": "Spend tokens on weakest axis; resume VERIFY/CRITIC/SYNTHESIZE.",
        "SHIP": "Done. Deliver report.md to user.",
        "BLOCKED": "Resolve blocked reason or ship best-so-far with honest FAIL.",
    }
    print(f"next_hint={hints.get(stage, 'continue autonomy loop')}")
    return 0


def touch(state: dict) -> None:
    state["updated_at"] = utc_now()


def cmd_stage(run_dir: Path, stage: str, note: str | None) -> int:
    stage = stage.upper()
    if stage not in VALID_STAGES:
        raise SystemExit(f"invalid stage {stage}; choose {sorted(VALID_STAGES)}")
    state_path = run_dir / "state.json"
    state = load_json(state_path)
    prev = state.get("stage")
    state["stage"] = stage
    touch(state)
    save_json(state_path, state)
    append_ledger(run_dir, {"stage": stage, "event": "stage_change", "from": prev, "note": note or ""})
    print(f"fable5 {stage} from={prev} note={note or ''}".rstrip())
    return 0


def cmd_round(run_dir: Path, number: int) -> int:
    state_path = run_dir / "state.json"
    state = load_json(state_path)
    state["round"] = int(number)
    state["stage"] = "EXECUTE"
    touch(state)
    save_json(state_path, state)
    append_ledger(run_dir, {"stage": "EXECUTE", "event": "round_set", "round": number})
    print(f"fable5 EXECUTE round={number}")
    return 0


def cmd_bump(run_dir: Path, axis: str | None, note: str | None, raise_depth: bool) -> int:
    state_path = run_dir / "state.json"
    meta_path = run_dir / "meta.json"
    state = load_json(state_path)
    meta = load_json(meta_path)
    bumps = int(state.get("bumps") or 0) + 1
    max_bumps = int(state.get("max_bumps") or 2)
    state["bumps"] = bumps
    state["stage"] = "BUMP"
    state["last_bump_axis"] = axis or "unspecified"
    touch(state)

    depth = state.get("depth") or meta.get("depth") or "standard"
    if raise_depth and depth in DEPTH_ORDER:
        idx = DEPTH_ORDER.index(depth)
        if idx < len(DEPTH_ORDER) - 1:
            new_depth = DEPTH_ORDER[idx + 1]
            state["depth"] = new_depth
            meta["depth"] = new_depth
            # expand max bumps to new tier default if higher
            tier_caps = {"lite": 1, "standard": 2, "max": 3, "insane": 4}
            state["max_bumps"] = max(max_bumps, tier_caps[new_depth])
            save_json(meta_path, meta)
            depth = new_depth

    save_json(state_path, state)
    append_ledger(
        run_dir,
        {
            "stage": "BUMP",
            "event": "bump",
            "bumps": bumps,
            "axis": axis or "",
            "depth": depth,
            "note": note or "",
        },
    )
    can = bumps <= int(state.get("max_bumps") or max_bumps)
    print(f"fable5 BUMP n={bumps}/{state.get('max_bumps')} axis={axis or '-'} depth={depth} can_continue={can}")
    if note:
        print(note)
    if not can:
        print("bump budget exhausted -> ship best-so-far or BLOCKED")
    return 0


def cmd_claims(run_dir: Path, verified: int, supported: int, unverified: int, contested: int) -> int:
    state_path = run_dir / "state.json"
    state = load_json(state_path)
    state["claim_counts"] = {
        "VERIFIED": verified,
        "SUPPORTED": supported,
        "UNVERIFIED": unverified,
        "CONTESTED": contested,
    }
    touch(state)
    save_json(state_path, state)
    append_ledger(run_dir, {"stage": "VERIFY", "event": "claims", "counts": state["claim_counts"]})
    print(
        "fable5 VERIFY "
        f"verified={verified} supported={supported} unverified={unverified} contested={contested}"
    )
    return 0


def cmd_stream_done(run_dir: Path, stream_id: str) -> int:
    state_path = run_dir / "state.json"
    state = load_json(state_path)
    open_s = list(state.get("open_streams") or [])
    done_s = list(state.get("done_streams") or [])
    if stream_id in open_s:
        open_s.remove(stream_id)
    if stream_id not in done_s:
        done_s.append(stream_id)
    state["open_streams"] = open_s
    state["done_streams"] = done_s
    # update plan statuses if present
    plan_path = run_dir / "plan.json"
    if plan_path.exists():
        plan = load_json(plan_path)
        for s in plan.get("streams") or []:
            if s.get("id") == stream_id:
                s["status"] = "done"
        save_json(plan_path, plan)
    touch(state)
    save_json(state_path, state)
    append_ledger(run_dir, {"stage": "EXECUTE", "event": "stream_done", "stream_id": stream_id})
    print(f"fable5 EXECUTE stream_done={stream_id} open={len(open_s)} done={len(done_s)}")
    return 0


def cmd_gate(run_dir: Path, passed: bool, avg: float | None, note: str | None) -> int:
    state_path = run_dir / "state.json"
    state = load_json(state_path)
    state["gate"] = {"pass": passed, "average": avg, "note": note or ""}
    state["stage"] = "SHIP" if passed else "BUMP"
    touch(state)
    save_json(state_path, state)
    append_ledger(
        run_dir,
        {
            "stage": "GATE",
            "event": "gate",
            "pass": passed,
            "average": avg,
            "note": note or "",
        },
    )
    status = "PASS" if passed else "FAIL"
    print(f"fable5 GATE {status} avg={avg}")
    return 0 if passed else 1


def cmd_blocked(run_dir: Path, reason: str) -> int:
    state_path = run_dir / "state.json"
    state = load_json(state_path)
    state["stage"] = "BLOCKED"
    state["blocked"] = reason
    touch(state)
    save_json(state_path, state)
    (run_dir / "BLOCKED.md").write_text(
        f"# BLOCKED\n\n{reason}\n\nupdated: {utc_now()}\n",
        encoding="utf-8",
    )
    append_ledger(run_dir, {"stage": "BLOCKED", "event": "blocked", "reason": reason})
    print(f"fable5 BLOCKED reason={reason}")
    return 2


def cmd_ship(run_dir: Path) -> int:
    state_path = run_dir / "state.json"
    meta = load_json(run_dir / "meta.json")
    state = load_json(state_path)
    state["stage"] = "SHIP"
    touch(state)
    save_json(state_path, state)
    summary = {
        "run_id": state.get("run_id"),
        "task": meta.get("task"),
        "mode": meta.get("mode"),
        "depth": state.get("depth"),
        "rounds": state.get("round"),
        "bumps": state.get("bumps"),
        "claim_counts": state.get("claim_counts"),
        "gate": state.get("gate"),
        "shipped_at": utc_now(),
    }
    save_json(run_dir / "summary.json", summary)
    append_ledger(run_dir, {"stage": "SHIP", "event": "shipped", "summary": summary})
    print(f"fable5 SHIP run={state.get('run_id')} gate={state.get('gate')}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Fable5 run state helper")
    parser.add_argument("--run", required=True, help="Path to run directory")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("status")

    p_stage = sub.add_parser("stage")
    p_stage.add_argument("name")
    p_stage.add_argument("--note", default=None)

    p_round = sub.add_parser("round")
    p_round.add_argument("number", type=int)

    p_bump = sub.add_parser("bump")
    p_bump.add_argument("--axis", default=None)
    p_bump.add_argument("--note", default=None)
    p_bump.add_argument("--raise-depth", action="store_true")

    p_claims = sub.add_parser("claims")
    p_claims.add_argument("--verified", type=int, default=0)
    p_claims.add_argument("--supported", type=int, default=0)
    p_claims.add_argument("--unverified", type=int, default=0)
    p_claims.add_argument("--contested", type=int, default=0)

    p_sd = sub.add_parser("stream-done")
    p_sd.add_argument("stream_id")

    p_gate = sub.add_parser("gate")
    g = p_gate.add_mutually_exclusive_group(required=True)
    g.add_argument("--pass", dest="passed", action="store_true")
    g.add_argument("--fail", dest="failed", action="store_true")
    p_gate.add_argument("--avg", type=float, default=None)
    p_gate.add_argument("--note", default=None)

    p_blocked = sub.add_parser("blocked")
    p_blocked.add_argument("--reason", required=True)

    sub.add_parser("ship")

    args = parser.parse_args(argv)
    run_dir = require_run(args.run)

    if args.cmd == "status":
        return cmd_status(run_dir)
    if args.cmd == "stage":
        return cmd_stage(run_dir, args.name, args.note)
    if args.cmd == "round":
        return cmd_round(run_dir, args.number)
    if args.cmd == "bump":
        return cmd_bump(run_dir, args.axis, args.note, args.raise_depth)
    if args.cmd == "claims":
        return cmd_claims(run_dir, args.verified, args.supported, args.unverified, args.contested)
    if args.cmd == "stream-done":
        return cmd_stream_done(run_dir, args.stream_id)
    if args.cmd == "gate":
        passed = bool(args.passed) and not bool(args.failed)
        return cmd_gate(run_dir, passed, args.avg, args.note)
    if args.cmd == "blocked":
        return cmd_blocked(run_dir, args.reason)
    if args.cmd == "ship":
        return cmd_ship(run_dir)
    raise SystemExit(f"unknown cmd {args.cmd}")


if __name__ == "__main__":
    raise SystemExit(main())

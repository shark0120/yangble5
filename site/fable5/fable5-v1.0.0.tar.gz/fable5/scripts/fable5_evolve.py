#!/usr/bin/env python3
"""Fable5 self-evolution harness (offline, gated).

Proposes skill improvements into .fable5/evolve/ and keeps them only if
verification suite passes. Never silently edits production skill without gates.

Usage:
  python fable5_evolve.py propose --note "add omega patience default"
  python fable5_evolve.py verify
  python fable5_evolve.py status
"""
from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent
REPO_ROOT = ROOT.parents[2] if (ROOT.parents[2] / "AGENTS.md").exists() else Path.cwd()
EVOLVE = REPO_ROOT / ".fable5" / "evolve"
PY = sys.executable


def utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def cmd_propose(note: str) -> int:
    EVOLVE.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    prop = {
        "id": stamp,
        "ts": utc(),
        "note": note,
        "status": "proposed",
        "gates": [
            "fable5_selftest.py",
            "fable5_cache_verify.py --evidence",
            "fable5_arena.py",
            "fable5_quality_fire.py --selftest",
        ],
        "rule": "apply to production skill only if all gates PASS and no cache regression",
    }
    path = EVOLVE / f"proposal-{stamp}.json"
    path.write_text(json.dumps(prop, indent=2) + "\n", encoding="utf-8")
    # snapshot current pin
    pin = ROOT / "references" / "cache_pin.json"
    if pin.exists():
        shutil.copy2(pin, EVOLVE / f"pin-before-{stamp}.json")
    print(f"fable5 EVOLVE proposed {path}")
    print("no production files modified; implement patch then run verify")
    return 0


def run(args: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(args, cwd=str(SCRIPTS), capture_output=True, text=True, check=False)


def cmd_verify() -> int:
    # Keep gates lean enough for interactive runs; full suite is cache_verify --evidence.
    gates = [
        [PY, "fable5_quality_fire.py", "--selftest"],
        [PY, "fable5_arena.py"],
        [PY, "fable5_cache_bench.py"],
        [PY, "fable5_router.py", "--corpus", str((SCRIPTS.parent / "references" / "trigger_corpus.jsonl"))],
    ]
    results = []
    ok = True
    for g in gates:
        cp = run(g)
        item = {
            "cmd": g,
            "rc": cp.returncode,
            "pass": cp.returncode == 0,
            "tail": (cp.stdout or cp.stderr)[-400:],
        }
        results.append(item)
        ok = ok and item["pass"]
        print(f"[{'PASS' if item['pass'] else 'FAIL'}] {' '.join(g[1:])}")
    EVOLVE.mkdir(parents=True, exist_ok=True)
    out = {
        "ts": utc(),
        "pass": ok,
        "results": results,
    }
    path = EVOLVE / f"verify-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}.json"
    path.write_text(json.dumps(out, indent=2) + "\n", encoding="utf-8")
    print(f"fable5 EVOLVE verify={'PASS' if ok else 'FAIL'} evidence={path}")
    return 0 if ok else 1


def cmd_status() -> int:
    if not EVOLVE.exists():
        print("fable5 EVOLVE no proposals yet")
        return 0
    props = sorted(EVOLVE.glob("proposal-*.json"))
    vers = sorted(EVOLVE.glob("verify-*.json"))
    print(f"proposals={len(props)} verifications={len(vers)}")
    if props:
        print("latest_proposal=", props[-1].name)
    if vers:
        v = json.loads(vers[-1].read_text(encoding="utf-8"))
        print(f"latest_verify={vers[-1].name} pass={v.get('pass')}")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("propose")
    p.add_argument("--note", required=True)
    sub.add_parser("verify")
    sub.add_parser("status")
    args = parser.parse_args(argv)
    if args.cmd == "propose":
        return cmd_propose(args.note)
    if args.cmd == "verify":
        return cmd_verify()
    if args.cmd == "status":
        return cmd_status()
    raise SystemExit("unknown")


if __name__ == "__main__":
    raise SystemExit(main())

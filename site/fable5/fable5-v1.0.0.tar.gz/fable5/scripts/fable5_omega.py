#!/usr/bin/env python3
"""Fable5 omega engine - unbounded escalation with diminishing-return stop."""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

DEFAULTS = {
    "epsilon": 0.05,
    "patience": 2,
    "max_steps": 12,
}

ESCALATIONS = {
    "truthfulness": "primary_retrieval+split_contested+dated_sources",
    "adversarial_hardness": "redteam_strikes+double_verifiers+kill_case_stream",
    "coverage": "critic_round+second_order+incentive+base_rate",
    "decision_usefulness": "option_matrix+kill_criteria+monitors+owner_timer",
    "structure_density": "retag+compress+best_of_n_rewrite",
    "calibration": "condition_claims+ranges+triggers",
    "implementability": "run_tests+interfaces+rollout_rollback",
    "dialectic_integrity": "steelman+premortem_merge",
}


def _say(msg: str) -> None:
    if os.environ.get("FABLE5_QUIET") in {"1", "true", "yes"}:
        return
    print(msg)


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def omega_path(run_dir: Path) -> Path:
    return run_dir / "omega.json"


def load(run_dir: Path) -> dict:
    path = omega_path(run_dir)
    if not path.exists():
        raise SystemExit(f"missing {path}; run init first")
    return json.loads(path.read_text(encoding="utf-8"))


def save(run_dir: Path, data: dict) -> None:
    data["updated_at"] = utc_now()
    omega_path(run_dir).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def cmd_init(run_dir: Path, epsilon: float, patience: int, max_steps: int) -> int:
    run_dir.mkdir(parents=True, exist_ok=True)
    data = {
        "enabled": True,
        "epsilon": epsilon,
        "patience": patience,
        "max_steps": max_steps,
        "step": 0,
        "no_gain_streak": 0,
        "quality_trace": [],
        "actions": [],
        "stopped": False,
        "stop_reason": None,
        "created_at": utc_now(),
        "updated_at": utc_now(),
    }
    state_path = run_dir / "state.json"
    if state_path.exists():
        st = json.loads(state_path.read_text(encoding="utf-8"))
        data["run_id"] = st.get("run_id")
        data["depth"] = st.get("depth") or "omega"
    save(run_dir, data)
    _say(f"fable5 OMEGA init epsilon={epsilon} patience={patience} max_steps={max_steps}")
    return 0


def cmd_status(run_dir: Path) -> int:
    data = load(run_dir)
    _say(
        "fable5 OMEGA "
        f"step={data.get('step')}/{data.get('max_steps')} "
        f"no_gain={data.get('no_gain_streak')}/{data.get('patience')} "
        f"stopped={data.get('stopped')} reason={data.get('stop_reason')}"
    )
    if data.get("quality_trace"):
        _say("quality_trace=" + str(data["quality_trace"]))
    if data.get("actions"):
        _say("last_action=" + str(data["actions"][-1]))
    if not data.get("stopped"):
        weakest = "coverage"
        if data.get("actions"):
            weakest = data["actions"][-1].get("next_axis_hint") or weakest
        _say("next=" + ESCALATIONS.get(weakest, ESCALATIONS["coverage"]))
    return 0


def cmd_step(run_dir: Path, axis: str, quality: float, note: str | None) -> int:
    data = load(run_dir)
    if data.get("stopped"):
        _say(f"fable5 OMEGA already stopped reason={data.get('stop_reason')}")
        return 2
    axis = axis or "coverage"
    if axis not in ESCALATIONS:
        raise SystemExit(f"unknown axis {axis}; choose {list(ESCALATIONS)}")
    step = int(data.get("step") or 0) + 1
    trace = list(data.get("quality_trace") or [])
    prev = trace[-1] if trace else None
    delta = None if prev is None else float(quality) - float(prev)
    action = {
        "step": step,
        "ts": utc_now(),
        "axis": axis,
        "action": ESCALATIONS[axis],
        "quality_before": prev,
        "quality_after": float(quality),
        "delta": delta,
        "note": note or "",
    }
    eps = float(data.get("epsilon") or DEFAULTS["epsilon"])
    if delta is None:
        no_gain = int(data.get("no_gain_streak") or 0)
    elif delta < eps:
        no_gain = int(data.get("no_gain_streak") or 0) + 1
    else:
        no_gain = 0
    trace.append(float(quality))
    actions = list(data.get("actions") or [])
    axes = list(ESCALATIONS)
    next_axis = axes[(axes.index(axis) + 1) % len(axes)] if delta is not None and delta < eps else axis
    action["next_axis_hint"] = next_axis
    actions.append(action)

    stopped = False
    reason = None
    if step >= int(data.get("max_steps") or DEFAULTS["max_steps"]):
        stopped = True
        reason = "safety_rail"
    elif no_gain >= int(data.get("patience") or DEFAULTS["patience"]) and step >= 2:
        stopped = True
        reason = "diminishing_returns"

    data.update({
        "step": step,
        "no_gain_streak": no_gain,
        "quality_trace": trace,
        "actions": actions,
        "stopped": stopped,
        "stop_reason": reason,
    })
    save(run_dir, data)
    _say(
        f"fable5 OMEGA step={step} axis={axis} action={ESCALATIONS[axis]} "
        f"quality={quality} delta={delta} no_gain={no_gain} stopped={stopped} reason={reason}"
    )
    if not stopped:
        _say(f"next_hint_axis={next_axis} next_action={ESCALATIONS[next_axis]}")
    return 0 if not stopped else 1


def cmd_decide(run_dir: Path, gate_pass: bool, quality: float) -> int:
    data = load(run_dir)
    data["final_quality"] = float(quality)
    data["final_gate_pass"] = bool(gate_pass)
    if gate_pass:
        data["stopped"] = True
        data["stop_reason"] = "gate_pass"
        save(run_dir, data)
        _say(f"fable5 OMEGA SHIP gate=PASS quality={quality}")
        return 0
    if data.get("stopped") and data.get("stop_reason") in {"safety_rail", "diminishing_returns"}:
        _say(f"fable5 OMEGA STOP gate=FAIL reason={data.get('stop_reason')} ship_best_so_far quality={quality}")
        return 1
    data["stopped"] = False
    data["stop_reason"] = None
    save(run_dir, data)
    _say(f"fable5 OMEGA CONTINUE gate=FAIL quality={quality}")
    return 2


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Fable5 omega controller")
    parser.add_argument("--run", required=True, type=Path)
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_init = sub.add_parser("init")
    p_init.add_argument("--epsilon", type=float, default=DEFAULTS["epsilon"])
    p_init.add_argument("--patience", type=int, default=DEFAULTS["patience"])
    p_init.add_argument("--max-steps", type=int, default=DEFAULTS["max_steps"])

    sub.add_parser("status")

    p_step = sub.add_parser("step")
    p_step.add_argument("--axis", required=True)
    p_step.add_argument("--quality", type=float, required=True)
    p_step.add_argument("--note", default=None)

    p_dec = sub.add_parser("decide")
    g = p_dec.add_mutually_exclusive_group(required=True)
    g.add_argument("--gate-pass", action="store_true")
    g.add_argument("--gate-fail", action="store_true")
    p_dec.add_argument("--quality", type=float, required=True)

    args = parser.parse_args(argv)
    run_dir = args.run
    if args.cmd == "init":
        return cmd_init(run_dir, args.epsilon, args.patience, args.max_steps)
    if args.cmd == "status":
        return cmd_status(run_dir)
    if args.cmd == "step":
        return cmd_step(run_dir, args.axis, args.quality, args.note)
    if args.cmd == "decide":
        return cmd_decide(run_dir, bool(args.gate_pass), args.quality)
    raise SystemExit("unknown command")


if __name__ == "__main__":
    raise SystemExit(main())

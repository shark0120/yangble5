#!/usr/bin/env python3
"""Evidence-based Fable5 cache verification.

Structural prompt-cache proxies with reproducible metrics.
Does not claim provider telemetry.

Usage:
  python fable5_cache_verify.py --evidence
  python fable5_cache_verify.py --evidence --json
  python fable5_cache_verify.py --write-pin
"""
from __future__ import annotations

import argparse
import os
import re
import hashlib
import json
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent
REFS = ROOT / "references"
CARD = SCRIPTS / "always_on_card.txt"
PIN = REFS / "cache_pin.json"
CORPUS = REFS / "trigger_corpus.jsonl"
PY = sys.executable


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def sha256_text(s: str) -> str:
    return sha256_bytes(s.encode("utf-8"))


def run(args: list[str]) -> subprocess.CompletedProcess:
    # Decode child stdout as UTF-8 (children emit UTF-8); the Windows locale codec
    # (cp950) would otherwise fail on CJK/emoji in the trigger corpus. errors=replace
    # keeps the harness alive even on unexpected bytes.
    return subprocess.run(
        args, cwd=str(SCRIPTS), capture_output=True, text=True,
        encoding="utf-8", errors="replace", check=False,
    )


def lcp_len(a: str, b: str) -> int:
    n = min(len(a), len(b))
    i = 0
    while i < n and a[i] == b[i]:
        i += 1
    return i


def extract_skill_stable_prefix(skill_text: str) -> str:
    begin = "<!-- CACHE_STABLE_PREFIX_BEGIN -->"
    end = "<!-- CACHE_STABLE_PREFIX_END -->"
    if begin not in skill_text or end not in skill_text:
        raise ValueError("SKILL.md missing CACHE_STABLE_PREFIX markers")
    return skill_text.split(begin, 1)[1].split(end, 1)[0]


def compute_pin() -> dict:
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    card = CARD.read_text(encoding="utf-8")
    if not card.endswith("\n"):
        card += "\n"
    stable = extract_skill_stable_prefix(skill)
    files = {
        "scripts/always_on_card.txt": sha256_file(CARD),
        "scripts/stable_pack.txt": sha256_file(SCRIPTS / "stable_pack.txt"),
        "scripts/fable5_stable_pack.py": sha256_file(SCRIPTS / "fable5_stable_pack.py"),
        "SKILL.md": sha256_file(ROOT / "SKILL.md"),
        "SKILL.md#stable_prefix": sha256_text(stable),
        "references/always-on.md": sha256_file(REFS / "always-on.md"),
        "references/cache-protocol.md": sha256_file(REFS / "cache-protocol.md"),
        "references/infinity.md": sha256_file(REFS / "infinity.md"),
        "references/elite.md": sha256_file(REFS / "elite.md"),
        "references/redteam.md": sha256_file(REFS / "redteam.md"),
        "references/grok-codex.md": sha256_file(REFS / "grok-codex.md"),
        "references/trigger_corpus.jsonl": sha256_file(CORPUS),
        "references/roles.md": sha256_file(REFS / "roles.md"),
        "references/autonomy.md": sha256_file(REFS / "autonomy.md"),
        "references/quality-rubric.md": sha256_file(REFS / "quality-rubric.md"),
        "references/stable_pack_meta.json": sha256_file(REFS / "stable_pack_meta.json"),
        "scripts/fable5_cache_card.py": sha256_file(SCRIPTS / "fable5_cache_card.py"),
        "scripts/fable5_router.py": sha256_file(SCRIPTS / "fable5_router.py"),
        "scripts/fable5_prompt_assemble.py": sha256_file(SCRIPTS / "fable5_prompt_assemble.py"),
        "scripts/fable5_cache_bench.py": sha256_file(SCRIPTS / "fable5_cache_bench.py"),
        "scripts/fable5_quality_fire.py": sha256_file(SCRIPTS / "fable5_quality_fire.py"),
        "scripts/fable5_runtime.py": sha256_file(SCRIPTS / "fable5_runtime.py"),
        "scripts/fable5_omega.py": sha256_file(SCRIPTS / "fable5_omega.py"),
        "scripts/fable5_arena.py": sha256_file(SCRIPTS / "fable5_arena.py"),
        "scripts/fable5_bakeoff.py": sha256_file(SCRIPTS / "fable5_bakeoff.py"),
        "scripts/fable5_orchestrate.py": sha256_file(SCRIPTS / "fable5_orchestrate.py"),
        "scripts/fable5_evolve.py": sha256_file(SCRIPTS / "fable5_evolve.py"),
        "agents/openai.yaml": sha256_file(ROOT / "agents" / "openai.yaml"),
    }
    return {
        "version": 2,
        "updated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "always_on_card_sha256": sha256_text(card),
        "files": files,
        "thresholds": {
            "min_trigger_hit_rate": 1.0,
            "min_lcp_ratio_multi_turn": 0.999,
            "min_prefix_stable_ratio": 1.0,
            "min_resume_identity_rate": 1.0,
            "min_bench_delta_over_naive": 0.5,
            "min_corpus_size": 40,
        },
    }


def write_pin() -> dict:
    pin = compute_pin()
    PIN.write_text(json.dumps(pin, indent=2, ensure_ascii=False) + "\n", encoding="utf-8", newline="\n")
    return pin


def check_encoding_clean() -> dict:
    bad_patterns = ["\ufffd", "芯蜓", "憭", "隤", "?�", ""]
    files = [ROOT / "SKILL.md", CARD, REFS / "always-on.md", REFS / "cache-protocol.md", SCRIPTS / "fable5_cache_card.py"]
    hits = []
    for f in files:
        t = f.read_text(encoding="utf-8")
        for pat in bad_patterns:
            if pat in t:
                hits.append({"file": f.name, "pattern": pat})
    return {
        "name": "encoding_clean",
        "pass": len(hits) == 0,
        "detail": "no mojibake markers" if not hits else "mojibake found",
        "metrics": {"hits": hits},
    }


def check_card_source_of_truth() -> dict:
    card = CARD.read_text(encoding="utf-8")
    if not card.endswith("\n"):
        return {"name": "card_source_of_truth", "pass": False, "detail": "card missing trailing newline", "metrics": {}}
    cp = run([PY, str(SCRIPTS / "fable5_cache_card.py")])
    ok = cp.returncode == 0 and cp.stdout == card
    h1 = run([PY, str(SCRIPTS / "fable5_cache_card.py"), "--hash"])
    h2 = run([PY, str(SCRIPTS / "fable5_cache_card.py"), "--hash"])
    det = h1.stdout == h2.stdout and h1.returncode == 0
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    digest = sha256_text(card)
    embedded = card.strip() in skill
    hash_embedded = digest in skill
    passed = ok and det and embedded and hash_embedded
    return {
        "name": "card_source_of_truth",
        "pass": passed,
        "detail": "file==stdout; deterministic; embedded",
        "metrics": {
            "card_sha256": digest,
            "stdout_matches_file": ok,
            "hash_deterministic": det,
            "embedded_in_skill": embedded,
            "hash_embedded_in_skill": hash_embedded,
        },
    }


def check_pin() -> dict:
    if not PIN.exists():
        return {"name": "pin_match", "pass": False, "detail": "cache_pin.json missing", "metrics": {}}
    pin = json.loads(PIN.read_text(encoding="utf-8"))
    current = compute_pin()
    mismatches = []
    for k, v in pin.get("files", {}).items():
        cur = current["files"].get(k)
        if cur != v:
            mismatches.append({"file": k, "pinned": v, "current": cur})
    if pin.get("always_on_card_sha256") != current["always_on_card_sha256"]:
        mismatches.append({
            "file": "always_on_card_sha256",
            "pinned": pin.get("always_on_card_sha256"),
            "current": current["always_on_card_sha256"],
        })
    return {
        "name": "pin_match",
        "pass": len(mismatches) == 0,
        "detail": "all pinned hashes match" if not mismatches else f"{len(mismatches)} drift(s)",
        "metrics": {"mismatches": mismatches, "pinned_files": len(pin.get("files", {}))},
    }


def check_multi_turn_lcp() -> dict:
    sys.path.insert(0, str(SCRIPTS))
    import fable5_prompt_assemble as asm  # type: ignore

    u = "fix flaky auth race"
    turns = [
        (u, None, None),
        (u, "autonomy.md", "fable5 RESUME run=demo stage=EXECUTE"),
        (u, "pipeline.md", "fable5 RESUME run=demo stage=VERIFY"),
        (u, "quality-rubric.md", "fable5 RESUME run=demo stage=SYNTHESIZE"),
        (u, "roles.md", "fable5 RESUME run=demo stage=CRITIC"),
        (u, "cache-protocol.md", "fable5 RESUME run=demo stage=GATE"),
    ]
    prompts = [asm.assemble(t, ref, resume) for t, ref, resume in turns]
    prefix = asm.stable_prefix()
    starts = [p.startswith(prefix) for p in prompts]
    ratios = []
    for p in prompts[1:]:
        ratios.append(lcp_len(prompts[0], p) / max(len(prompts[0]), 1))
    min_ratio = min(ratios) if ratios else 1.0
    lcp01 = lcp_len(prompts[0], prompts[1])
    prefix_covered = lcp01 >= len(prefix)
    passed = all(starts) and prefix_covered and min_ratio >= 0.999
    return {
        "name": "multi_turn_lcp",
        "pass": passed,
        "detail": f"min_lcp_ratio={min_ratio:.6f} prefix_covered={prefix_covered}",
        "metrics": {
            "prefix_sha256": sha256_text(prefix),
            "prefix_len": len(prefix),
            "all_start_with_prefix": all(starts),
            "lcp_prefix_covered": prefix_covered,
            "lcp_ratios_vs_turn0": [round(r, 6) for r in ratios],
            "min_lcp_ratio": round(min_ratio, 6),
            "threshold": 0.999,
        },
    }


def check_resume_identity() -> dict:
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        task = "Due diligence on CacheCorp"
        boot1 = run([
            PY, str(SCRIPTS / "fable5_boot.py"), "--task", task, "--depth", "standard",
            "--run-root", str(root / "runs"), "--fresh", "--json",
        ])
        if boot1.returncode != 0:
            return {"name": "resume_identity", "pass": False, "detail": f"boot1 failed: {boot1.stderr}", "metrics": {}}
        info1 = json.loads(boot1.stdout)
        run_dir = info1["run_dir"]
        run([PY, str(SCRIPTS / "fable5_state.py"), "--run", run_dir, "stage", "EXECUTE"])
        boot2 = run([
            PY, str(SCRIPTS / "fable5_boot.py"), "--task", task, "--depth", "standard",
            "--run-root", str(root / "runs"), "--json",
        ])
        info2 = json.loads(boot2.stdout)
        same = info2.get("resumed") is True and info2.get("run_id") == info1.get("run_id")
        boot3 = run([
            PY, str(SCRIPTS / "fable5_boot.py"), "--task", task + " DIFFERENT", "--depth", "standard",
            "--run-root", str(root / "runs"), "--fresh", "--json",
        ])
        info3 = json.loads(boot3.stdout)
        diff_ok = info3.get("run_id") != info1.get("run_id")
        return {
            "name": "resume_identity",
            "pass": bool(same and diff_ok),
            "detail": "same task resumes run_id; different task new run",
            "metrics": {
                "run_id_1": info1.get("run_id"),
                "run_id_2": info2.get("run_id"),
                "resumed": info2.get("resumed"),
                "stage_after_resume": info2.get("stage"),
                "different_task_new_run": diff_ok,
            },
        }


def check_trigger_corpus() -> dict:
    cp = run([PY, str(SCRIPTS / "fable5_router.py"), "--corpus", str(CORPUS), "--json"])
    if cp.returncode not in (0, 1):
        return {"name": "trigger_corpus", "pass": False, "detail": cp.stderr or cp.stdout, "metrics": {}}
    data = json.loads(cp.stdout)
    rate = float(data.get("trigger_hit_rate") or 0)
    bad = []
    for row in data.get("rows") or []:
        if bool(row["expected"]["trigger"]) != bool(row["got"]["trigger"]):
            bad.append({"text": row["text"], "expected": row["expected"], "got": row["got"]})
    return {
        "name": "trigger_corpus",
        "pass": rate >= 1.0 and cp.returncode == 0,
        "detail": f"trigger_hit_rate={rate}",
        "metrics": {
            "trigger_hit_rate": rate,
            "depth_hit_rate": data.get("depth_hit_rate"),
            "total": data.get("total"),
            "mismatches": bad,
        },
    }


def check_agents_injection() -> dict:
    global_agents = Path.home() / ".codex" / "AGENTS.md"
    # Optional per-project AGENTS.md; set FABLE5_PROJECT_AGENTS to its path to include it.
    project_agents_env = os.environ.get("FABLE5_PROJECT_AGENTS", "")
    project_agents = Path(project_agents_env) if project_agents_env else None
    g = global_agents.read_text(encoding="utf-8") if global_agents.exists() else ""
    pr = (
        project_agents.read_text(encoding="utf-8")
        if project_agents is not None and project_agents.exists()
        else ""
    )
    g_ok = "FABLE5-ALWAYS-ON:BEGIN" in g and "fable5" in g.lower()
    # When no project AGENTS.md is configured, the global block alone is sufficient.
    p_ok = (
        True
        if project_agents is None
        else ("FABLE5-ALWAYS-ON:BEGIN" in pr and "fable5" in pr.lower())
    )
    yaml = (ROOT / "agents" / "openai.yaml").read_text(encoding="utf-8")
    implicit = "allow_implicit_invocation: true" in yaml
    return {
        "name": "agents_injection",
        "pass": g_ok and p_ok and implicit,
        "detail": "global+project AGENTS blocks present; implicit invocation true",
        "metrics": {"global": g_ok, "project": p_ok, "implicit": implicit},
    }


def check_anti_churn() -> dict:
    # In-process deterministic hash (avoid 20 process spawns; still proves byte-stability).
    import hashlib
    card_path = SCRIPTS / "always_on_card.txt"
    text = card_path.read_text(encoding="utf-8")
    if not text.endswith("\n"):
        text += "\n"
    hashes = []
    for _ in range(20):
        hashes.append(hashlib.sha256(text.encode("utf-8")).hexdigest())
    # one subprocess cross-check against CLI
    cp = run([PY, str(SCRIPTS / "fable5_cache_card.py"), "--hash"])
    cli = None
    for ln in (cp.stdout or "").splitlines():
        if ln.startswith("sha256="):
            cli = ln.split("=", 1)[1]
            break
    ok = len(set(hashes)) == 1 and cli == hashes[0] and cp.returncode == 0
    return {
        "name": "anti_churn_20",
        "pass": ok,
        "detail": f"unique_hashes={len(set(hashes))} cli_match={cli == hashes[0]}",
        "metrics": {"sha256": hashes[0] if hashes else None, "n": 20, "cli": cli},
    }



def check_corpus_size() -> dict:
    n = 0
    for line in CORPUS.read_text(encoding="utf-8").splitlines():
        if line.strip():
            n += 1
    return {
        "name": "corpus_size",
        "pass": n >= 40,
        "detail": f"corpus_size={n}",
        "metrics": {"total": n, "threshold": 40},
    }


def check_cache_bench() -> dict:
    cp = run([PY, str(SCRIPTS / "fable5_cache_bench.py"), "--json"])
    if cp.returncode not in (0, 1) or not cp.stdout.strip():
        return {
            "name": "cache_bench",
            "pass": False,
            "detail": f"bench failed rc={cp.returncode}: {cp.stderr[:300]}",
            "metrics": {},
        }
    data = json.loads(cp.stdout)
    return {
        "name": "cache_bench",
        "pass": bool(data.get("pass")) and cp.returncode == 0,
        "detail": (
            f"naive={data.get('naive', {}).get('min_lcp_ratio')} "
            f"fable5={data.get('fable5', {}).get('min_lcp_ratio')} "
            f"delta={data.get('delta_min_lcp_ratio')}"
        ),
        "metrics": data,
    }


def check_mutation_canary() -> dict:
    """Prove verifier is not a always-green rubber stamp.

    Temporarily mutate always_on_card.txt in a temp copy style by checking that
    a deliberate content change would break card embedding / pin logic using
    pure functions (no lasting mutation).
    """
    card = CARD.read_text(encoding="utf-8")
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    digest = sha256_text(card if card.endswith("\n") else card + "\n")
    # append mutation so version renames cannot break the canary
    mutated = card.rstrip() + "\n# MUTATED_CANARY_BYTE\n"
    if mutated == card:
        return {"name": "mutation_canary", "pass": False, "detail": "could not mutate marker", "metrics": {}}
    mut_digest = sha256_text(mutated if mutated.endswith("\n") else mutated + "\n")
    # Current skill should embed real card, not mutated
    real_embedded = card.strip() in skill
    mut_embedded = mutated.strip() in skill
    # Pin should match real digest
    pin = json.loads(PIN.read_text(encoding="utf-8")) if PIN.exists() else {}
    pin_ok = pin.get("always_on_card_sha256") == digest
    # Canary passes if real is locked and mutation is distinguishable
    passed = real_embedded and (not mut_embedded) and pin_ok and digest != mut_digest
    return {
        "name": "mutation_canary",
        "pass": passed,
        "detail": "mutated card hash differs; skill embeds only real card; pin locks real hash",
        "metrics": {
            "real_sha256": digest,
            "mutated_sha256": mut_digest,
            "real_embedded": real_embedded,
            "mutated_embedded": mut_embedded,
            "pin_locks_real": pin_ok,
            "hashes_differ": digest != mut_digest,
        },
    }


def check_repo_user_sync() -> dict:
    cp = run([PY, str(SCRIPTS / "fable5_sync.py"), "--check", "--json"])
    if not cp.stdout.strip():
        return {"name": "repo_user_sync", "pass": False, "detail": cp.stderr or "no output", "metrics": {}}
    data = json.loads(cp.stdout)
    return {
        "name": "repo_user_sync",
        "pass": bool(data.get("in_sync")),
        "detail": "repo and %USERPROFILE%/.codex/skills/fable5 in sync" if data.get("in_sync") else "drift detected",
        "metrics": data,
    }


def check_role_prompt_stability() -> dict:
    """Role prompts must be pinned and free of turn-volatile tokens."""
    roles = (REFS / "roles.md").read_text(encoding="utf-8")
    volatile = []
    for pat in [r"\b20\d{2}-\d{2}-\d{2}\b", r"run_id=", r"nonce=", r"generated_at="]:
        if re.search(pat, roles):
            volatile.append(pat)
    # hash must match pin if present
    pin = json.loads(PIN.read_text(encoding="utf-8")) if PIN.exists() else {}
    h = sha256_file(REFS / "roles.md")
    pinned = (pin.get("files") or {}).get("references/roles.md")
    pin_ok = pinned == h if pinned else True
    return {
        "name": "role_prompt_stability",
        "pass": len(volatile) == 0 and pin_ok and len(roles) > 200,
        "detail": "roles.md stable and pinned" if pin_ok and not volatile else "roles.md unstable or unpinned",
        "metrics": {"sha256": h, "pinned": pinned, "volatile_patterns": volatile, "size": len(roles)},
    }





def check_stable_pack() -> dict:
    sys.path.insert(0, str(SCRIPTS))
    import fable5_stable_pack as sp  # type: ignore
    rep = sp.verify_pack()
    meta_path = REFS / "stable_pack_meta.json"
    meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.exists() else {}
    length_ok = int(meta.get("stable_pack_len") or 0) >= 10000
    return {
        "name": "stable_pack",
        "pass": bool(rep.get("pass")) and length_ok,
        "detail": f"{rep.get('detail')} len={meta.get('stable_pack_len')}",
        "metrics": {**rep, "meta": meta, "min_len": 10000, "length_ok": length_ok},
    }


def check_quality_fire() -> dict:
    cp = run([PY, str(SCRIPTS / "fable5_quality_fire.py"), "--selftest"])
    return {
        "name": "quality_fire_selftest",
        "pass": cp.returncode == 0,
        "detail": (cp.stdout.strip().splitlines() or [""])[0],
        "metrics": {"stdout": cp.stdout[-500:], "stderr": cp.stderr[-300:]},
    }


def check_arena() -> dict:
    cp = run([PY, str(SCRIPTS / "fable5_arena.py"), "--json"])
    if cp.returncode not in (0, 1) or not (cp.stdout or "").strip():
        return {"name": "arena", "pass": False, "detail": f"arena failed rc={cp.returncode}", "metrics": {"stderr": cp.stderr[-400:]}}
    data = json.loads(cp.stdout)
    return {
        "name": "arena",
        "pass": bool(data.get("pass")) and cp.returncode == 0,
        "detail": f"delta={data.get('delta_best_minus_single')} best={((data.get('best_fable5') or {}).get('depth'))}",
        "metrics": data,
    }


def check_omega_engine() -> dict:
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        rd = Path(td) / "run"
        rd.mkdir()
        c1 = run([PY, str(SCRIPTS / "fable5_omega.py"), "--run", str(rd), "init", "--epsilon", "0.05", "--patience", "2", "--max-steps", "5"])
        c2 = run([PY, str(SCRIPTS / "fable5_omega.py"), "--run", str(rd), "step", "--axis", "coverage", "--quality", "3.5"])
        c3 = run([PY, str(SCRIPTS / "fable5_omega.py"), "--run", str(rd), "step", "--axis", "adversarial_hardness", "--quality", "3.52"])
        c4 = run([PY, str(SCRIPTS / "fable5_omega.py"), "--run", str(rd), "step", "--axis", "truthfulness", "--quality", "3.53"])
        data = json.loads((rd / "omega.json").read_text(encoding="utf-8"))
        stopped = bool(data.get("stopped"))
        reason = data.get("stop_reason")
        ok = c1.returncode == 0 and stopped and reason == "diminishing_returns"
        return {
            "name": "omega_engine",
            "pass": ok,
            "detail": f"stopped={stopped} reason={reason} steps={data.get('step')}",
            "metrics": data,
        }


def check_runtime() -> dict:
    cp = run([PY, str(SCRIPTS / "fable5_runtime.py"), "--selftest"])
    return {
        "name": "runtime_selftest",
        "pass": cp.returncode == 0,
        "detail": (cp.stdout.strip().splitlines() or [""])[-1][:200],
        "metrics": {"stdout": cp.stdout[-800:], "stderr": cp.stderr[-300:]},
    }


def check_bakeoff() -> dict:
    cp = run([PY, str(SCRIPTS / "fable5_bakeoff.py"), "--selftest"])
    ok = cp.returncode == 0 and "SELFTEST PASS" in (cp.stdout or "")
    return {
        "name": "bakeoff_selftest",
        "pass": ok,
        "detail": (cp.stdout.strip().splitlines() or [""])[-1][:200],
        "metrics": {"stdout": cp.stdout[-1000:], "stderr": cp.stderr[-300:]},
    }


def check_orchestrate() -> dict:
    cp = run([PY, str(SCRIPTS / "fable5_orchestrate.py"), "--selftest", "--quick"])
    ok = cp.returncode == 0 and "SELFTEST PASS" in (cp.stdout or "")
    return {
        "name": "orchestrate_selftest",
        "pass": ok,
        "detail": (cp.stdout.strip().splitlines() or [""])[-1][:200],
        "metrics": {"stdout": cp.stdout[-1200:], "stderr": cp.stderr[-300:]},
    }


def check_substance_dominates_structure() -> dict:
    """Breakthrough invariant: shape-only can pass structural fire but fails bakeoff substance."""
    sys.path.insert(0, str(SCRIPTS))
    from fable5_quality_fire import evaluate as qf_eval  # type: ignore
    from fable5_bakeoff import scorecard as bake_score  # type: ignore

    shape_only = """# Bottom line
Ship immediately. VERIFIED everything. SUPPORTED all upsides. UNVERIFIED nothing important. CONTESTED none.

## Findings
- Claim A VERIFIED sim://primary/a
- Claim B SUPPORTED sim://b
- Claim C UNVERIFIED
- Claim D CONTESTED

## Red-team / disconfirm
Adversarial review complete.

## Steelman for the aggressive option
Strongest case noted.

## Pre-mortem
Six months later failure mode noted.

## Implementation path
1. tests/
2. pytest -q exit code 0
3. rollout flag rollback

## Kill-criteria
Abort if threshold misses.

## Unknowns
Residual risk / open question / not yet closed.

Padding padding padding padding padding padding padding padding padding padding padding padding.

---
fable5 | depth=omega | streams=12 | rounds=3 | verifiers=5 | drafts=3
survived=3/4 | bumped=no | mode=decision | run=shape
weakest: none
next_token_spend: none
gate: PASS avg=5.0
redteam: clean
"""
    q = qf_eval(shape_only, "max", findings_total=40, critic_rounds=3, drafts=3)
    b = bake_score(shape_only)
    # bakeoff scorecard API may vary - handle dict-like
    if not isinstance(b, dict):
        b = getattr(b, "__dict__", {"raw": str(b)})
    flags = b.get("gaming_flags") or b.get("flags") or []
    substance = b.get("substance") or b.get("substance_score") or (b.get("parts") or {}).get("substance")
    # Accept either explicit flags or low substance
    substance_fail = False
    if isinstance(flags, list) and flags:
        substance_fail = True
    if substance is not None:
        try:
            substance_fail = substance_fail or float(substance) < 3.5
        except Exception:
            pass
    # Also try nested
    if not substance_fail and isinstance(b, dict):
        # demo output style
        for k in ("decorated_vacuity", "empty_sections", "fake_evidence", "structure_over_substance"):
            if k in str(b).lower():
                substance_fail = True
    structural_high = float(q.get("average") or 0) >= 4.5
    ok = structural_high and substance_fail
    return {
        "name": "substance_dominates_structure",
        "pass": ok,
        "detail": f"structural_avg={q.get('average')} substance={substance} flags={flags}",
        "metrics": {"structural": q, "bakeoff": b, "invariant": "shape-only must not clear substance"},
    }

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Fable5 cache evidence verifier")
    parser.add_argument("--evidence", action="store_true")
    parser.add_argument(
        "--profile",
        choices=["core", "full"],
        default="core",
        help="core=fast cache+substance gates; full=include arena+orchestrate",
    )
    parser.add_argument("--write-pin", action="store_true")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args(argv)

    if args.write_pin:
        pin = write_pin()
        print(f"wrote {PIN} files={len(pin['files'])} card={pin['always_on_card_sha256'][:12]}")
        if not args.evidence:
            return 0

    if not args.evidence and not args.write_pin:
        args.evidence = True

    # Profiles:
    #   core = cache + substance anti-gaming + runtime/omega (interactive-safe)
    #   full = core + arena + orchestrate (heavier)
    core_fns = [
        check_encoding_clean,
        check_stable_pack,
        check_card_source_of_truth,
        check_pin,
        check_multi_turn_lcp,
        check_resume_identity,
        check_trigger_corpus,
        check_corpus_size,
        check_cache_bench,
        check_quality_fire,
        check_runtime,
        check_bakeoff,
        check_substance_dominates_structure,
        check_omega_engine,
        check_mutation_canary,
        check_repo_user_sync,
        check_role_prompt_stability,
        check_agents_injection,
        check_anti_churn,
    ]
    full_fns = [
        check_arena,
        check_orchestrate,
    ]
    selected = list(core_fns)
    if args.profile == "full":
        selected.extend(full_fns)

    checks = []
    for fn in selected:
        t0 = time.time()
        try:
            result = fn()
        except Exception as e:  # noqa: BLE001
            result = {
                "name": getattr(fn, "__name__", "check"),
                "pass": False,
                "detail": repr(e),
                "metrics": {},
            }
        result = dict(result)
        result["seconds"] = round(time.time() - t0, 3)
        checks.append(result)

    def _metrics(name: str) -> dict:
        for c in checks:
            if c.get("name") == name:
                return c.get("metrics") or {}
        return {}

    def _pass(name: str):
        for c in checks:
            if c.get("name") == name:
                return c.get("pass")
        return None

    bench = _metrics("cache_bench")
    lcp = _metrics("multi_turn_lcp")
    trig = _metrics("trigger_corpus")
    card = _metrics("card_source_of_truth")

    summary = {
        "ts": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "profile": args.profile,
        "pass": all(bool(c.get("pass")) for c in checks),
        "checks": checks,
        "headline_metrics": {
            "trigger_hit_rate": trig.get("trigger_hit_rate"),
            "min_lcp_ratio": lcp.get("min_lcp_ratio"),
            "prefix_len": lcp.get("prefix_len"),
            "resume_identity": _pass("resume_identity"),
            "pin_match": _pass("pin_match"),
            "always_on_card_sha256": card.get("card_sha256"),
            "bench_delta": bench.get("delta_min_lcp_ratio"),
            "bench_fable5_lcp": (bench.get("fable5") or {}).get("min_lcp_ratio") if isinstance(bench.get("fable5"), dict) else bench.get("fable5_min_lcp_ratio"),
            "bench_naive_lcp": (bench.get("naive") or {}).get("min_lcp_ratio") if isinstance(bench.get("naive"), dict) else bench.get("naive_min_lcp_ratio"),
            "repo_user_in_sync": _pass("repo_user_sync"),
            "corpus_size": _metrics("corpus_size").get("total"),
            "total_seconds": round(sum(float(c.get("seconds") or 0) for c in checks), 3),
        },
        "method": {
            "note": "Structural prompt-cache proxies + substance anti-gaming; not provider cache telemetry.",
            "profile": args.profile,
            "proxies": [
                "byte_stable_prefix",
                "pinned_hashes",
                "multi_turn_lcp_ratio",
                "resume_identity",
                "trigger_corpus_hit_rate",
                "bakeoff_substance",
                "anti_churn",
            ],
        },
    }

    out_path = args.out
    if out_path is None:
        try:
            # skill path: .../.agents/skills/fable5 ; repo root is parents[2]
            repo_root = ROOT.parents[2] if (ROOT.parents[2] / "AGENTS.md").exists() else Path.cwd()
            ev_root = repo_root / ".fable5" / "cache-evidence"
            ev_root.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            out_path = ev_root / f"evidence-{args.profile}-{stamp}.json"
        except OSError:
            out_path = None
    if out_path is not None:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        summary["evidence_path"] = str(out_path.resolve())

    if args.json:
        json.dump(summary, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        status = "PASS" if summary["pass"] else "FAIL"
        print(f"fable5_cache_verify: {status} profile={args.profile}")
        hm = summary["headline_metrics"]
        print(
            "headline: "
            f"trigger_hit_rate={hm.get('trigger_hit_rate')} "
            f"min_lcp_ratio={hm.get('min_lcp_ratio')} "
            f"prefix_len={hm.get('prefix_len')} "
            f"resume_identity={hm.get('resume_identity')} "
            f"pin_match={hm.get('pin_match')} "
            f"seconds={hm.get('total_seconds')}"
        )
        print(f"card_sha256={hm.get('always_on_card_sha256')}")
        print(
            "bench: "
            f"naive_lcp={hm.get('bench_naive_lcp')} "
            f"fable5_lcp={hm.get('bench_fable5_lcp')} "
            f"delta={hm.get('bench_delta')} "
            f"corpus={hm.get('corpus_size')} "
            f"sync={hm.get('repo_user_in_sync')}"
        )
        for c in checks:
            mark = "PASS" if c.get("pass") else "FAIL"
            sec = c.get("seconds")
            extra = f" ({sec}s)" if sec is not None else ""
            print(f"  [{mark}] {c.get('name')}: {c.get('detail')}{extra}")
        if out_path is not None:
            print(f"evidence: {out_path}")
        if args.profile == "core":
            print("note: arena+orchestrate are full-profile only (use --profile full)")
        print("method: structural proxies + substance anti-gaming (not provider telemetry)")
    return 0 if summary["pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

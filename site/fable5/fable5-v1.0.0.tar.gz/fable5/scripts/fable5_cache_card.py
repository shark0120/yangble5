#!/usr/bin/env python3
"""Print the stable Fable5 always-on cache card (single source of truth file)."""
from __future__ import annotations

import argparse
import hashlib
import sys
from pathlib import Path

CARD_PATH = Path(__file__).with_name("always_on_card.txt")


def load_card() -> str:
    text = CARD_PATH.read_text(encoding="utf-8")
    if not text.endswith("\n"):
        text += "\n"
    return text


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Print stable Fable5 cache card")
    parser.add_argument("--hash", action="store_true")
    parser.add_argument("--path", action="store_true")
    args = parser.parse_args(argv)
    card = load_card()
    output = ""
    if args.path:
        output += str(CARD_PATH) + "\n"
    output += card
    if args.hash:
        output += "sha256=" + hashlib.sha256(card.encode("utf-8")).hexdigest() + "\n"
    # Text-mode stdout rewrites LF to CRLF on Windows, breaking byte-stable
    # source-of-truth checks. Emit UTF-8 bytes so the cached card is identical
    # on every supported platform.
    sys.stdout.buffer.write(output.encode("utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

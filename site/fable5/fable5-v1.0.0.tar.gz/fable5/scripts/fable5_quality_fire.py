#!/usr/bin/env python3
"""Fable5 quality fire - elite structural quality checks beyond basic gate."""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path

TAGS = ("VERIFIED", "SUPPORTED", "UNVERIFIED", "CONTESTED")
TAG_RE = re.compile(r"\b(VERIFIED|SUPPORTED|UNVERIFIED|CONTESTED)\b")
FOOTER_RE = re.compile(r"fable5\s*\|", re.I)
GATE_RE = re.compile(r"gate:\s*(PASS|FAIL)\b", re.I)
KILL_RE = re.compile(r"\b(kill[- ]?criteria|stop if|what would change my mind|rollback trigger|abort if)\b", re.I)
PREMORTEM_RE = re.compile(r"\b(pre[- ]?mortem|if this fails|failure mode|6 months later|autopsy)\b", re.I)
STEEL_RE = re.compile(r"\b(steelman|strongest case for|best argument against|opposing view)\b", re.I)
RED_RE = re.compile(r"\b(red[- ]?team|adversarial|counterargument|disconfirm)\b", re.I)
UNKNOWN_RE = re.compile(r"\b(unknown|unverified|open questions?|residual risk|uncertainty|not yet)\b", re.I)
FAKE_PREC = re.compile(r"\b\d+\.\d{3,}%\b")
URL_RE = re.compile(r"https?://[^\s)\]]+")
COND_RE = re.compile(r"\b(under (pilot |test )?conditions?|scoped to|only if|conditional on|given that)\b", re.I)
RANGE_RE = re.compile(r"\b(\d+\s*-\s*\d+|between \d+|at least \d+|threshold|p99|within \d+)\b", re.I)
OMEGA_RE = re.compile(r"\b(omega|diminishing returns|epsilon|weakest axis|escalat)\b", re.I)
PRIMARY_RE = re.compile(r"\b(primary|dated|sim://dated|official|filing|source of record)\b", re.I)
TEST_RE = re.compile(r"\b(pytest|npm test|go test|cargo test|ran tests?|test(s)? (pass|fail)|exit code)\b", re.I)

DEPTH_MIN_AVG = {"micro": 3.0, "lite": 3.5, "standard": 4.0, "max": 4.4, "insane": 4.6, "omega": 4.8}

def score_axes(text: str, depth: str) -> dict[str, int]:
    tags = TAG_RE.findall(text)
    counts = {t: tags.count(t) for t in TAGS}
    weak = counts["UNVERIFIED"] + counts["CONTESTED"] + counts["SUPPORTED"]
    has_unknown = bool(UNKNOWN_RE.search(text))
    has_url = bool(URL_RE.search(text)) or bool(re.search(r"`[^`]+`|\b[\w.-]+\.(py|ts|tsx|md|json)\b", text))
    no_fake = FAKE_PREC.search(text) is None
    has_steel = bool(STEEL_RE.search(text))
    has_pre = bool(PREMORTEM_RE.search(text))
    has_red = bool(RED_RE.search(text))
    has_kill = bool(KILL_RE.search(text))
    has_footer = bool(FOOTER_RE.search(text)) and bool(GATE_RE.search(text))
    has_decision = bool(re.search(r"\b(recommend|bottom line|decision|fix|patch|next step|ship|do not)\b", text, re.I))
    has_cond = bool(COND_RE.search(text))
    has_range = bool(RANGE_RE.search(text))
    has_omega = bool(OMEGA_RE.search(text))
    has_primary = bool(PRIMARY_RE.search(text))
    length_ok = 400 <= len(text) <= 120_000

    truth = 3
    if tags and has_url and no_fake:
        truth = 5 if has_unknown else 4
    elif not no_fake:
        truth = 2

    adv = 2
    if weak > 0:
        adv = 4
    if has_red and weak > 0:
        adv = 5
    if counts["VERIFIED"] >= 5 and weak == 0 and len(text) > 1500:
        adv = 1

    section_hits = sum(
        1
        for s in [
            "## Findings",
            "## Red-team",
            "## Kill-criteria",
            "## Unknowns",
            "## Implementation",
            "## Steelman",
            "## Pre-mortem",
        ]
        if s.lower() in text.lower()
    )
    tag_density = len(tags) / max(len(text) / 500.0, 1.0)
    coverage = 3
    if has_unknown and length_ok:
        coverage = 4
    if has_red and has_unknown and section_hits >= 4:
        coverage = 5
    if depth in {"insane", "omega"} and section_hits >= 6 and tag_density >= 1.0:
        coverage = 5

    decision = 4 if has_decision else 2
    if has_decision and has_kill:
        decision = 5

    structure = 5 if has_footer and tags else (3 if tags else 2)

    calibration = 3
    if has_unknown and no_fake:
        calibration = 4
    if has_unknown and no_fake and weak > 0 and has_cond:
        calibration = 5
    if depth in {"insane", "omega"} and has_cond and has_range and has_unknown and no_fake:
        calibration = 5
    if depth == "omega" and has_omega and has_cond and has_unknown:
        calibration = 5
    if weak == 0 and counts["VERIFIED"] >= 3 and depth in {"max", "insane", "omega"}:
        calibration = min(calibration, 2)

    implement = 3
    if TEST_RE.search(text) or re.search(r"\b(rollout|rollback|interface|API|migration)\b", text, re.I):
        implement = 4
    if TEST_RE.search(text) and has_decision:
        implement = 5

    dialectic = 2
    if has_steel or has_pre:
        dialectic = 4
    if has_steel and has_pre:
        dialectic = 5
    if depth in {"max", "insane", "omega"} and dialectic < 4:
        dialectic = min(dialectic, 2)

    return {
        "truthfulness": truth,
        "adversarial_hardness": adv,
        "coverage": coverage,
        "decision_usefulness": decision,
        "structure_density": structure,
        "calibration": calibration,
        "implementability": implement,
        "dialectic_integrity": dialectic,
    }



def composite_score(axes: dict[str, int], *, findings_total: int = 0, critic_rounds: int = 0, drafts: int = 1, depth: str = "standard") -> float:
    """Continuous 0-100 score with depth-sensitive work terms.

    Axis average saturates quickly; work intensity + depth keep omega above insane.
    Caps are set so typical insane < 98 and omega can still gain.
    """
    avg = sum(axes.values()) / max(len(axes), 1)
    axis_part = (avg / 5.0) * 60.0  # up to 60
    # slower log growth for findings
    find_part = min(18.0, math.log1p(max(0, findings_total)) / math.log1p(300) * 18.0)
    critic_part = min(6.0, critic_rounds * 0.75)
    draft_part = min(6.0, max(0, drafts - 1) * 0.9)
    depth_bonus = {
        "micro": 0.0,
        "lite": 1.0,
        "standard": 3.0,
        "max": 6.0,
        "insane": 9.0,
        "omega": 12.0,
    }.get((depth or "standard").lower(), 3.0)
    if findings_total <= 0:
        depth_bonus = 0.0
    # omega-only continuity bonus if substantial work
    omega_bonus = 0.0
    if (depth or "").lower() == "omega" and findings_total >= 100:
        omega_bonus = 3.0
    total = axis_part + find_part + critic_part + draft_part + depth_bonus + omega_bonus
    return round(min(100.0, total), 3)


def evaluate(text: str, depth: str = "standard", *, findings_total: int = 0, critic_rounds: int = 0, drafts: int = 1) -> dict:
    depth = (depth or "standard").lower()
    axes = score_axes(text, depth)
    avg = sum(axes.values()) / len(axes)
    min_avg = DEPTH_MIN_AVG.get(depth, 4.0)
    tags = TAG_RE.findall(text)
    checks = {"has_tags": bool(tags), "has_footer": bool(FOOTER_RE.search(text)) and bool(GATE_RE.search(text)), "has_kill_criteria": bool(KILL_RE.search(text)), "has_unknowns": bool(UNKNOWN_RE.search(text)), "has_redteam_language": bool(RED_RE.search(text)), "has_steelman": bool(STEEL_RE.search(text)), "has_premortem": bool(PREMORTEM_RE.search(text)), "no_fake_precision": FAKE_PREC.search(text) is None}
    hard_fails = []
    if depth in {"standard", "max", "insane", "omega"}:
        if not checks["has_tags"]: hard_fails.append("missing claim tags")
        if not checks["has_footer"]: hard_fails.append("missing fable5 footer/gate line")
        if not checks["has_unknowns"]: hard_fails.append("missing explicit unknowns")
    if depth in {"max", "insane", "omega"}:
        if not checks["has_kill_criteria"]: hard_fails.append("max+ requires kill-criteria")
        if not checks["has_redteam_language"]: hard_fails.append("max+ requires redteam/disconfirm language")
    if depth in {"insane", "omega"}:
        if not checks["has_steelman"]: hard_fails.append("insane requires steelman residue")
        if not checks["has_premortem"]: hard_fails.append("insane requires premortem residue")
    passed = avg >= min_avg and not hard_fails and checks["no_fake_precision"]
    weakest = min(axes, key=axes.get)
    advice = []
    if not passed:
        advice.append(f"weakest_axis={weakest} score={axes[weakest]}")
        advice.extend(hard_fails)
        if avg < min_avg: advice.append(f"avg {avg:.2f} < min_avg {min_avg} for depth={depth}")
    else:
        advice.append("quality fire passed; optional spend on residual weakest axis")
    comp = composite_score(
        axes,
        findings_total=findings_total,
        critic_rounds=critic_rounds,
        drafts=drafts,
        depth=depth,
    )
    return {
        "pass": passed,
        "depth": depth,
        "average": round(avg, 3),
        "composite": comp,
        "min_avg": min_avg,
        "axes": axes,
        "checks": checks,
        "hard_fails": hard_fails,
        "weakest": weakest,
        "advice": advice,
        "auto_bump": not passed,
        "work": {
            "findings_total": findings_total,
            "critic_rounds": critic_rounds,
            "drafts": drafts,
        },
    }

def selftest() -> int:
    bad = "Certainly everything is fine."
    r1 = evaluate(bad, "standard")
    if r1["pass"]:
        print("selftest FAIL: bad text passed"); return 1
    good = """# Bottom line
Do not full-scale ship. Run a 30-day pilot. VERIFIED core demo works; unit economics remain UNVERIFIED.

## Findings
- Single pilot customer only. UNVERIFIED at scale
- Competitor shipped similar payload. VERIFIED https://example.com/x
- Safety cert in progress via blog. SUPPORTED

## Red-team / disconfirm
Missing-killer: third-party MTBA telemetry. Incentive: vendor narrative over field reliability.

## Steelman for shipping now
If competitor lock-in is real and pilot NPS holds, delayed entry could be costly.

## Pre-mortem
Six months later the rollout fails because assist rate collapses on unionized night shifts.

## Kill-criteria
Abort expansion if MTBA < 4h in third-party bakeoff or assist rate > 12%.

## Unknowns
Battery cycle life and site integration cost remain open questions.

Padding for length gate. Residual risk stays explicit. Decision usefulness requires staged capital only.

---
fable5 | depth=max | streams=12 | rounds=2 | verifiers=5 | drafts=3
survived=1/3 | bumped=no | mode=research | run=selftest
weakest: unit economics
next_token_spend: customer references + telemetry
gate: PASS avg=4.5
redteam: patched
"""
    r2 = evaluate(good, "max")
    if not r2["pass"]:
        print("selftest FAIL: good max text failed", r2); return 1
    print("fable5_quality_fire: SELFTEST PASS")
    print("  bad_avg=%s good_avg=%s good_weakest=%s" % (r1["average"], r2["average"], r2["weakest"]))
    return 0

def main(argv=None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path)
    parser.add_argument("--text")
    parser.add_argument("--depth", default="standard")
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args(argv)
    if args.selftest: return selftest()
    if args.input: text = args.input.read_text(encoding="utf-8")
    elif args.text is not None: text = args.text
    else: raise SystemExit("provide --input/--text or --selftest")
    result = evaluate(text, args.depth)
    if args.json:
        json.dump(result, sys.stdout, indent=2, ensure_ascii=False); sys.stdout.write("\\n")
    else:
        status = "PASS" if result["pass"] else "FAIL"
        print("fable5_quality_fire: %s depth=%s avg=%s min=%s" % (status, result["depth"], result["average"], result["min_avg"]))
        for k, v in result["axes"].items(): print(f"  {k}: {v}/5")
        print("advice:")
        for a in result["advice"]: print(f"  - {a}")
    return 0 if result["pass"] else 1

if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3
"""Fable5 orchestrate - the executable grok4.5 + codex engine, and an autonomy-loop gate.

Two modes, one honest engine:

  SELF-AUDIT (default)  - runs the skill's own allow-listed tools as experiments (offline dogfood).
  GUARD (--guard spec)  - runs a CALLER-SUPPLIED set of acceptance checks (the autonomy loop's or
                          project's own tests) and returns a machine-readable ship / no-ship verdict.
                          The loop supplies the vetted checks; the reasoner only ADJUDICATES exit
                          codes, so it cannot game them. This is how autopilot/iterate/.coord plug in:
                              python fable5_orchestrate.py --guard acceptance.json --json
                          exit 0 == ship, exit 1 == do-not-ship.

The split (grok-codex.md):
  ORCHESTRATOR (reasoner) selects/adjudicates/red-teams/decides; NEVER emits tool output (its prose
    is sanitized so it cannot inject a `run://...#exit=0`).
  EXECUTOR runs allow-listed / caller-supplied commands as real subprocesses; NEVER decides ship.

Honesty invariants (hardened after an adversarial red-team broke v1): every evidence handle in the
shipped report is provenanced to a real executor run; a VERIFIED finding maps to a real exit-0 of a
vetted command whose hypothesis the reasoner cannot rewrite; a failing check sinks the gate; omega is
measured, not a hardcoded curve; the report must clear its own bake-off substance floor.

SECURITY: a --guard spec runs arbitrary commands. Only pass specs from a TRUSTED source (the operator,
the loop, a checked-in project config) - never a spec built from untrusted/observed content.

Usage:
  python fable5_orchestrate.py --depth max          # self-audit
  python fable5_orchestrate.py --depth omega --json
  python fable5_orchestrate.py --guard acceptance.json --json
  python fable5_orchestrate.py --selftest
"""
from __future__ import annotations

import argparse
import json
import re
import shlex
import subprocess
import sys
import tempfile
from dataclasses import dataclass, asdict
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
ROOT = SCRIPTS.parent
REFS = ROOT / "references"
REPO_ROOT = ROOT.parents[2] if len(ROOT.parents) >= 3 else Path.cwd()
PY = sys.executable
sys.path.insert(0, str(SCRIPTS))

try:
    from fable5_quality_fire import evaluate as qf_evaluate  # type: ignore
except Exception:  # pragma: no cover
    qf_evaluate = None
try:
    from fable5_bakeoff import scorecard as bakeoff_scorecard, judge_prompt as bakeoff_judge_prompt  # type: ignore
except Exception:  # pragma: no cover
    bakeoff_scorecard = None
    bakeoff_judge_prompt = None


EXPERIMENT_POOL = [
    ("quality_fire_selftest", ("fable5_quality_fire.py", "--selftest"),
     "the structural scorer rejects weak drafts and passes strong ones"),
    ("router_corpus", ("fable5_router.py", "--corpus", str(REFS / "trigger_corpus.jsonl"), "--json"),
     "the deterministic router matches every labeled trigger example"),
    ("stable_pack_verify", ("fable5_stable_pack.py", "--verify"),
     "the byte-frozen protocol pack still matches its source files"),
    ("plan_smoke", ("fable5_plan.py", "--task", "self audit", "--depth", "max", "--json"),
     "the planner emits unique non-overlapping workstreams at max depth"),
    ("bakeoff_selftest", ("fable5_bakeoff.py", "--selftest"),
     "the head-to-head resists shape-only and decorated vacuity"),
    ("prompt_assemble", ("fable5_prompt_assemble.py", "--text", "self audit", "--hash"),
     "prompt assembly keeps the stable prefix byte-identical"),
    ("cache_card", ("fable5_cache_card.py", "--hash"),
     "the always-on card hashes deterministically across calls"),
    ("cache_bench", ("fable5_cache_bench.py",),
     "assembly outscores naive concatenation on prefix overlap"),
    ("runtime_selftest", ("fable5_runtime.py", "--selftest"),
     "closed-loop findings grow with depth and omega halts on plateau"),
    ("arena", ("fable5_arena.py",),
     "the depth ladder outscores a single-shot baseline"),
]
POOL_BY_ARGV = {argv: (name, hyp) for (name, argv, hyp) in EXPERIMENT_POOL}
ALLOWED_ARGVS = set(POOL_BY_ARGV)

DEPTH_EXPERIMENTS = {"micro": 1, "lite": 2, "standard": 3, "max": 4, "insane": 6, "omega": 6}

QF_AXES = {
    "truthfulness", "adversarial_hardness", "coverage", "decision_usefulness",
    "structure_density", "calibration", "implementability", "dialectic_integrity",
}

_HANDLE_RE = re.compile(r"\b(?:run|sim|http|file)://\S*", re.I)
_REPORT_HANDLE_RE = re.compile(r"run://[^\s`]+#exit=[-\d]+")
_FAKE_RE = re.compile(r"(sim://|\bTODO\b|\bplaceholder\b|<fill[-_ ]?in>)", re.I)


def _sanitize(text: str) -> str:
    return _HANDLE_RE.sub("[redacted-handle]", (text or "")).replace("`", "'")


# ---- executor ------------------------------------------------------------

@dataclass
class ExecResult:
    name: str
    argv: tuple
    exit_code: int
    ok: bool
    stdout_excerpt: str
    stderr_excerpt: str
    evidence_handle: str


class Executor:
    """Codex role. Runs commands. Returns raw truth. Never editorializes a PASS."""

    def __init__(self):
        self.log: list[ExecResult] = []

    def run(self, name: str, argv, cwd: Path | None = None, prefix_python: bool = True,
            timeout: int = 300) -> ExecResult:
        argv = tuple(argv)
        cmd = ([PY, *argv] if prefix_python else list(argv))
        try:
            cp = subprocess.run(
                cmd, cwd=str(cwd or SCRIPTS), capture_output=True, text=True,
                encoding="utf-8", errors="replace", timeout=timeout, check=False,
            )
            exit_code, out, err = cp.returncode, cp.stdout or "", cp.stderr or ""
        except FileNotFoundError as e:
            exit_code, out, err = 127, "", f"command not found: {e}"
        except subprocess.TimeoutExpired:
            exit_code, out, err = 124, "", f"timeout after {timeout}s"
        except Exception as e:  # pragma: no cover
            exit_code, out, err = 125, "", f"executor error: {e}"
        res = ExecResult(name=name, argv=argv, exit_code=exit_code, ok=(exit_code == 0),
                         stdout_excerpt=out.strip()[-300:], stderr_excerpt=err.strip()[-200:],
                         evidence_handle=f"run://{' '.join(argv)}#exit={exit_code}")
        self.log.append(res)
        return res

    # back-compat convenience for the self-audit pool (python-prefixed, cwd=scripts)
    def run_tool(self, name: str, argv) -> ExecResult:
        return self.run(name, argv, cwd=SCRIPTS, prefix_python=True)

    def ok_handles(self) -> set[str]:
        return {r.evidence_handle for r in self.log if r.ok}

    def all_handles(self) -> set[str]:
        return {r.evidence_handle for r in self.log}


# ---- checks & reasoner ---------------------------------------------------

@dataclass
class Check:
    name: str
    argv: tuple
    hypothesis: str
    cwd: Path
    prefix_python: bool


@dataclass
class Finding:
    id: str
    hypothesis: str
    status: str
    evidence: str


def _verdict(ex: ExecResult) -> str:
    # proposer != evaluator: derived purely from the executor's real exit code.
    if ex.ok:
        return "VERIFIED"
    if ex.exit_code == 1:
        return "CONTESTED"
    return "UNVERIFIED"


class Reasoner:
    name = "base"

    def orient(self, task: str) -> dict:
        raise NotImplementedError

    def select(self, depth: str) -> list[tuple]:
        raise NotImplementedError

    def redteam(self, findings: list[Finding], depth: str, mode: str) -> list[str]:
        raise NotImplementedError

    def judge(self, challenger: str, opponent: str) -> dict:
        raise NotImplementedError


class DeterministicReasoner(Reasoner):
    name = "deterministic"

    def orient(self, task: str) -> dict:
        t = (task or "").lower()
        mode = "debug" if any(k in t for k in ("fix", "bug", "fail", "audit", "guard", "verify")) else "research"
        return {"mode": mode, "goal": _sanitize(f"evidence-backed report for: {task}"),
                "risk_if_wrong": "shipping on unproven evidence", "irreversible": False}

    def select(self, depth: str) -> list[tuple]:
        import os as _os
        n = DEPTH_EXPERIMENTS.get(depth, 3)
        if _os.environ.get("FABLE5_ORCH_QUICK") in {"1", "true", "yes"}:
            # evidence-suite budget: keep scaling lite<max but avoid the heavy tail
            n = min(n, {"lite": 2, "standard": 2, "max": 3, "insane": 3, "omega": 3}.get(depth, 2))
        return [argv for (_n, argv, _h) in EXPERIMENT_POOL[: n]]

    def redteam(self, findings: list[Finding], depth: str, mode: str) -> list[str]:
        strikes = [f"missing_killer/high: {f.id} is {f.status}; its hypothesis is not currently supported"
                   for f in findings if f.status != "VERIFIED"]
        if mode == "self-audit":
            strikes.append("incentive/high: every experiment is the skill auditing itself; internal "
                           "self-consistency is not external competitiveness versus the native model")
        else:
            strikes.append("incentive/med: green acceptance checks prove the checks passed, not that "
                           "the checks fully cover the change; coverage gaps stay a residual risk")
        return strikes

    def judge(self, challenger: str, opponent: str) -> dict:
        if bakeoff_scorecard is None:
            return {"winner": "tie", "authoritative": False, "reason": "bakeoff unavailable"}
        ch = bakeoff_scorecard(challenger, "max", "challenger")
        op = bakeoff_scorecard(opponent, "max", "opponent")
        margin = ch["combined"] - op["combined"]
        winner = "tie" if abs(margin) < 0.05 else ("challenger" if margin > 0 else "opponent")
        return {"winner": winner, "authoritative": False,
                "challenger_substance": ch["substance"], "opponent_substance": op["substance"],
                "reason": "deterministic heuristic floor; run an LLM judge for the authoritative call"}


class LLMReasoner(Reasoner):
    """Live orchestrator via injected call_llm(prompt)->str, with cassette replay. Cannot override a
    real tool failure (verdict is exit-code-derived)."""

    name = "llm"

    def __init__(self, call_llm=None, cassette: dict | None = None):
        self._call = call_llm
        self._cassette = dict(cassette or {})
        self._det = DeterministicReasoner()

    def _ask(self, key: str, prompt: str):
        if key in self._cassette:
            return self._cassette[key]
        if self._call is None:
            return None
        try:
            out = self._call(prompt)
            self._cassette[key] = out
            return out
        except Exception:
            return None

    def orient(self, task):
        return self._det.orient(task)

    def select(self, depth):
        return self._det.select(depth)

    def redteam(self, findings, depth, mode):
        return self._det.redteam(findings, depth, mode)

    def judge(self, challenger, opponent):
        prompt = bakeoff_judge_prompt(challenger, opponent) if bakeoff_judge_prompt else ""
        out = self._ask("judge", prompt)
        if not out:
            d = self._det.judge(challenger, opponent)
            d["reason"] = "LLM unavailable; deterministic fallback"
            return d
        try:
            data = json.loads(out)
            data["authoritative"] = True
            return data
        except Exception:
            return {"winner": "tie", "authoritative": False, "reason": "unparseable judge output"}


# ---- report synthesis ----------------------------------------------------

def _build_report(task: str, orient: dict, findings: list[Finding], strikes: list[str],
                  depth: str, gate_line: str, mode: str) -> str:
    verified = [f for f in findings if f.status == "VERIFIED"]
    total = len(findings)
    n_ver = len(verified)
    if mode == "guard":
        sound = ("Every acceptance check passed" if n_ver == total and total
                 else f"Only {n_ver} of {total} acceptance checks passed, so this must NOT ship")
        head = (f"For {task}: {n_ver} of {total} caller-supplied acceptance checks are VERIFIED by "
                f"exit code. {sound}. Ship only if every load-bearing check passes; residual risk is "
                f"whatever the checks do not cover. Scoped to the supplied check set.")
    else:
        sound = ("Every experiment passed, so the internal machinery is self-consistent"
                 if n_ver == total and total else
                 f"Only {n_ver} of {total} experiments passed, so the internal machinery is NOT fully sound")
        head = (f"For {task}: the skill's tools ran for real and {n_ver} of {total} hypotheses are "
                f"VERIFIED by exit code. {sound}. Competitiveness versus the native Fable5 model is "
                f"UNVERIFIED offline and needs a live bake-off. Recommend a live head-to-head; do not "
                f"claim parity from a self-audit alone. Scoped to offline tool runs only.")
    L = ["# Bottom line", _sanitize(head), "", "## Findings"]
    for f in findings:
        L.append(f"- {_sanitize(f.hypothesis)} -- {f.status}.")
        L.append(f"  Evidence: `{f.evidence}`")
    L += ["", "## Red-team / disconfirm"]
    for s in strikes:
        L.append(f"- {_sanitize(s)}")
    L += [
        "",
        "## Steelman for trusting the audit",
        "If the checks faithfully proxy the real acceptance bar, then green exit codes plus a cache "
        "overlap near unity are strong signals the work is sound -- but only while that proxy holds, "
        "which the incentive strike disputes.",
        "",
        "## Pre-mortem",
        "Six months out this fails if someone treats a green gate as full coverage: the checks were "
        "always partial, the live judge was never run, and gaps hid behind exit-0. Early warning: "
        "checks skipped, needs_llm_judge ignored, fabricated handles return.",
        "",
        "## Implementation path",
        "1. Keep the exit-code evidence trail for every check.",
        "2. For competitiveness, run the Layer-2 judge on a real challenger and opponent pair.",
        "3. Ship only on a real gate PASS and a cleared substance floor.",
        "",
        "## Kill-criteria",
        "Do not ship if any load-bearing check exits non-zero, if the report trips decorated_vacuity, "
        "or if a required live judge bake-off is skipped. Conditional on the checks being load-bearing.",
        "",
        "## Unknowns",
        _sanitize("UNVERIFIED / open question / residual risk: whatever the supplied checks do not "
                  "exercise, and real competitiveness versus the native model, stay unsettled here."),
        "",
        "---",
        f"fable5 | depth={depth} | streams={total} | rounds=1 | verifiers=exit-code | drafts=1",
        f"survived={n_ver}/{max(1, total)} | bumped=orchestrate | mode={orient['mode']} | run={mode}",
        "weakest: see quality fire",
        "next_token_spend: live LLM-judge bake-off vs native Fable5",
        gate_line,
        f"redteam: {'patched' if strikes else 'clean'}",
    ]
    return "\n".join(L) + "\n"


def _score(report: str, depth: str) -> tuple[float, str]:
    if qf_evaluate is None:
        return 0.0, "coverage"
    try:
        q = qf_evaluate(report, depth)
        return float(q.get("average") or 0.0), q.get("weakest") or "coverage"
    except Exception:
        return 0.0, "coverage"


# ---- the shared assessment pipeline --------------------------------------

@dataclass
class OrchestrationResult:
    task: str
    mode: str
    depth: str
    reasoner: str
    orient: dict
    findings: list
    strikes: list
    report: str
    exec_log: list
    gate: dict
    self_bakeoff: dict
    omega: dict | None
    invariants: dict
    ship: bool


def _assess(task: str, depth: str, reasoner: Reasoner, checks: list[Check], allowlist: set,
            min_frac: float, mode: str, run_dir: Path | None, do_omega: bool) -> OrchestrationResult:
    ex = Executor()
    orient = reasoner.orient(task)

    findings: list[Finding] = []
    for i, c in enumerate(checks, 1):
        if tuple(c.argv) not in allowlist:  # fail closed: only vetted commands
            raise ValueError(f"check argv not in allow-list: {c.argv}")
        res = ex.run(c.name, c.argv, cwd=c.cwd, prefix_python=c.prefix_python)
        findings.append(Finding(id=f"E{i}", hypothesis=c.hypothesis, status=_verdict(res),
                                evidence=res.evidence_handle))

    omega_meta = None
    if do_omega:
        omega_meta = _run_omega(ex, task, orient, findings, depth, mode)

    strikes = reasoner.redteam(findings, depth, mode)

    tmp = run_dir or Path(tempfile.mkdtemp(prefix="f5orch_"))
    tmp.mkdir(parents=True, exist_ok=True)
    provisional = _build_report(task, orient, findings, strikes, depth, "gate: PENDING avg=?", mode)
    report_path = tmp / "report.md"
    report_path.write_text(provisional, encoding="utf-8")
    gate_res = ex.run("gate", ("fable5_gate.py", "--input", str(report_path), "--min-avg", "4.0", "--json"),
                      cwd=SCRIPTS, prefix_python=True)
    qavg, weakest = _score(provisional, depth)
    gate_ok = gate_res.ok
    report = _build_report(task, orient, findings, strikes, depth,
                           f"gate: {'PASS' if gate_ok else 'FAIL'} avg={qavg}", mode)
    report_path.write_text(report, encoding="utf-8")

    self_bakeoff = {}
    if bakeoff_scorecard is not None:
        try:
            sc = bakeoff_scorecard(report, "max", "self")
            self_bakeoff = {"substance": sc["substance"], "heuristic_clear": sc["heuristic_clear"],
                            "gaming_flags": sc["gaming_flags"], "concreteness": sc["parts"]["concreteness"]}
        except Exception:
            self_bakeoff = {}

    verified = [f for f in findings if f.status == "VERIFIED"]
    verified_fraction = len(verified) / max(1, len(findings))
    experiments_pass = verified_fraction >= min_frac

    report_handles = set(_REPORT_HANDLE_RE.findall(report))
    ok_handles = ex.ok_handles()
    all_handles = ex.all_handles()
    check_argvs = {tuple(c.argv) for c in checks}
    invariants = {
        "verified_backed_by_exit0": all(f.evidence in ok_handles for f in verified),
        "report_handles_all_executor_produced": report_handles <= all_handles,
        "no_fabricated_evidence": _FAKE_RE.search(report) is None,
        "checks_allowlisted": all(tuple(r.argv) in allowlist for r in ex.log
                                  if r.name != "gate" and not r.name.startswith("omega_")),
        "footer_gate_matches_real": (f"gate: {'PASS' if gate_ok else 'FAIL'} avg={qavg}") in report,
        "own_report_clears_floor": bool(self_bakeoff.get("heuristic_clear", False)),
        "checks_pass_threshold": experiments_pass,
        "verified_fraction": round(verified_fraction, 3),
        "min_verified_fraction": min_frac,
        "real_tool_runs": len([r for r in ex.log if r.name != "gate"]),
    }
    if omega_meta is not None:
        invariants["omega_trace_measured"] = omega_meta.get("measured", False)

    ship = bool(gate_ok and experiments_pass)
    gate = {"structural_exit_code": gate_res.exit_code, "structural_pass": gate_ok,
            "quality_avg": qavg, "weakest": weakest, "checks_pass": experiments_pass,
            "verified_fraction": round(verified_fraction, 3), "pass": ship}

    if run_dir is not None:
        (run_dir / "orchestration.json").write_text(json.dumps({
            "task": task, "mode": mode, "depth": depth, "reasoner": reasoner.name, "ship": ship,
            "findings": [asdict(f) for f in findings], "gate": gate, "self_bakeoff": self_bakeoff,
            "exec_log": [asdict(r) for r in ex.log], "invariants": invariants, "omega": omega_meta,
        }, indent=2, ensure_ascii=False), encoding="utf-8")

    return OrchestrationResult(
        task=task, mode=mode, depth=depth, reasoner=reasoner.name, orient=orient,
        findings=[asdict(f) for f in findings], strikes=strikes, report=report,
        exec_log=[asdict(r) for r in ex.log], gate=gate, self_bakeoff=self_bakeoff,
        omega=omega_meta, invariants=invariants, ship=ship,
    )


def _run_omega(ex: Executor, task: str, orient: dict, findings: list[Finding], depth: str, mode: str) -> dict:
    rd = Path(tempfile.mkdtemp(prefix="f5omega_"))
    ex.run("omega_init", ("fable5_omega.py", "--run", str(rd), "init", "--patience", "2", "--max-steps", "8"),
           cwd=SCRIPTS, prefix_python=True)
    import os as _os
    _quick = _os.environ.get("FABLE5_ORCH_QUICK") in {"1", "true", "yes"}
    remaining = [argv for (_n, argv, _h) in EXPERIMENT_POOL
                 if argv not in {tuple(r.argv) for r in ex.log}]
    if _quick:
        remaining = remaining[:2]
    trace, steps, stop_reason = [], 0, None
    for argv in remaining:
        name, hyp = POOL_BY_ARGV[argv]
        res = ex.run_tool(name, argv)
        findings.append(Finding(id=f"E{len(findings)+1}", hypothesis=hyp, status=_verdict(res),
                                evidence=res.evidence_handle))
        interim = _build_report(task, orient, findings,
                                DeterministicReasoner().redteam(findings, depth, mode), depth,
                                "gate: PENDING avg=?", mode)
        if bakeoff_scorecard is not None:
            q = bakeoff_scorecard(interim, "max", "omega")["substance"]
        else:
            q = _score(interim, depth)[0]
        weakest = _score(interim, depth)[1]
        axis = weakest if weakest in QF_AXES else "coverage"
        ex.run(f"omega_step{steps+1}", ("fable5_omega.py", "--run", str(rd), "step", "--axis", axis,
               "--quality", f"{q:.3f}"), cwd=SCRIPTS, prefix_python=True)
        trace.append(round(q, 3))
        steps += 1
        try:
            od = json.loads((rd / "omega.json").read_text(encoding="utf-8"))
        except Exception:
            od = {}
        if od.get("stopped"):
            stop_reason = od.get("stop_reason")
            break
    return {"stopped": True, "stop_reason": stop_reason or "coverage_exhausted", "steps": steps,
            "quality_trace": trace, "measured": True,
            "note": "quality_trace = real bakeoff substance of the growing report at each step"}


# ---- public entrypoints --------------------------------------------------

def orchestrate(task: str, depth: str = "max", reasoner: Reasoner | None = None,
                run_dir: Path | None = None) -> OrchestrationResult:
    """SELF-AUDIT mode: run the skill's own allow-listed tools as experiments."""
    reasoner = reasoner or DeterministicReasoner()
    depth = (depth or "max").lower()
    selected = [tuple(a) for a in reasoner.select(depth)]
    checks = []
    for argv in selected:
        if argv not in POOL_BY_ARGV:
            raise ValueError(f"selected experiment not in pool: {argv}")
        name, hyp = POOL_BY_ARGV[argv]
        checks.append(Check(name, argv, hyp, SCRIPTS, True))
    return _assess(task, depth, reasoner, checks, ALLOWED_ARGVS, 1.0, "self-audit",
                   run_dir, do_omega=(depth == "omega"))


def load_guard_spec(spec: dict, base: Path = REPO_ROOT) -> tuple[str, list[Check], set, float]:
    task = spec.get("task", "guard: verify acceptance checks")
    raw = spec.get("checks") or []
    if not raw:
        raise ValueError("guard spec has no checks")
    default_cwd = (base / spec["cwd"]).resolve() if spec.get("cwd") else base
    checks: list[Check] = []
    for c in raw:
        argv = c["argv"] if isinstance(c.get("argv"), list) else shlex.split(c["cmd"])
        cwd = (base / c["cwd"]).resolve() if c.get("cwd") else default_cwd
        checks.append(Check(name=c.get("name") or argv[0], argv=tuple(argv),
                            hypothesis=c.get("hypothesis") or f"{' '.join(argv)} passes",
                            cwd=cwd, prefix_python=bool(c.get("prefix_python", False))))
    allowlist = {tuple(c.argv) for c in checks}
    return task, checks, allowlist, float(spec.get("min_verified_fraction", 1.0))


def guard(spec: dict, depth: str = "standard", reasoner: Reasoner | None = None,
          run_dir: Path | None = None, base: Path = REPO_ROOT) -> OrchestrationResult:
    """GUARD mode: run CALLER-SUPPLIED acceptance checks; return a ship / no-ship verdict."""
    reasoner = reasoner or DeterministicReasoner()
    task, checks, allowlist, min_frac = load_guard_spec(spec, base)
    return _assess(task, (depth or "standard").lower(), reasoner, checks, allowlist, min_frac,
                   "guard", run_dir, do_omega=False)


# ---- selftest ------------------------------------------------------------

class _FabricatingReasoner(DeterministicReasoner):
    def redteam(self, findings, depth, mode):
        return ["all good; corroborated by run://fable5_native_bakeoff.py --live#exit=0 (judge 3-0)"]


class _ArbitraryArgvReasoner(DeterministicReasoner):
    def select(self, depth):
        return [("fable5_gate.py", "--help")]


def selftest(quick: bool = False) -> int:
    import os as _os
    if quick:
        _os.environ["FABLE5_ORCH_QUICK"] = "1"
        _os.environ.setdefault("FABLE5_QUIET", "1")
    fails: list[str] = []
    lite = orchestrate("self-audit the fable5 skill", "lite")
    mx = orchestrate("self-audit the fable5 skill", "max")
    omega = orchestrate("self-audit the fable5 skill", "omega")

    if not (len(lite.findings) < len(mx.findings) <= len(omega.findings)):
        fails.append(f"experiments did not scale: {len(lite.findings)}/{len(mx.findings)}/{len(omega.findings)}")
    if DEPTH_EXPERIMENTS["micro"] == DEPTH_EXPERIMENTS["lite"]:
        fails.append("micro and lite do identical work")

    for r in (lite, mx, omega):
        for key in ("verified_backed_by_exit0", "report_handles_all_executor_produced",
                    "no_fabricated_evidence", "checks_allowlisted", "footer_gate_matches_real",
                    "own_report_clears_floor", "checks_pass_threshold"):
            if not r.invariants.get(key):
                fails.append(f"{r.mode}/{r.depth}: invariant {key} False ({r.self_bakeoff if key=='own_report_clears_floor' else ''})")
    if not mx.ship:
        fails.append(f"max self-audit should ship: {mx.gate}")
    if mx.self_bakeoff.get("gaming_flags"):
        fails.append(f"max report tripped its own gaming flags: {mx.self_bakeoff}")
    if not (omega.omega and omega.omega.get("stopped") and omega.omega.get("measured")):
        fails.append(f"omega not measured/stopped: {omega.omega}")

    # red-team replays
    fab = orchestrate("self-audit", "lite", reasoner=_FabricatingReasoner())
    if "fable5_native_bakeoff" in fab.report:
        fails.append("fabricated handle survived into the report")
    if not fab.invariants.get("report_handles_all_executor_produced"):
        fails.append("report-provenance invariant should hold after sanitization")
    rejected = False
    try:
        orchestrate("self-audit", "lite", reasoner=_ArbitraryArgvReasoner())
    except ValueError:
        rejected = True
    if not rejected:
        fails.append("arbitrary argv was NOT rejected by the allow-list")

    # GUARD mode: a passing check ships; a failing check does not, and reports honestly.
    good_spec = {"task": "guard demo", "min_verified_fraction": 1.0, "checks": [
        {"name": "qf", "argv": [PY, str(SCRIPTS / "fable5_quality_fire.py"), "--selftest"],
         "hypothesis": "the structural scorer selftest passes"},
        {"name": "bo", "argv": [PY, str(SCRIPTS / "fable5_bakeoff.py"), "--selftest"],
         "hypothesis": "the bake-off anti-gaming selftest passes"}]}
    g_ok = guard(good_spec, "standard")
    if not g_ok.ship:
        fails.append(f"guard should ship when all checks pass: {g_ok.gate}")
    if g_ok.mode != "guard":
        fails.append("guard result mode should be 'guard'")

    bad_spec = {"task": "guard demo fail", "min_verified_fraction": 1.0, "checks": [
        {"name": "qf", "argv": [PY, str(SCRIPTS / "fable5_quality_fire.py"), "--selftest"],
         "hypothesis": "the structural scorer selftest passes"},
        {"name": "boom", "argv": [PY, "-c", "import sys; sys.exit(1)"],
         "hypothesis": "a load-bearing check that fails"}]}
    g_bad = guard(bad_spec, "standard")
    if g_bad.ship:
        fails.append("guard must NOT ship when a check fails")
    if g_bad.invariants.get("checks_pass_threshold"):
        fails.append("checks_pass_threshold should be False on a failing check")
    if "must NOT ship" not in g_bad.report:
        fails.append("guard report should state it must not ship on failure")
    # honesty invariants still hold even on the failing run
    for key in ("verified_backed_by_exit0", "report_handles_all_executor_produced", "checks_allowlisted"):
        if not g_bad.invariants.get(key):
            fails.append(f"guard-fail: invariant {key} should still hold")

    print("fable5_orchestrate selftest:")
    print(f"  self-audit experiments lite/max/omega = {len(lite.findings)}/{len(mx.findings)}/{len(omega.findings)}")
    print(f"  max ship={mx.ship} avg={mx.gate.get('quality_avg')} self_bakeoff={mx.self_bakeoff}")
    print(f"  omega stop={omega.omega and omega.omega.get('stop_reason')} trace={omega.omega and omega.omega.get('quality_trace')}")
    print(f"  guard: all-pass ship={g_ok.ship} ; one-fail ship={g_bad.ship} (verified={g_bad.gate.get('verified_fraction')})")
    if fails:
        print("FAIL")
        for f in fails:
            print("  -", f)
        return 1
    print("fable5_orchestrate: SELFTEST PASS")
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="Fable5 executable grok+codex orchestrator + autonomy gate")
    p.add_argument("--task", default="self-audit the fable5 skill")
    p.add_argument("--depth", default="max")
    p.add_argument("--guard", type=Path, default=None, help="path to a JSON acceptance-check spec (GUARD mode)")
    p.add_argument("--run-dir", type=Path, default=None)
    p.add_argument("--json", action="store_true")
    p.add_argument("--print-report", action="store_true")
    p.add_argument("--quick", action="store_true", help="faster self-audit subset for evidence suites")
    p.add_argument("--selftest", action="store_true")
    args = p.parse_args(argv)
    if args.selftest:
        return selftest(quick=bool(getattr(args, "quick", False)))

    if args.guard is not None:
        spec = json.loads(args.guard.read_text(encoding="utf-8"))
        r = guard(spec, args.depth, None, args.run_dir)
    else:
        r = orchestrate(args.task, args.depth, None, args.run_dir)

    if args.print_report:
        sys.stdout.write(r.report)
    if args.json:
        json.dump({"task": r.task, "mode": r.mode, "depth": r.depth, "reasoner": r.reasoner,
                   "ship": r.ship, "findings": r.findings, "gate": r.gate,
                   "self_bakeoff": r.self_bakeoff, "invariants": r.invariants, "omega": r.omega,
                   "exec_log": r.exec_log}, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        g = r.gate
        verdict = "SHIP" if r.ship else "DO-NOT-SHIP"
        print(f"fable5_orchestrate[{r.mode}]: {verdict}  verified={g.get('verified_fraction')} "
              f"gate={'PASS' if g.get('pass') else 'FAIL'} q={g.get('quality_avg')} "
              f"own_floor={'clear' if r.self_bakeoff.get('heuristic_clear') else 'FLAGGED'}")
        print("PASS" if r.ship else "FAIL")  # .coord-style line for loop integration
        if not r.ship:
            for f in r.findings:
                if f["status"] != "VERIFIED":
                    print(f"  not-verified: {f['id']} {f['status']} {f['evidence']}")
    return 0 if r.ship else 1


if __name__ == "__main__":
    raise SystemExit(main())
